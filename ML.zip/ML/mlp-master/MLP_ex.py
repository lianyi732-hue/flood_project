#最初的模型 用来训练权重

import joblib
import pandas as pd
import numpy as np
# 关键：导入多层感知机回归器
from sklearn.neural_network import MLPRegressor
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.inspection import permutation_importance
from sklearn.metrics import r2_score, mean_squared_error
import matplotlib.pyplot as plt

# --- 1. 数据加载与准备 ---
try:
    file_path = 'FloodInventory_All_Normalized_city20.xlsx'
    data = pd.read_excel(file_path)
    print(f"成功加载Excel文件: '{file_path}'")
except FileNotFoundError:
    print(f"错误：未找到文件 '{file_path}'。请确保文件与脚本在同一目录下。")
    exit()
except Exception as e:
    print(f"读取Excel文件时发生错误: {e}")
    exit()

data.columns = data.columns.str.strip()
factor_columns = [
    'Number of people affected(ten thousand)',
    'Citywide deaths',
    'Disaster-affected area(thousand hectares)',
    'Economic losses(ten thousand yuan)',
    'Online popularity(Daily average)'
#    'loss_per_person',
#    'Damage_density'
]

missing_cols = [col for col in factor_columns if col not in data.columns]
if missing_cols:
    print(f"\n错误：数据中缺少以下关键列: {missing_cols}")
    exit()

data_factors = data[factor_columns].dropna()
print(f"数据清理完成，用于分析的记录共有 {len(data_factors)} 条。")

# --- 2. 创建一个综合的“洪水严重性指数”作为预测目标 ---
# 注意：对于神经网络，特征和目标的缩放非常重要
# 我们使用对数变换减少偏度，然后用MinMaxScaler归一化
X_features = data_factors.apply(np.log1p)
scaler = MinMaxScaler()
factors_scaled = scaler.fit_transform(X_features)
y_target = np.sum(factors_scaled, axis=1)

print("\n已成功创建“洪水严重性指数”作为模型预测目标。")

# --- 3. 准备训练数据，并进行标准化 ---
# 神经网络对输入数据的尺度非常敏感，因此标准化是必须的
feature_scaler = StandardScaler()
X_features_scaled = feature_scaler.fit_transform(X_features)
x_train, x_test, y_train, y_test = train_test_split(X_features_scaled, y_target, random_state=42, test_size=0.3)

# --- 4. 使用GridSearchCV寻找最佳MLP模型 ---
# 关键：这里我们使用 MLPRegressor
# hidden_layer_sizes 定义了神经网络的结构，例如 (50, 25) 代表两个隐藏层，分别有50和25个神经元
estimator = MLPRegressor(max_iter=1000, random_state=42) # 增加最大迭代次数以确保模型收敛

param_grid = {
    'hidden_layer_sizes': [(50,), (100,), (50, 25)],
    'activation': ['relu', 'tanh'],
    'alpha': [0.001, 0.01, 0.1, 1, 10]  # 显著增加alpha的值
}

print("\n正在使用GridSearchCV进行MLP回归模型参数调优...")
grid_search = GridSearchCV(estimator, param_grid, cv=5, scoring='r2', n_jobs=-1)
grid_search.fit(x_train, y_train)

best_estimator = grid_search.best_estimator_
print(f"参数调优完成，找到的最佳参数为: {grid_search.best_params_}")

# --- 5. 使用排列重要性计算特征权重 ---
print("\n正在计算特征重要性（权重）...")
result = permutation_importance(
    best_estimator, x_test, y_test, n_repeats=10, random_state=42, n_jobs=-1
)

importance_df = pd.DataFrame({
    '指标 (Factor)': factor_columns,
    '重要性均值 (Importance Mean)': result.importances_mean
}).sort_values(by='重要性均值 (Importance Mean)', ascending=False)

total_importance = importance_df['重要性均值 (Importance Mean)'].sum()
if total_importance > 0:
    importance_df['重要性百分比 (Weight %)'] = (importance_df['重要性均值 (Importance Mean)'] / total_importance * 100).round(2)
else:
    importance_df['重要性百分比 (Weight %)'] = 0.0

# --- 6. 展示权重分析结果与模型评估 ---
print('\n\n====== 各项洪水影响指标的权重分析结果 (MLP模型) ======')
print(importance_df[['指标 (Factor)', '重要性百分比 (Weight %)']])

y_pred = best_estimator.predict(x_test)
r2 = r2_score(y_test, y_pred)
mse = mean_squared_error(y_test, y_pred)
print('\n--- 模型性能评估 ---')
print(f'R² 分数: {r2:.4f}')
print(f'均方误差 (MSE): {mse:.4f}')
print(f'(R²分数越接近1，说明MLP模型越能解释数据的变异，结果越可靠)')

# 可视化展示
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
plt.figure(figsize=(12, 8))
plt.barh(importance_df['指标 (Factor)'], importance_df['重要性均值 (Importance Mean)'], color='orange')
plt.xlabel('特征重要性（基于模型性能下降幅度）', fontsize=14)
plt.ylabel('影响指标', fontsize=14)
plt.title('MLP模型分析：各影响指标的权重', fontsize=16)
plt.gca().invert_yaxis()
plt.grid(axis='x', linestyle='--', alpha=0.7)

joblib.dump(best_estimator, 'mlp_flood_model.pkl')
print("\n最佳MLP回归模型已保存为 'mlp_flood_model.pkl'")

plt.show()
