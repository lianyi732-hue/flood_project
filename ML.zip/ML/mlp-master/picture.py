#这个代码的作用是得到权重后的可视化出图

import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

# ===================================================================================
# !!! 核心数据区：请在这里填入您从各个模型运行得到的权重百分比 !!!
# ===================================================================================
model_results = {
    "随机森林(RF)": {
        "受灾人数(万)": 18.19,
        "全市死亡人数": 18.68,
        "受灾面积(千公顷)": 39.05,
        "经济损失(万元)": 19.14,
        "网络热度(日均)": 4.94
    },
    "支持向量机(SVR)": {
        "受灾人数(万)": 24.19,
        "全市死亡人数": 16.58,
        "受灾面积(千公顷)": 20.61,
        "经济损失(万元)": 17.05,
        "网络热度(日均)": 21.57
    },
    "XGBoost": {
        "受灾人数(万)": 17.14,
        "全市死亡人数": 59.05,
        "受灾面积(千公顷)": 6.50,
        "经济损失(万元)": 6.84,
        "网络热度(日均)": 10.46
    },
    "梯度提升树(GBDT)": {
        "受灾人数(万)": 44.66,
        "全市死亡人数": 5.31,
        "受灾面积(千公顷)": 4.03,
        "经济损失(万元)": 23.95,
        "网络热度(日均)": 22.04
    },
    "LightGBM": {
        "受灾人数(万)": 35.1,
        "全市死亡人数": 12.8,
        "受灾面积(千公顷)": 8.2,
        "经济损失(万元)": 28.5,
        "网络热度(日均)": 15.4
    },
    "神经网络(MLP)": {
        "受灾人数(万)": 25.6,
        "全市死亡人数": 9.5,
        "受灾面积(千公顷)": 14.5,
        "经济损失(万元)": 30.1,
        "网络热度(日均)": 20.3
    }
}
# ===================================================================================
# End of Data Area
# ===================================================================================

# --- 1. 准备绘图数据 ---
# 设置matplotlib以正确显示中文和负号
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# 提取模型名称和指标名称
model_names = list(model_results.keys())
factor_names = list(list(model_results.values())[0].keys())

# --- 2. 开始绘图 ---
# 创建一个3x2的子图网格
fig, axes = plt.subplots(figsize=(18, 22), nrows=3, ncols=2)
# 将2D的axes数组展平为1D，方便遍历
axes = axes.flatten()

# 设置颜色循环
colors = plt.cm.get_cmap('Set2', len(model_names))

# 为整个图表添加一个主标题
fig.suptitle('多模型对洪水灾害影响因素的权重分析', size=30, y=0.96)

# 循环为每个模型创建一个独立的横向折线图
for i, model_name in enumerate(model_names):
    ax = axes[i]

    # 获取该模型的数据
    importances = model_results[model_name]
    importance_series = pd.Series(importances, index=factor_names)

    values = importance_series.values
    factors = importance_series.index

    #
    # !!! 核心修改在这里：绘制横向的折线图 (点和线) !!!
    #
    ax.plot(values, factors, marker='o', linestyle='-', color=colors(i), markersize=8, zorder=3)

    # 在每个数据点旁边标注数值
    for x_pos, y_pos in zip(values, factors):
        ax.text(x_pos + 1, y_pos, f'{x_pos:.2f}%', va='center', ha='left', fontsize=11)

    # --- 美化每个子图 ---
    # 设置子图标题
    ax.set_title(model_name, size=18, pad=15)

    # 设置X轴（权重）和Y轴（因子）
    ax.set_xlabel('重要性百分比 (%)', fontsize=14)
    ax.set_ylabel('')  # Y轴标签由因子名称提供
    ax.tick_params(axis='y', labelsize=12, length=0)  # length=0 隐藏刻度线但保留标签
    ax.tick_params(axis='x', labelsize=12)

    # 设置X轴范围和网格线
    ax.set_xlim(0, 70)  # 设置一个固定的X轴上限，方便对比
    ax.grid(True, axis='x', linestyle='--', alpha=0.6)

    # 翻转Y轴，使第一个因子显示在顶部
    ax.invert_yaxis()

# 如果子图数量多于模型数量，隐藏多余的子图
for i in range(len(model_names), len(axes)):
    fig.delaxes(axes[i])

# 调整子图之间的间距
plt.tight_layout(rect=[0, 0, 1, 0.95])  # rect为主标题留出空间

# --- 3. 保存并显示图表 ---
output_filename = 'flood_analysis_horizontal_line_report.png'
plt.savefig(output_filename, dpi=300, bbox_inches='tight')
plt.show()

print(f"\n多模型横向折线图报告已保存为 '{output_filename}'")
