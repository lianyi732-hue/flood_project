import joblib
import pandas as pd
import numpy as np
from sklearn import svm
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.inspection import permutation_importance
from sklearn.metrics import r2_score, mean_squared_error
import matplotlib.pyplot as plt
import os

# --- 1. 数据加载与准备 (已修正) ---
# 定义你的Excel文件名
file_path = 'FloodInventory_All_Normalized_city20.xlsx'

try:
    # 使用pandas的read_excel函数加载数据
    data = pd.read_excel(file_path)
    print(f"成功加载Excel文件: '{file_path}'")
except FileNotFoundError:
    print(f"错误：未找到文件 '{file_path}'。请确保文件与脚本在同一目录下。")
    exit()
except Exception as e:
    print(f"读取Excel文件时发生错误: {e}")
    print("请确保你安装了读取Excel所需的库，如 'openpyxl'。可以运行: pip install openpyxl")
    exit()


# 清理列名，去除可能存在的空格
data.columns = data.columns.str.strip()

# 定义你关心的五个指标
factor_columns = [
    'Number of people affected(ten thousand)',
    'Citywide deaths',
    'Disaster-affected area(thousand hectares)',
    'Economic losses(ten thousand yuan)',
    'Online popularity(Daily average)'
]

# 检查关键列是否存在
missing_cols = [col for col in factor_columns if col not in data.columns]
if missing_cols:
    print(f"\n错误：数据中缺少以下关键列: {missing_cols}")
    exit()

# 删除包含缺失值的行，并只保留需要的列
data_factors = data[factor_columns].dropna()
print(f"数据清理完成，用于分析的记录共有 {len(data_factors)} 条。")


# --- 2. 创建一个综合的“洪水严重性指数”作为预测目标 ---
# 使用MinMaxScaler将所有指标归一化到0-1之间
scaler = MinMaxScaler()
factors_scaled = scaler.fit_transform(data_factors)

# 将归一化后的指标相加，得到严重性指数
y_target = np.sum(factors_scaled, axis=1)
X_features = data_factors.values # 特征是原始的、未归一化的数据

print("\n已成功创建“洪水严重性指数”作为模型预测目标。")

# --- 3. 准备训练数据，并进行标准化 ---
# 对特征数据进行标准化，这对于SVM/SVR模型很重要
feature_scaler = StandardScaler()
X_features_scaled = feature_scaler.fit_transform(X_features)

# 划分训练集和测试集
x_train, x_test, y_train, y_test = train_test_split(X_features_scaled, y_target, random_state=42, test_size=0.3)


# --- 4. 使用GridSearchCV寻找最佳SVR模型 ---
# 注意：我们使用SVR（回归）而不是SVC（分类）
estimator = svm.SVR()

# 为SVR定义参数网格
param_grid = {
    'C': [1, 10, 100],
    'kernel': ['linear', 'rbf'],
    'gamma': ['scale', 'auto']
}

print("\n正在使用GridSearchCV进行SVR模型参数调优...")
# 对于回归任务，评分标准通常使用 'r2'
grid_search = GridSearchCV(estimator, param_grid, cv=5, scoring='r2', n_jobs=-1)
grid_search.fit(x_train, y_train)

# 获取最佳模型
best_estimator = grid_search.best_estimator_
print(f"参数调优完成，找到的最佳参数为: {grid_search.best_params_}")


# --- 5. 使用排列重要性计算特征权重 ---
print("\n正在计算特征重要性（权重）...")
result = permutation_importance(
    best_estimator, x_test, y_test, n_repeats=10, random_state=40, n_jobs=-1
)

# 将结果整理成DataFrame
importance_df = pd.DataFrame({
    '指标 (Factor)': factor_columns,
    '重要性均值 (Importance Mean)': result.importances_mean
}).sort_values(by='重要性均值 (Importance Mean)', ascending=False)

# 将重要性转换为百分比
total_importance = importance_df['重要性均值 (Importance Mean)'].sum()
if total_importance > 0:
    importance_df['重要性百分比 (Weight %)'] = (importance_df['重要性均值 (Importance Mean)'] / total_importance * 100).round(2)
else:
    importance_df['重要性百分比 (Weight %)'] = 0.0


# --- 6. 展示权重分析结果与模型评估 ---
print('\n\n====== 各项洪水影响指标的权重分析结果 (SVR模型) ======')
print(importance_df[['指标 (Factor)', '重要性百分比 (Weight %)']])

# 评估模型性能
y_pred = best_estimator.predict(x_test)
r2 = r2_score(y_test, y_pred)
# 计算均方误差 (MSE)
mse = mean_squared_error(y_test, y_pred)

print('\n--- 模型性能评估 ---')
print(f'R² 分数: {r2:.4f}')
print(f'均方误差 (MSE): {mse:.4f}')
print(f'(R²分数越接近1，说明SVR模型越能解释数据的变异，特征重要性的结果也越可靠)')


# 可视化展示
# 注意: 如果在没有图形界面的环境中运行 (如服务器)，plt.show()可能会报错或无效
# 可以将plt.show()注释掉，只保存图片
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
plt.figure(figsize=(12, 8))
plt.barh(importance_df['指标 (Factor)'], importance_df['重要性均值 (Importance Mean)'], color='royalblue')
plt.xlabel('特征重要性（基于模型R²分数下降幅度）', fontsize=14)
plt.ylabel('影响指标', fontsize=14)
plt.title('SVR模型分析：各影响指标的权重', fontsize=16)
plt.gca().invert_yaxis()
plt.grid(axis='x', linestyle='--', alpha=0.7)

# 保存图表
plt.savefig('svr_feature_importance.png')
print("\n特征重要性图表已保存为 'svr_feature_importance.png'")

# 保存模型
joblib.dump(best_estimator, 'svr_flood_model.pkl')
print("最佳SVR模型已保存为 'svr_flood_model.pkl'")

# plt.show() # 如果需要显示图表，取消此行的注释