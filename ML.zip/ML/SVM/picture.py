#师弟论文的出图代码（包括）


import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# --- 1. 设置全局字体和样式 ---
plt.rcParams['font.family'] = 'Arial'
plt.rcParams['font.size'] = 12
# 在macOS或Linux上，如果Arial字体不可用，可以尝试 'sans-serif'
# plt.rcParams['font.sans-serif'] = ['Arial']


# --- 2. 准备数据 ---
df_data = {
    'name': ['Shanghai', 'Shenzhen', 'Guangzhou', 'Chengdu', 'Wuxi', 'Hangzhou', 'Wuhan', 'Nanjing', 'Ningbo', 'Suzhou'],
    'CW1990': [162.8622, 91.548, 43.6518, 430.631, 33.4476, 632.6316, 620.6877, 153.9693, 305.1765, 481.8528],
    'CW1995': [109.9836, 134.8335, 65.9331, 485.948, 41.6619, 489.843, 664.8894, 118.8792, 244.3428, 423.2438],
    'CW2000': [None, None, 61.0749, 456.583, 50.8509, 568.2456, 625.4361, 156.6288, 175.1202, 364.5495],
    'CW2005': [137.8872, 77.8985, 59.5116, 412.964, 56.4831, 583.245, 575.055, 149.5377, 296.3187, 366.9579],
    'CW2010': [148.968, 77.8212, 50.1345, 365.6238, 41.7024, 565.7832, 763.3251, 202.9824, 175.7259, 379.7766],
    'CW2015': [93.4038, 32.6601, 57.1374, 671.8638, 43.002, 620.2854, 714.8124, 303.0183, 129.4857, 467.856],
    'CW2020': [95.8338, 41.3163, 51.0804, 825.1893, 56.8629, 562.2552, 696.5874, 220.0446, 128.8899, 433.719],
    'CW2023': [86.9616, 32.6511, 58.9662, 903.085, 61.5384, 590.2947, 769.6782, 217.1475, 120.7683, 442.4967]
}
df = pd.DataFrame(df_data)
df = df.set_index('name')
# 清理列名，去掉 'CW'
df.columns = [col.replace('CW', '') for col in df.columns]


# --- 3. 准备绘图数据 ---
years = df.columns
cities = df.index
n_cities = len(cities)
x = np.arange(len(years))
bar_width = 0.07


# --- 4. 开始绘图 ---
fig, ax = plt.subplots(figsize=(14, 8))

# 定义一个淡雅的配色方案
colors = ['#8ECFC9', '#FFBE7A', '#FA7F6F', '#82B0D2', '#BEB8DC',
          '#E7DAD2', '#96CCCB', '#C4A5DE', '#F6C4AF', '#B5EAD7']

# 绘制每个城市的柱状图
for i, city in enumerate(cities):
    offset = (i - n_cities / 2) * bar_width + bar_width / 2
    # 【修改】添加 edgecolor 和 linewidth 参数来绘制边框
    ax.bar(x + offset, df.loc[city], width=bar_width, label=city,
           color=colors[i], edgecolor='black', linewidth=1)


# --- 5. 美化图表 ---
ax.set_xlabel('Year', fontsize=12)
ax.set_ylabel('Urban Water Body Area (km²)', fontsize=12)

# 设置 x 轴刻度和标签
ax.set_xticks(x)
ax.set_xticklabels(years)

# 将图例放置在图表内部
ax.legend(loc='best', ncol=2,  fontsize=12)

# 添加 y 轴的网格线
ax.yaxis.grid(True, linestyle='--', alpha=0.7)
ax.set_axisbelow(True)

# 调整布局以防止标签被截断
plt.tight_layout()

# --- 6. 【修改】保存图表到文件 ---
# 将图表保存为 'urban_water_body_chart.png'，分辨率为 300 DPI
# bbox_inches='tight' 会自动裁剪图片周围的空白
plt.savefig('urban_water_body_chart_with_borders.png', dpi=300, bbox_inches='tight')

print("图表已成功导出为 'urban_water_body_chart_with_borders.png'")