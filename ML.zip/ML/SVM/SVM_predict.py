import joblib
import pandas as pd
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

# 预测全区
data = pd.read_csv(r'C:\Users\fan\Desktop\测试集.csv', encoding='ISO-8859-1')

x_data_pr = data.loc[:, ['key1', 'key2', 'key3', 'key4', 'key5', 'key6', 'key7', 'key8', 'key9', 'key10', 'key11']]

# 数据标准化
transfer = StandardScaler()
x_data_pr = transfer.fit_transform(x_data_pr)

# 加载SVM模型
estimator = joblib.load('svm_tuned.pkl')

# 预测
y_predict = estimator.predict(x_data_pr)

print(y_predict, y_predict.shape)

# 输出预测概率值
roc_auc_plot = estimator.predict_proba(x_data_pr)
print(roc_auc_plot, y_predict.shape)

# 保存预测概率值到CSV文件
pd.DataFrame(roc_auc_plot).to_csv(r'C:\Users\fan\Desktop\SVMjieguo.csv', header=None)

# 预测结果分析或可视化
# 假设我们对预测结果的正负例比例感兴趣
positive_count = sum(y_predict == 1)
negative_count = sum(y_predict == 0)
total_count = len(y_predict)

plt.figure(figsize=(8, 6))
plt.bar(['Positive', 'Negative'], [positive_count, negative_count], color=['green', 'red'])
plt.title('Prediction Result Distribution')
plt.xlabel('Prediction Result')
plt.ylabel('Count')
plt.ylim(0, total_count)
plt.show()