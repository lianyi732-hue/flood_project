import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# --- 1. 设置全局字体和样式 (无需改动) ---
plt.rcParams['font.family'] = 'Arial'
plt.rcParams['font.size'] = 12

# --- 2. 准备数据 (无需改动) ---
# 南方城市GDP数据 (单位：亿元)
gdp_data = {
    'name': ['Shanghai', 'Shenzhen', 'Guangzhou', 'Chengdu', 'Wuxi', 'Hangzhou', 'Wuhan', 'Nanjing', 'Ningbo', 'Suzhou'],
    '1990': [781.66, 171.6665, 319.5952, 194.0857, 160.4402, 189.62, 176.83, 176.52, 141.4, 202.14],
    '1995': [2518.08, 842.7933, 1260.3097, 713.6718, 755.6513, 762.01, 606.91, 584.59, 602.65, 903.11],
    '2000': [4812.15, 2219.2, 2505.58, 1238.2, 1176.543, 1395.67, 1206.84, 1073.54, 1144.57, 1540.68],
    '2005': [9197.13, 5035.77, 5187.85, 2370.163, 2839.54, 2973.74, 2238.23, 2478.26, 2462.09, 4173.48],
    '2010': [16872.42, 10069.06, 10640.67, 5889.462, 5779.21, 5945.82, 5515.76, 5010.36, 5125.82, 9180.76],
    '2015': [25123.45, 18436.84, 17347.37, 10662.31, 8681.37, 10495.28, 10905.6, 10015.73, 8295.35, 14468.68],
    '2020': [38700.6, 27759.02, 25068.75, 17838, 12340.48, 16206.82, 15516.07, 14817.95, 12599.22, 20180.45],
    '2023': [47218.66, 34606.40, 30053.73, 22074.7, 15456.19, 20059, 20011.65, 17421.4, 16452.8, 24653.4]
}
df_gdp = pd.DataFrame(gdp_data).set_index('name')

# 南方城市人口数据 (单位：万人)
pop_data = {
    'name': ['Shanghai', 'Shenzhen', 'Guangzhou', 'Chengdu', 'Wuxi', 'Hangzhou', 'Wuhan', 'Nanjing', 'Ningbo', 'Suzhou'],
    '1990': [13340, 1677.8, 5918.462, 9195, 4177.2, 5832.1, 6903.1, 5018.2, 5091, 5610.2],
    '1995': [14140, 4491.5, 6433.241, 9716, 4291.9, 5979.6, 7435, 5217.2, 5262, 5729.1],
    '2000': [16086, 7012.4, 9948, 11108.5, 5086.6, 7017, 7435.3, 6126.2, 5963, 6792.2],
    '2005': [18900, 8277.5, 9496.8, 12217.2, 5600, 7713, 8580, 6900, 6560, 7580],
    '2010': [23030, 10372, 12709.6, 14054, 6376, 8705.4, 9785.4, 8008, 7606, 10469],
    '2015': [24580, 14142.1, 15949.5, 16853, 6511, 10380, 10607.7, 8235.9, 7825, 10616],
    '2020': [24870, 17633.8, 18740.3, 20947, 7464, 11965, 12447.7, 9319.7, 9420, 12749.6],
    '2023': [24875, 17661.8, 18827, 21403, 7495, 12522, 13739, 9547, 9697, 12958]
}
df_pop = pd.DataFrame(pop_data).set_index('name')

# --- 3. 准备绘图数据 (无需改动) ---
years = df_gdp.columns
cities = df_gdp.index
n_cities = len(cities)
x = np.arange(len(years))
bar_width = 0.07

# 定义统一的淡雅配色方案
colors = ['#8ECFC9', '#FFBE7A', '#FA7F6F', '#82B0D2', '#BEB8DC',
          '#E7DAD2', '#96CCCB', '#C4A5DE', '#F6C4AF', '#B5EAD7']
color_map = dict(zip(cities, colors))


# ==============================================================================
# --- 4. 生成并保存第一个图表：GDP ---
# ==============================================================================
# 创建一个独立的画布用于GDP图表
fig_gdp, ax_gdp = plt.subplots(figsize=(12, 8))

# 绘制GDP数据
for i, city in enumerate(cities):
    offset = (i - n_cities / 2) * bar_width + bar_width / 2
    # 添加黑色边框
    ax_gdp.bar(x + offset, df_gdp.loc[city], width=bar_width, label=city,
               color=color_map[city], edgecolor='black', linewidth=1)

# 美化GDP图表
ax_gdp.set_ylabel('GDP (10⁸ Yuan)')
ax_gdp.set_xlabel('Year')
ax_gdp.set_xticks(x)
ax_gdp.set_xticklabels(years)
ax_gdp.yaxis.grid(True, linestyle='--', alpha=0.7)

# 【修改】将图例放置在左上角，单列显示
ax_gdp.legend(loc='upper left', ncol=1)

# 调整布局以确保所有元素都可见
plt.tight_layout()

# 保存GDP图表
gdp_filename = 'GDP_Southern_Cities_legend_topleft_with_borders.png'
plt.savefig(gdp_filename, dpi=300, bbox_inches='tight')
print(f"GDP图表已成功导出为 '{gdp_filename}'")
plt.close(fig_gdp) # 关闭当前画布，防止与下一个图表重叠


# ==============================================================================
# --- 5. 生成并保存第二个图表：人口 ---
# ==============================================================================
# 创建一个独立的画布用于人口图表
fig_pop, ax_pop = plt.subplots(figsize=(12, 8))

# 绘制人口数据
for i, city in enumerate(cities):
    offset = (i - n_cities / 2) * bar_width + bar_width / 2
    # 添加黑色边框
    ax_pop.bar(x + offset, df_pop.loc[city], width=bar_width, label=city,
               color=color_map[city], edgecolor='black', linewidth=1)

# 美化人口图表
ax_pop.set_ylabel('Population (10⁴ People)')
ax_pop.set_xlabel('Year')
ax_pop.set_xticks(x)
ax_pop.set_xticklabels(years)
ax_pop.yaxis.grid(True, linestyle='--', alpha=0.7)

# 【修改】将图例放置在左上角，单列显示
ax_pop.legend(loc='upper left', ncol=1)

# 调整布局以确保所有元素都可见
plt.tight_layout()

# 保存人口图表
pop_filename = 'Population_Southern_Cities_legend_topleft_with_borders.png'
plt.savefig(pop_filename, dpi=300, bbox_inches='tight')
print(f"人口图表已成功导出为 '{pop_filename}'")
plt.close(fig_pop) # 关闭当前画布