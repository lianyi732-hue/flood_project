import os
import glob
import numpy as np
import pandas as pd
import rasterio
from rasterio.warp import calculate_default_transform, reproject, Resampling
from rasterio.mask import mask
import geopandas as gpd
import matplotlib.pyplot as plt

# -------------------------
# Step 1. 设置路径
# -------------------------
zenodo_dir = "data/zenodo"
landscan_dir = "data/landscan"
output_dir = "data/harmonized"
os.makedirs(output_dir, exist_ok=True)

shanxi_shp = "data/shapefile/山西省_省级行政边界.shp"

# -------------------------
# Step 2. 读取山西省边界
# -------------------------
shanxi = gpd.read_file(shanxi_shp)
shanxi = shanxi.to_crs("EPSG:4326")

# -------------------------
# Step 3. 重采样函数定义
# -------------------------
def resample_to_match(src_path, reference_path, output_path):
    with rasterio.open(reference_path) as ref:
        ref_meta = ref.meta.copy()
        dst_crs = ref.crs
        dst_transform = ref.transform
        dst_width = ref.width
        dst_height = ref.height

    with rasterio.open(src_path) as src:
        data = src.read(1)
        kwargs = src.meta.copy()
        kwargs.update({
            'crs': dst_crs,
            'transform': dst_transform,
            'width': dst_width,
            'height': dst_height
        })

        with rasterio.open(output_path, "w", **kwargs) as dst:
            reproject(
                source=data,
                destination=rasterio.band(dst, 1),
                src_transform=src.transform,
                src_crs=src.crs,
                dst_transform=dst_transform,
                dst_crs=dst_crs,
                resampling=Resampling.bilinear
            )

# -------------------------
# Step 4. 以 LandScan 2000 为基准进行重采样
# -------------------------
ref_raster = glob.glob(os.path.join(landscan_dir, "2000*.tif"))[0]

for file in glob.glob(os.path.join(zenodo_dir, "*.tif")):
    year = os.path.basename(file).split('.')[0]
    out_file = os.path.join(output_dir, f"{year}_resampled.tif")
    resample_to_match(file, ref_raster, out_file)
    print(f"Resampled {year}")

# -------------------------
# Step 5. 提取山西省区域 (Masking)
# -------------------------
def mask_shanxi(src_path, out_path):
    with rasterio.open(src_path) as src:
        out_image, out_transform = mask(src, shanxi.geometry, crop=True)
        out_meta = src.meta.copy()
        out_meta.update({
            "driver": "GTiff",
            "height": out_image.shape[1],
            "width": out_image.shape[2],
            "transform": out_transform
        })
        with rasterio.open(out_path, "w", **out_meta) as dest:
            dest.write(out_image)

for file in glob.glob(os.path.join(output_dir, "*_resampled.tif")):
    year = os.path.basename(file).split('_')[0]
    masked_path = os.path.join(output_dir, f"{year}_shanxi.tif")
    mask_shanxi(file, masked_path)
    print(f"Masked {year}")

# -------------------------
# Step 6. 计算总人口，建立校准比例
# -------------------------
def calc_total_population(tif_path):
    with rasterio.open(tif_path) as src:
        arr = src.read(1)
        arr = np.where(arr < 0, np.nan, arr)
        return np.nansum(arr)

zenodo_pop = {int(os.path.basename(f).split('_')[0]): calc_total_population(f)
              for f in glob.glob(os.path.join(output_dir, "199*.tif"))}
landscan_pop = {int(os.path.basename(f).split('_')[0]): calc_total_population(f)
                for f in glob.glob(os.path.join(landscan_dir, "200*.tif"))}

# 假设2000年为校准点
P2000_landscan = landscan_pop[2000]
P1999_zenodo = zenodo_pop[1999]
scale_factor = P2000_landscan / P1999_zenodo
print("Scale factor =", scale_factor)

# -------------------------
# Step 7. 对1990–1999进行线性校准
# -------------------------
for f in glob.glob(os.path.join(output_dir, "199*.tif")):
    with rasterio.open(f) as src:
        data = src.read(1)
        data = data * scale_factor
        meta = src.meta
        out_name = f.replace(".tif", "_harmonized.tif")
        with rasterio.open(out_name, "w", **meta) as dst:
            dst.write(data, 1)
    print(f"Harmonized {f}")

# -------------------------
# Step 8. 趋势验证
# -------------------------
years = sorted(list(zenodo_pop.keys()) + list(landscan_pop.keys()))
pop_values = [zenodo_pop.get(y, landscan_pop.get(y)) for y in years]

plt.figure(figsize=(8,5))
plt.plot(years, pop_values, marker='o')
plt.title("Population Trend in Shanxi (1990–2023)")
plt.xlabel("Year")
plt.ylabel("Total Population (sum of pixels)")
plt.grid(True)
plt.show()
