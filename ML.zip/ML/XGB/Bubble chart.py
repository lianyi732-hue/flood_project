# 气泡图：20个城市的平均洪涝严重性等级的变化趋势
# 顺序是从严重到不严重
# 字体要求：Times New Roman，24号，加粗
# 新增要求：横坐标旋转 45°

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.neural_network import MLPClassifier

# ==============================================================================
# --- 0. 全局字体设置（Times New Roman, 24pt, bold） ---
# ==============================================================================
FONT_FAMILY = 'Times New Roman'
FONT_SIZE = 24
FONT_WEIGHT = 'bold'

plt.rcParams.update({
    'font.family': FONT_FAMILY,
    'font.size': FONT_SIZE,

    'axes.titlesize': FONT_SIZE,
    'axes.titleweight': FONT_WEIGHT,

    'axes.labelsize': FONT_SIZE,
    'axes.labelweight': FONT_WEIGHT,

    'xtick.labelsize': FONT_SIZE,
    'ytick.labelsize': FONT_SIZE,

    'legend.fontsize': FONT_SIZE,
    'figure.titlesize': FONT_SIZE,

    'axes.unicode_minus': False
})

sns.set_theme(
    style='white',
    rc={
        'font.family': FONT_FAMILY,
        'font.size': FONT_SIZE,
        'axes.titlesize': FONT_SIZE,
        'axes.labelsize': FONT_SIZE,
        'xtick.labelsize': FONT_SIZE,
        'ytick.labelsize': FONT_SIZE,
        'legend.fontsize': FONT_SIZE,
        'figure.titlesize': FONT_SIZE
    }
)

# ==============================================================================
# --- 1. 加载并准备数据 ---
# ==============================================================================
file_path = 'FloodInventory_All_Normalized_city20.xlsx'
data = pd.read_excel(file_path)

data.columns = data.columns.str.strip()

factor_columns = [
    'Number of people affected(ten thousand)',
    'Citywide deaths',
    'Disaster-affected area(thousand hectares)',
    'Economic losses(ten thousand yuan)',
    'Online popularity(Daily average)'
]

data.dropna(subset=factor_columns, inplace=True)

X_features = data[factor_columns].values
X_scaled = StandardScaler().fit_transform(X_features)

data['City'] = (
    data['City'].astype(str)
    .str.replace(' City', '', regex=False)
    .str.replace('市', '', regex=False)
    .str.strip()
)

# ==============================================================================
# --- 2. 训练模型并计算平均严重等级 ---
# ==============================================================================
model = MLPClassifier(random_state=42, max_iter=2000, hidden_layer_sizes=(100, 50))

factors_scaled = MinMaxScaler().fit_transform(data[factor_columns])
y_reg = np.sum(factors_scaled, axis=1)
y_multi_class = pd.qcut(y_reg, q=5, labels=False, duplicates='drop')

model.fit(X_scaled, y_multi_class)
data['Predicted_Severity_Class'] = model.predict(X_scaled)

annual_severity = (
    data.groupby(['City', 'Year'])['Predicted_Severity_Class']
    .mean()
    .reset_index(name='Avg_Severity_Class')
)

# ==============================================================================
# --- 3. 城市顺序 ---
# ==============================================================================
custom_city_order = [
    'Chengdu', 'Wuhan', 'Hangzhou', 'Guangzhou', 'Shenzhen', 'Shanghai',
    'Dalian', "Xi'an", 'Beijing', 'Jinan', 'Tangshan', 'Ningbo',
    'Shenyang', 'Zhengzhou', 'Tianjin', 'Yantai', 'Qingdao',
    'Wuxi', 'Nanjing', 'Suzhou'
]

annual_severity['City'] = pd.Categorical(
    annual_severity['City'],
    categories=custom_city_order,
    ordered=True
)

annual_severity.sort_values(['City', 'Year'], inplace=True)
annual_severity['Bubble_Size'] = (annual_severity['Avg_Severity_Class'] + 1) * 100

# ==============================================================================
# --- 4. 绘图 ---
# ==============================================================================
fig, ax = plt.subplots(figsize=(16, 12))

sc = ax.scatter(
    annual_severity['Year'],
    annual_severity['City'],
    s=annual_severity['Bubble_Size'],
    c=annual_severity['Avg_Severity_Class'],
    cmap='Reds',
    alpha=0.7,
    edgecolors='k',
    linewidth=0.5
)

# 颜色条
cbar = fig.colorbar(sc, ax=ax)
cbar.set_label(
    'Average Severity Level (0–4)',
    rotation=270,
    labelpad=20,
    fontsize=FONT_SIZE,
    fontfamily=FONT_FAMILY,
    fontweight=FONT_WEIGHT
)

for t in cbar.ax.get_yticklabels():
    t.set_fontsize(FONT_SIZE)
    t.set_fontfamily(FONT_FAMILY)
    t.set_fontweight(FONT_WEIGHT)

# 坐标轴标签
ax.set_xlabel('Year', fontsize=FONT_SIZE, fontweight=FONT_WEIGHT)
ax.set_ylabel('City', fontsize=FONT_SIZE, fontweight=FONT_WEIGHT)

# 横坐标：旋转 45°
all_years = sorted(annual_severity['Year'].unique())
ax.set_xticks(all_years)
ax.set_xticklabels(
    all_years,
    rotation=45,
    ha='right',
    fontfamily=FONT_FAMILY,
    fontsize=FONT_SIZE,
    fontweight=FONT_WEIGHT
)

# Y 轴刻度字体
for t in ax.get_yticklabels():
    t.set_fontsize(FONT_SIZE)
    t.set_fontfamily(FONT_FAMILY)
    t.set_fontweight(FONT_WEIGHT)

ax.grid(True, linestyle='--', alpha=0.4)
ax.invert_yaxis()

plt.tight_layout()
plt.savefig(
    'city_severity_bubble_chart_TNR24_bold_xtick45.png',
    dpi=300,
    bbox_inches='tight'
)
plt.show()

print("✅ 完成：横坐标已旋转 45°（Times New Roman，24号，加粗）")
