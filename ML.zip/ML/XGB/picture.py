# 两张图：南北方城市洪涝严重性变化趋势（柱 + 线 + 点）
# 字体要求：Times New Roman，18号，加粗（数字 + 英文）
# 最新的生成Figure_8和Figure_7的生成结果
# 最新一版由于期刊要求改成了Arial字体 字号17


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.neural_network import MLPClassifier
from matplotlib.ticker import MaxNLocator

# ==============================================================================
# 0. 全局绘图风格（Times New Roman, 18pt, bold）
# ==============================================================================
FONT_FAMILY = 'Arial'
FONT_SIZE = 18
FONT_WEIGHT = 'bold'

plt.rcParams.update({
    'font.family': FONT_FAMILY,
    'font.size': FONT_SIZE,

    'axes.titlesize': FONT_SIZE,
    'axes.titleweight': FONT_WEIGHT,

    'axes.labelsize': FONT_SIZE,
    'axes.labelweight': FONT_WEIGHT,

    'xtick.labelsize': FONT_SIZE,
    'ytick.labelsize': FONT_SIZE,

    'legend.fontsize': FONT_SIZE,
    'figure.titlesize': FONT_SIZE,

    'axes.unicode_minus': False
})

# ==============================================================================
# 1. 读取数据
# ==============================================================================
file_path = 'FloodInventory_All_Normalized_city20.xlsx'
data = pd.read_excel(file_path)
data.columns = data.columns.str.strip()

factor_columns = [
    'Number of people affected(ten thousand)', 'Citywide deaths',
    'Disaster-affected area(thousand hectares)',
    'Economic losses(ten thousand yuan)',
    'Online popularity(Daily average)'
]
data.dropna(subset=factor_columns, inplace=True)

data['City'] = (
    data['City'].astype(str)
    .str.replace(' City', '', regex=False)
    .str.replace('市', '', regex=False)
    .str.strip()
)

# ==============================================================================
# 2. 训练模型并预测严重等级
# ==============================================================================
X = data[factor_columns].values
X_scaled = StandardScaler().fit_transform(X)

scaler_y = MinMaxScaler()
factors_scaled = scaler_y.fit_transform(data[factor_columns])
y_reg = np.sum(factors_scaled, axis=1)
y_multi_class = pd.qcut(y_reg, q=5, labels=False, duplicates='drop')

model = MLPClassifier(random_state=42, max_iter=2000, hidden_layer_sizes=(100, 50))
model.fit(X_scaled, y_multi_class)
data['Predicted_Severity_Class'] = model.predict(X_scaled)

annual_severity = (
    data.groupby(['City', 'Year'])['Predicted_Severity_Class']
    .mean()
    .reset_index()
    .rename(columns={'Predicted_Severity_Class': 'Avg_Severity_Class'})
)

# ==============================================================================
# 3. 城市分组
# ==============================================================================
northern_cities_raw = [
    'Beijing', 'Tianjin', "Xi'an City", 'Tangshan City', 'Zhengzhou City',
    'Dalian City', 'Shenyang City', 'Jinan City', 'Qingdao City', 'Yantai City'
]
northern_cities = [c.replace(' City', '').replace('市', '').strip()
                   for c in northern_cities_raw]

all_cities = annual_severity['City'].unique().tolist()
southern_cities = [c for c in all_cities if c not in northern_cities]

# ==============================================================================
# 4. 统一坐标轴
# ==============================================================================
min_year = int(annual_severity['Year'].min())
max_year = int(annual_severity['Year'].max())
x_ticks = list(range(min_year, max_year + 5, 5))

Y_LIM = (-0.2, 4.2)
Y_TICKS = [0, 1, 2, 3, 4]

# ==============================================================================
# 5. 绘图函数（18pt + bold）
# ==============================================================================
def plot_region(ax_list, cities,
                bar_color, line_color, dot_face,
                rolling_window=3):

    for i, city in enumerate(cities):
        ax = ax_list[i]
        city_data = annual_severity[annual_severity['City'] == city].sort_values('Year')

        if not city_data.empty:
            years = city_data['Year'].to_numpy()
            vals = city_data['Avg_Severity_Class'].to_numpy()

            ax.bar(years, vals, width=0.75,
                   color=bar_color, alpha=0.80, edgecolor='none', zorder=1)

            smooth = (pd.Series(vals)
                      .rolling(window=rolling_window, center=True, min_periods=1)
                      .mean()
                      .to_numpy())
            ax.plot(years, smooth, color=line_color, lw=2.5, zorder=3)

            ax.scatter(years, vals, s=70,
                       facecolor=dot_face, edgecolor='white',
                       linewidth=1.0, zorder=4)

        ax.set_xlim(min_year - 1, max_year + 1)
        ax.set_xticks(x_ticks)
        ax.set_ylim(*Y_LIM)
        ax.set_yticks(Y_TICKS)
        ax.xaxis.set_major_locator(MaxNLocator(integer=True))

        ax.grid(True, linestyle='--', alpha=0.35, zorder=0)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

        ax.set_title(city, fontsize=FONT_SIZE,
                     fontfamily=FONT_FAMILY,
                     fontweight=FONT_WEIGHT,
                     pad=6)

        if i % 2 == 0:
            ax.set_ylabel('Average Severity Level',
                          fontsize=FONT_SIZE,
                          fontfamily=FONT_FAMILY,
                          fontweight=FONT_WEIGHT)
        else:
            ax.set_ylabel('')

        if i >= 8:
            ax.set_xlabel('Year',
                          fontsize=FONT_SIZE,
                          fontfamily=FONT_FAMILY,
                          fontweight=FONT_WEIGHT)
        else:
            ax.set_xlabel('')

        ax.tick_params(axis='both', labelsize=FONT_SIZE)
        for t in ax.get_xticklabels() + ax.get_yticklabels():
            t.set_fontfamily(FONT_FAMILY)
            t.set_fontsize(FONT_SIZE)
            t.set_fontweight(FONT_WEIGHT)

    for j in range(len(cities), len(ax_list)):
        ax_list[j].axis('off')

# ==============================================================================
# 6. 北方城市
# ==============================================================================
fig_north, axes_north = plt.subplots(5, 2, figsize=(18, 14),
                                     sharex=True, sharey=True)
axes_north = axes_north.flatten()

plot_region(
    ax_list=axes_north,
    cities=northern_cities,
    bar_color="#bdd7e7",
    line_color="#08519c",
    dot_face="#2171b5"
)

fig_north.tight_layout()
# 修改点：同时保存矢量PDF和高分辨率PNG（500 DPI，满足组合图要求）
fig_north.savefig('Northern_Cities_Severity_TNR18_bold.pdf',
                  format='pdf', bbox_inches='tight')
fig_north.savefig('Northern_Cities_Severity_TNR18_bold.png',
                  dpi=500, bbox_inches='tight')
plt.show()

# ==============================================================================
# 7. 南方城市
# ==============================================================================
fig_south, axes_south = plt.subplots(5, 2, figsize=(18, 14),
                                     sharex=True, sharey=True)
axes_south = axes_south.flatten()

plot_region(
    ax_list=axes_south,
    cities=southern_cities,
    bar_color="#fcbba1",
    line_color="#a50f15",
    dot_face="#cb181d"
)

fig_south.tight_layout()
# 修改点：同时保存矢量PDF和高分辨率PNG（500 DPI）
fig_south.savefig('Southern_Cities_Severity_TNR18_bold.pdf',
                  format='pdf', bbox_inches='tight')
fig_south.savefig('Southern_Cities_Severity_TNR18_bold.png',
                  dpi=500, bbox_inches='tight')
plt.show()

print("✅ 完成：字体已统一为 Times New Roman，18号，加粗；图片已保存为PDF（矢量）和500 DPI的PNG，符合期刊要求。")