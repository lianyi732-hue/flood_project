# 两张图  分别是 各个城市的严重性排名 和 高危城市排名
#这个代码是最开始两张排名图，出图不规范，字体字号等都不规范

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# ==============================================================================
# --- 1. 数据加载 ---
# ==============================================================================
# 加载包含您最终专家权重得分的文件
file_path = 'Final_Severity_Scores_Expert_Weighted.xlsx'

try:
    data = pd.read_excel(file_path, engine='openpyxl')
    print(f"✅ 成功加载最终得分文件: '{file_path}'")
except Exception as e:
    print(f"❌ 读取文件时发生错误: {e}")
    exit()

# ==============================================================================
# --- 2. 基于“专家权重得分”进行最终的五等级划分 ---
# ==============================================================================
class_names = ['极低严重', '低严重', '中严重', '高严重', '极高严重']
try:
    # 确保'Final_Severity_Score'列存在
    if 'Final_Severity_Score' not in data.columns:
        print("❌ 错误：文件中未找到 'Final_Severity_Score' 列。")
        exit()

    # 创建文本标签的等级列，用于展示和理解
    data['Final_Severity_Level'] = pd.qcut(data['Final_Severity_Score'], q=5, labels=class_names, duplicates='drop')

    # 创建一个对应的数字等级列 (0-4)，用于数学计算
    data['Final_Severity_Class_Num'] = pd.qcut(data['Final_Severity_Score'], q=5, labels=False, duplicates='drop')

    print("已根据您的“专家权重得分”完成最终的五等级划分。")
    print("\n最终各类别样本数量分布：")
    print(data['Final_Severity_Level'].value_counts().sort_index())
except Exception as e:
    print(f"分级时发生错误：{e}。可能是数据量过少或分数完全相同。")
    exit()

# ==============================================================================
# --- 3. 按城市进行汇总分析 ---
# ==============================================================================
print("\n开始按城市进行风险汇总分析...")
if 'City' not in data.columns:
    print("错误：数据中缺少 'City' 列，无法按城市进行分析。")
    exit()

# 清理城市名
data['City'] = data['City'].astype(str).str.replace(' City', '').str.replace('市', '').str.strip()

# 按城市分组并进行聚合统计
city_risk_analysis = data.groupby('City').agg(
    total_events=('City', 'count'),
    # 使用数字等级列来计算平均值
    avg_severity_class=('Final_Severity_Class_Num', 'mean'),
    # 使用数字等级列来统计高危事件
    high_severity_events=('Final_Severity_Class_Num', lambda x: (x >= 3).sum())
).reset_index()

# 计算高危事件比例
city_risk_analysis['high_severity_ratio'] = city_risk_analysis['high_severity_events'] / city_risk_analysis['total_events']

# 按平均严重等级排序
city_risk_analysis_sorted = city_risk_analysis.sort_values(by='avg_severity_class', ascending=False)

print("\n--- 城市洪水灾害风险分析报告 (基于专家权重) ---")
print(city_risk_analysis_sorted)

# 将分析结果保存到CSV
city_risk_analysis_sorted.to_csv('city_flood_risk_analysis_expert_weighted.csv', index=False, encoding='utf-8-sig')
print("\n城市风险分析结果已保存到 'city_flood_risk_analysis_expert_weighted.csv'")


# ==============================================================================
# --- 4. 可视化风险最高的城市 ---
# ==============================================================================
top_n = 20
top_cities = city_risk_analysis_sorted.head(top_n)

# 图一：平均严重等级排名
plt.figure(figsize=(12, 10))
sns.barplot(x='avg_severity_class', y='City', data=top_cities, palette='viridis')
plt.title(f'洪水灾害平均严重等级最高的 {top_n} 个城市 (基于专家权重)', fontsize=18)
plt.xlabel('平均严重等级 (0-4)', fontsize=12)
plt.ylabel('城市', fontsize=12)
plt.grid(axis='x', linestyle='--', alpha=0.7)
plt.tight_layout()
plt.savefig('top_risk_cities_by_avg_severity_expert.png', dpi=300)
plt.show()

# 图二：高危事件占比排名
plt.figure(figsize=(12, 10))
top_cities_by_ratio = city_risk_analysis.sort_values(by='high_severity_ratio', ascending=False).head(top_n)
sns.barplot(x='high_severity_ratio', y='City', data=top_cities_by_ratio, palette='plasma')
plt.title(f'高危洪水事件 (等级3&4) 占比最高的 {top_n} 个城市 (基于专家权重)', fontsize=18)
plt.xlabel('高危事件占比', fontsize=12)
plt.ylabel('城市', fontsize=12)
plt.grid(axis='x', linestyle='--', alpha=0.7)
plt.tight_layout()
plt.savefig('top_risk_cities_by_high_severity_ratio_expert.png', dpi=300)
plt.show()

print("\n所有分析与绘图任务均已完成！")