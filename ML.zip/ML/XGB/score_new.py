# ============================================
# Combined Figure (SCI template)
# FINAL REQUIREMENT (STRICT):
# - ALL text = Times New Roman
# - Font size = 20 pt
# - Font weight = BOLD
# - Two panels merged
# - Right panel removes y-axis labels
# - Shared city order from left panel
# ============================================
# Figure_5 的生成代码，字体现在是Arial

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

FONT_FAMILY = "Arial"
FONT_SIZE = 20
FONT_WEIGHT = "bold"

# -----------------------------------------------------------------------------
# 0. Global style (hard override, prevent seaborn rollback)
# -----------------------------------------------------------------------------
plt.rcParams.update({
    "font.family": FONT_FAMILY,
    "font.size": FONT_SIZE,

    "axes.titlesize": FONT_SIZE,
    "axes.labelsize": FONT_SIZE,

    "xtick.labelsize": FONT_SIZE,
    "ytick.labelsize": FONT_SIZE,

    "legend.fontsize": FONT_SIZE,
    "figure.titlesize": FONT_SIZE,

    "axes.unicode_minus": False
})

sns.set_theme(
    style="white",
    rc={
        "font.family": FONT_FAMILY,
        "font.size": FONT_SIZE,
        "axes.titlesize": FONT_SIZE,
        "axes.labelsize": FONT_SIZE,
        "xtick.labelsize": FONT_SIZE,
        "ytick.labelsize": FONT_SIZE,
        "legend.fontsize": FONT_SIZE,
        "figure.titlesize": FONT_SIZE
    }
)

# =============================================================================
# 1. Load data
# =============================================================================
file_path = "Final_Severity_Scores_Expert_Weighted.xlsx"
data = pd.read_excel(file_path, engine="openpyxl")

# =============================================================================
# 2. Severity class (0–4)
# =============================================================================
data["Final_Severity_Class_Num"] = pd.qcut(
    data["Final_Severity_Score"],
    q=5,
    labels=False,
    duplicates="drop"
)

data["City"] = (
    data["City"].astype(str)
    .str.replace(" City", "", regex=False)
    .str.replace("市", "", regex=False)
    .str.strip()
)

# =============================================================================
# 3. City-level aggregation
# =============================================================================
city_stats = data.groupby("City").agg(
    total_events=("City", "count"),
    avg_severity_class=("Final_Severity_Class_Num", "mean"),
    high_severity_events=("Final_Severity_Class_Num", lambda x: (x >= 3).sum())
).reset_index()

city_stats["high_severity_ratio_pct"] = (
    city_stats["high_severity_events"] / city_stats["total_events"] * 100
)

# =============================================================================
# 4. Select top N and enforce shared city order
# =============================================================================
top_n = 20

avg_sorted = city_stats.sort_values(
    by="avg_severity_class",
    ascending=False
).head(top_n).copy()

ratio_sorted = avg_sorted[["City"]].merge(
    city_stats[["City", "high_severity_ratio_pct"]],
    on="City",
    how="left"
)

# =============================================================================
# 5. Plot merged figure
# =============================================================================
fig, axes = plt.subplots(1, 2, figsize=(18, 10), sharey=True)

# -------------------------
# (a) Average severity
# -------------------------
ax1 = axes[0]
sns.barplot(
    ax=ax1,
    x="avg_severity_class",
    y="City",
    data=avg_sorted,
    palette="Blues_r"
)

ax1.set_title("(a) Top 20 cities by average severity",
              fontsize=FONT_SIZE, fontfamily=FONT_FAMILY, fontweight=FONT_WEIGHT)
ax1.set_xlabel("Average severity level (0–4)",
               fontsize=FONT_SIZE, fontfamily=FONT_FAMILY, fontweight=FONT_WEIGHT)
ax1.set_ylabel("City",
               fontsize=FONT_SIZE, fontfamily=FONT_FAMILY, fontweight=FONT_WEIGHT)

ax1.tick_params(axis="both", labelsize=FONT_SIZE)

for t in ax1.get_xticklabels() + ax1.get_yticklabels():
    t.set_fontfamily(FONT_FAMILY)
    t.set_fontsize(FONT_SIZE)
    t.set_fontweight(FONT_WEIGHT)

ax1.grid(axis="x", linestyle="--", alpha=0.4)
ax1.set_axisbelow(True)

max_sev = avg_sorted["avg_severity_class"].max()
ax1.set_xlim(0, max_sev * 1.15)

for patch in ax1.patches:
    w = patch.get_width()
    y = patch.get_y() + patch.get_height() / 2
    ax1.text(
        w + max_sev * 0.02,
        y,
        f"{w:.2f}",
        va="center",
        ha="left",
        fontsize=FONT_SIZE,
        fontfamily=FONT_FAMILY,
        fontweight=FONT_WEIGHT
    )

# -------------------------
# (b) High-severity ratio
# -------------------------
ax2 = axes[1]
sns.barplot(
    ax=ax2,
    x="high_severity_ratio_pct",
    y="City",
    data=ratio_sorted,
    palette="Reds_r"
)

ax2.set_title("(b) Top 20 cities by proportion of high-severity events",
              fontsize=FONT_SIZE, fontfamily=FONT_FAMILY, fontweight=FONT_WEIGHT)
ax2.set_xlabel("Proportion of high-severity events (%)",
               fontsize=FONT_SIZE, fontfamily=FONT_FAMILY, fontweight=FONT_WEIGHT)

ax2.set_ylabel("")
ax2.tick_params(axis="y", left=False, labelleft=False)
ax2.tick_params(axis="x", labelsize=FONT_SIZE)

for t in ax2.get_xticklabels():
    t.set_fontfamily(FONT_FAMILY)
    t.set_fontsize(FONT_SIZE)
    t.set_fontweight(FONT_WEIGHT)

ax2.grid(axis="x", linestyle="--", alpha=0.4)
ax2.set_axisbelow(True)

max_ratio = ratio_sorted["high_severity_ratio_pct"].max()
ax2.set_xlim(0, max_ratio * 1.15)

for patch in ax2.patches:
    w = patch.get_width()
    y = patch.get_y() + patch.get_height() / 2
    ax2.text(
        w + max_ratio * 0.02,
        y,
        f"{w:.1f}%",
        va="center",
        ha="left",
        fontsize=FONT_SIZE,
        fontfamily=FONT_FAMILY,
        fontweight=FONT_WEIGHT
    )

# -----------------------------------------------------------------------------
# 6. Save & show
# -----------------------------------------------------------------------------
plt.tight_layout()
plt.savefig(
    "combined_city_flood_risk_TNR20_bold.png",
    dpi=300,
    bbox_inches="tight"
)
plt.show()

print("✅ 完成：所有字体已统一为 Times New Roman，20 号，加粗（无遗漏）")
