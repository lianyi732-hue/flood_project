# 这个代码用于生成柱状图，也是一个分组对比图
# 第二组图生成了两张年度趋势图（AHP 和 Entropy）
# ✅ 最终图形规范：
# 1) 英文 + 数字：Times New Roman
# 2) 坐标轴字体（标题 + 刻度）：24号，加粗
# 3) 标注字体（Legend / Legend title）：28号，加粗
# 4) 图1 横坐标（City）强制旋转 45°
# 最新的要求是做出了字体的调整 现在的字体是Arial
# 这个是Figure_4的成图代码

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.ticker import MaxNLocator
from matplotlib.font_manager import FontProperties

# ==============================================================================
# --- 0. 统一字体规范 ---
# ==============================================================================
AXIS_FONTSIZE = 24
ANNOT_FONTSIZE = 28
FONT_WEIGHT = 'bold'

fp_axis = FontProperties(family='Arial', size=AXIS_FONTSIZE, weight=FONT_WEIGHT)
fp_annot = FontProperties(family='Arial', size=ANNOT_FONTSIZE, weight=FONT_WEIGHT)

plt.rcParams['font.family'] = 'Arial'
plt.rcParams['axes.unicode_minus'] = False


def style_axis(ax, xlabel=None, ylabel=None, title=None,
               legend=None, legend_title=None):
    """统一设置（不在这里处理旋转，旋转统一放到最后强制执行，避免被pandas覆盖）"""
    if title is not None:
        ax.set_title(title, fontproperties=fp_axis)
    if xlabel is not None:
        ax.set_xlabel(xlabel, fontproperties=fp_axis)
    if ylabel is not None:
        ax.set_ylabel(ylabel, fontproperties=fp_axis)

    ax.tick_params(axis='both', which='major', labelsize=AXIS_FONTSIZE)
    for t in ax.get_xticklabels():
        t.set_fontproperties(fp_axis)
    for t in ax.get_yticklabels():
        t.set_fontproperties(fp_axis)

    if legend is not None:
        for txt in legend.get_texts():
            txt.set_fontproperties(fp_annot)
        if legend.get_title() is not None:
            legend.get_title().set_fontproperties(fp_annot)
            if legend_title is not None:
                legend.get_title().set_text(legend_title)


def force_rotate_xticks(ax, rotation=45, ha='right'):
    """强制旋转x轴刻度（确保不会被pandas/barplot覆盖）"""
    labels = ax.get_xticklabels()
    for t in labels:
        t.set_rotation(rotation)
        t.set_ha(ha)
        t.set_fontproperties(fp_axis)
    ax.figure.canvas.draw_idle()


# ==============================================================================
# --- 1. 数据加载 ---
# ==============================================================================
ahp_file_path = 'Flood_Severity_Scores_Final_Weighs_AHP.xlsx'
entropy_file_path = 'Flood_Severity_Scores_Final_Weighs_Entropy.xlsx'

data_ahp = pd.read_excel(ahp_file_path, engine='openpyxl')
data_entropy = pd.read_excel(entropy_file_path, engine='openpyxl')

# ==============================================================================
# --- 2. 集成得分 ---
# ==============================================================================
def calculate_ensemble_score(data):
    score_columns = [
        'Score_GBDT', 'Score_XGBoost', 'Score_RF',
        'Score_SVM', 'Score_LightGBM', 'Score_MLP'
    ]
    data['Ensemble_Score'] = data[score_columns].mean(axis=1)
    return data


data_ahp = calculate_ensemble_score(data_ahp)
data_entropy = calculate_ensemble_score(data_entropy)

# ==============================================================================
# --- 3. 五等级划分 ---
# ==============================================================================
class_names_english = ['Very Low', 'Low', 'Medium', 'High', 'Very High']

data_ahp['Final_Severity_Level'] = pd.qcut(data_ahp['Ensemble_Score'], q=5, labels=class_names_english)
data_entropy['Final_Severity_Level'] = pd.qcut(data_entropy['Ensemble_Score'], q=5, labels=class_names_english)

# ==============================================================================
# --- 4. 图1：城市灾害等级构成（上下组合） ---
# ==============================================================================
def prepare_city_data(data):
    city_level_counts = data.groupby(['City', 'Final_Severity_Level']).size().unstack(fill_value=0)
    city_level_prop = city_level_counts.div(city_level_counts.sum(axis=1), axis=0)

    for lvl in class_names_english:
        if lvl not in city_level_prop.columns:
            city_level_prop[lvl] = 0

    city_level_prop = city_level_prop[class_names_english]
    city_level_prop['high_risk'] = city_level_prop['High'] + city_level_prop['Very High']
    city_level_prop.sort_values('high_risk', ascending=False, inplace=True)
    city_level_prop.drop(columns='high_risk', inplace=True)

    city_level_prop.index = city_level_prop.index.str.replace(' City', '', regex=False)
    return city_level_prop


city_data_ahp = prepare_city_data(data_ahp)
city_data_entropy = prepare_city_data(data_entropy)

fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(22, 16), sharex=True)

city_data_ahp.plot(kind='bar', stacked=True, ax=ax1, colormap='coolwarm', edgecolor='white')
city_data_entropy.plot(kind='bar', stacked=True, ax=ax2, colormap='coolwarm', edgecolor='white')

for ax in [ax1, ax2]:
    ax.set_ylim(0, 1)
    ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
    ax.set_yticklabels(['0%', '25%', '50%', '75%', '100%'])
    ax.grid(axis='y', linestyle='--', alpha=0.7)

# 上图隐藏横坐标
plt.setp(ax1.get_xticklabels(), visible=False)

style_axis(ax1, ylabel='Proportion of Events',
           title='AHP: Historical Flood Severity Composition by City')

style_axis(ax2, xlabel='City', ylabel='Proportion of Events',
           title='Entropy: Historical Flood Severity Composition by City')

# legend 只保留在下图
ax1.legend().remove()
legend = ax2.legend(title='Severity Level', bbox_to_anchor=(1.01, 1), loc='upper left')
style_axis(ax2, legend=legend, legend_title='Severity Level')

# ✅ 关键：在所有绘制/legend/tight_layout之后，强制旋转图1横坐标 45°
plt.tight_layout()
force_rotate_xticks(ax2, rotation=45, ha='right')

plt.savefig('city_severity_composition_combined.png', dpi=300, bbox_inches='tight')
plt.show()

# ==============================================================================
# --- 5. 图2：年度趋势图 ---
# ==============================================================================
def create_year_trend_plot(data, name):
    data = data.copy()
    data['Year'] = pd.to_numeric(data['Year'], errors='coerce')
    data = data.dropna(subset=['Year'])
    data['Year'] = data['Year'].astype(int)

    counts = data.groupby(['Year', 'Final_Severity_Level']).size().unstack(fill_value=0)
    for lvl in class_names_english:
        if lvl not in counts.columns:
            counts[lvl] = 0
    counts = counts.sort_index()

    smooth = counts.rolling(window=3, center=True, min_periods=1).mean()

    fig, ax = plt.subplots(figsize=(20, 10))
    colors = plt.cm.viridis(np.linspace(0, 1, len(class_names_english)))

    for i, lvl in enumerate(class_names_english):
        ax.plot(counts.index, counts[lvl],
                linestyle=':', alpha=0.35, linewidth=1.2,
                marker='o', markersize=4, color=colors[i])
        ax.plot(counts.index, smooth[lvl],
                linewidth=2.8, label=lvl, color=colors[i])

    ax.grid(True, linestyle='--', alpha=0.7)
    ax.xaxis.set_major_locator(MaxNLocator(integer=True, nbins=15))

    style_axis(ax, xlabel='Year', ylabel='Number of Events',
               title=f'{name}: Trend of Flood Events by Severity Level Over Years')

    legend = ax.legend(title='Severity Level')
    style_axis(ax, legend=legend, legend_title='Severity Level')

    plt.tight_layout()
    plt.savefig(f'year_severity_trend_{name}.png', dpi=300, bbox_inches='tight')
    plt.show()


create_year_trend_plot(data_ahp, 'AHP')
create_year_trend_plot(data_entropy, 'Entropy')
