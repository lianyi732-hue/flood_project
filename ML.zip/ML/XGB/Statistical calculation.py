import geopandas as gpd
import pandas as pd
from rasterstats import zonal_stats

# ==============================================================================
# --- 1. 用户配置区 ---
# ==============================================================================
# 请将文件名替换为您自己的实际文件名
city_boundaries_path = 'F:\原始数据\北京市矢量范围\北京市.shp'  # 您的城市边界矢量文件
dem_raster_path = 'F:\原始数据\DEM北京市\北京市\china.tif'  # 您的DEM栅格文件
slope_raster_path = 'F:\原始数据\作图\处理过程\podu.tif'  # 您预先生成的坡度栅格文件

output_csv_path = 'F:\原始数据\作图\City_Topographic_Features.csv'  # 最终输出的文件名

# ==============================================================================
# --- 2. 主程序 ---
# ==============================================================================
try:
    # --- a. 加载矢量数据 ---
    print(f"正在加载城市边界文件: {city_boundaries_path}...")
    cities_gdf = gpd.read_file(city_boundaries_path)
    print(f"加载成功！共找到 {len(cities_gdf)} 个城市。")

    # --- b. 计算高程相关指标 ---
    print(f"\n正在从 {dem_raster_path} 中为每个城市计算高程统计数据...")
    # 使用zonal_stats一次性计算所有需要的统计量
    elevation_stats = zonal_stats(
        cities_gdf,
        dem_raster_path,
        stats=['mean', 'std', 'min', 'max']
    )
    # 将结果（一个字典列表）转换为DataFrame
    elevation_df = pd.DataFrame(elevation_stats)
    elevation_df.rename(columns={
        'mean': 'Mean_Elevation',
        'std': 'Std_Dev_Elevation',
        'min': 'Min_Elevation',
        'max': 'Max_Elevation'
    }, inplace=True)
    print("高程指标计算完成！")

    # --- c. 计算坡度相关指标 ---
    print(f"\n正在从 {slope_raster_path} 中为每个城市计算坡度统计数据...")
    slope_stats = zonal_stats(
        cities_gdf,
        slope_raster_path,
        stats=['mean']
    )
    slope_df = pd.DataFrame(slope_stats)
    slope_df.rename(columns={'mean': 'Mean_Slope'}, inplace=True)
    print("坡度指标计算完成！")

    # --- d. 合并所有结果 ---
    print("\n正在合并所有计算结果...")
    # 将原始地理数据与计算出的统计数据合并
    final_df = pd.concat([cities_gdf, elevation_df, slope_df], axis=1)

    # 计算地势起伏度
    final_df['Relief'] = final_df['Max_Elevation'] - final_df['Min_Elevation']
    print("地势起伏度计算完成！")

    # --- e. 清理并导出最终表格 ---
    # 选择您最终需要的列（例如，只保留城市名和计算出的指标）
    # 您需要知道您城市边界文件中代表城市名的列叫什么，这里假设是'NAME'
    city_name_column = 'NAME'  # !! 如果您的城市名字段不叫'NAME'，请修改这里 !!
    if city_name_column not in final_df.columns:
        print(f"警告: 未在shapefile中找到名为'{city_name_column}'的列，将使用第一列作为城市名。")
        city_name_column = final_df.columns[0]

    final_columns = [city_name_column, 'Mean_Elevation', 'Std_Dev_Elevation', 'Relief', 'Mean_Slope']
    # 过滤掉不存在的列
    final_columns_exist = [col for col in final_columns if col in final_df.columns]

    output_df = final_df[final_columns_exist]

    # 导出为CSV文件
    output_df.to_csv(output_csv_path, index=False, encoding='utf-8-sig')
    print("\n" + "=" * 60)
    print(f"✅ 所有计算均已完成！")
    print(f"包含所有地形指标的最终表格已保存到: '{output_csv_path}'")
    print("=" * 60)

    # 显示结果预览
    print("\n最终结果预览：")
    print(output_df.head())

except Exception as e:
    import traceback

    print(f"\n❌ 处理过程中发生错误: {e}")
    traceback.print_exc()