#先通过AHP或熵权法进行人工/客观赋权，再利用机器学习模型xgb进行学习和修正
#这里AHP的权重是我计算得到的

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from xgboost import XGBRegressor

# ==============================================================================
# --- 1. 数据加载与准备 (与之前相同) ---
# ==============================================================================
try:
    file_path = 'FloodInventory_All_Normalized_city20.xlsx'
    data = pd.read_excel(file_path)
    print(f"成功加载Excel文件: '{file_path}'")
except Exception as e:
    print(f"读取Excel文件时发生错误: {e}")
    exit()

data.columns = data.columns.str.strip()
factor_columns = [
    'Number of people affected(ten thousand)',
    'Citywide deaths',
    'Disaster-affected area(thousand hectares)',
    'Economic losses(ten thousand yuan)',
    'Online popularity(Daily average)'
]
data_factors = data[factor_columns].dropna()
X_features = data_factors.values

# 创建回归目标 y_reg
scaler_y = MinMaxScaler()
factors_scaled = scaler_y.fit_transform(data_factors)
y_reg = np.sum(factors_scaled, axis=1)

# 标准化特征 X_scaled
scaler_X = StandardScaler()
X_scaled = scaler_X.fit_transform(X_features)


# ==============================================================================
# --- 2. AHP混合模型：权重设定与修正过程分析 ---
# ==============================================================================
print("\n" + "="*60)
print("--- 分析AHP混合模型的修正过程 ---")

# --- 步骤A: 原始AHP权重 (您的输入) ---
ahp_weights_dict = {
    'Citywide deaths': 0.497,
    'Economic losses(ten thousand yuan)': 0.245,
    'Number of people affected(ten thousand)': 0.105,
    'Disaster-affected area(thousand hectares)': 0.105,
    'Online popularity(Daily average)': 0.048
}
ahp_weights = np.array([ahp_weights_dict[col] for col in factor_columns])
expert_index_ahp = np.dot(factors_scaled, ahp_weights)
X_hybrid_ahp = np.c_[X_scaled, expert_index_ahp]

# --- 步骤B: 训练AHP混合模型 ---
ahp_model = XGBRegressor(random_state=42)
ahp_model.fit(X_hybrid_ahp, y_reg)

# --- 步骤C: 提取并展示“修正后”的特征重要性 ---
ahp_corrected_importances = ahp_model.feature_importances_
# 将6个特征的重要性整理成DataFrame
ahp_features_names = factor_columns + ['AHP_Expert_Index']
ahp_importance_df = pd.DataFrame({
    'Feature': ahp_features_names,
    'Importance': ahp_corrected_importances
}).sort_values('Importance', ascending=False)

print("\n【原始AHP权重】(您的输入):")
print(pd.Series(ahp_weights_dict).sort_values(ascending=False))
print("\n【机器学习修正后的特征重要性】:")
print(ahp_importance_df)


# ==============================================================================
# --- 3. 熵权法混合模型：权重设定与修正过程分析 ---
# ==============================================================================
print("\n" + "="*60)
print("--- 分析熵权法混合模型的修正过程 ---")

# --- 步骤A: 原始熵权法权重 (客观计算) ---
def calculate_entropy_weights(data):
    p = data / data.sum(axis=0)
    p[p == 0] = 1e-10
    k = 1 / np.log(data.shape[0])
    e = -k * (p * np.log(p)).sum(axis=0)
    d = 1 - e
    return d / d.sum()

entropy_weights = calculate_entropy_weights(factors_scaled)
entropy_weights_dict = dict(zip(factor_columns, entropy_weights))
expert_index_entropy = np.dot(factors_scaled, entropy_weights)
X_hybrid_entropy = np.c_[X_scaled, expert_index_entropy]

# --- 步骤B: 训练熵权法混合模型 ---
entropy_model = XGBRegressor(random_state=42)
entropy_model.fit(X_hybrid_entropy, y_reg)

# --- 步骤C: 提取并展示“修正后”的特征重要性 ---
entropy_corrected_importances = entropy_model.feature_importances_
entropy_features_names = factor_columns + ['Entropy_Expert_Index']
entropy_importance_df = pd.DataFrame({
    'Feature': entropy_features_names,
    'Importance': entropy_corrected_importances
}).sort_values('Importance', ascending=False)

print("\n【原始熵权法权重】(客观计算):")
print(pd.Series(entropy_weights_dict).sort_values(ascending=False))
print("\n【机器学习修正后的特征重要性】:")
print(entropy_importance_df)
print("="*60)


# ==============================================================================
# --- 4. 最终解读 ---
# ==============================================================================
print("\n--- 解读说明 ---")
print("通过对比【原始权重】和【修正后的特征重要性】，我们可以观察到：")
print("1. 'Expert_Index'的重要性有多高？ -> 代表了机器学习模型在多大程度上采纳了您的加权总分。")
print("2. 原始的5个因子在修正后是否依然重要？ -> 如果某个原始因子的重要性依然很高，说明模型认为它包含了'Expert_Index'未能完全捕捉的、独特的预测信息，这就是'修正'的具体体现。")