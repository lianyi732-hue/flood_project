# ================================================================
# AHP → 熵权 → 综合指数 → 6 模型混合 → RF 代理 → SHAP 双图
# 兼容 shap legacy：绘图不使用 ax=
# 增强：6 模型真集成 + 代理模型 fidelity (R²) 检验
# 美化：左侧 "Influencing factors / 影响因子" 总标题
# 修改：强制整张图字体为 Arial
# ================================================================
# Figure_9 的出图

import os
import numpy as np
import pandas as pd
import shap
import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import matplotlib.text as mtext

from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.svm import SVR
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score

from xgboost import XGBRegressor
from lightgbm import LGBMRegressor


# ---------------------------
# 0. 全局设置（SCI 绘图风格）
# ---------------------------

# Windows 下显式注册 Arial，避免 Matplotlib 找不到字体后回退到 Times New Roman
arial_path = r"C:\Windows\Fonts\arial.ttf"
arial_bold_path = r"C:\Windows\Fonts\arialbd.ttf"

if os.path.exists(arial_path):
    fm.fontManager.addfont(arial_path)

if os.path.exists(arial_bold_path):
    fm.fontManager.addfont(arial_bold_path)

plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial"],
    "font.size": 12,
    "font.weight": "bold",
    "axes.labelweight": "bold",
    "axes.titleweight": "bold",
    "axes.unicode_minus": False,

    # 保存 PDF / PS / SVG 时避免字体被替换
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.fonttype": "none",

    # 数学符号也尽量使用 Arial 风格
    "mathtext.fontset": "custom",
    "mathtext.rm": "Arial",
    "mathtext.it": "Arial:italic",
    "mathtext.bf": "Arial:bold",
})

print("Matplotlib 当前使用字体：", fm.findfont("Arial"))


def force_arial_font(fig, font_name="Arial", font_weight="bold"):
    """
    强制将整张图中的所有文字对象统一设置为 Arial。
    主要用于修正 shap.summary_plot() 自动生成的文字不继承 rcParams 的问题。
    """
    for text in fig.findobj(match=mtext.Text):
        text.set_fontfamily(font_name)
        text.set_fontweight(font_weight)

    for ax in fig.axes:
        ax.title.set_fontfamily(font_name)
        ax.title.set_fontweight(font_weight)

        ax.xaxis.label.set_fontfamily(font_name)
        ax.xaxis.label.set_fontweight(font_weight)

        ax.yaxis.label.set_fontfamily(font_name)
        ax.yaxis.label.set_fontweight(font_weight)

        for label in ax.get_xticklabels():
            label.set_fontfamily(font_name)
            label.set_fontweight(font_weight)

        for label in ax.get_yticklabels():
            label.set_fontfamily(font_name)
            label.set_fontweight(font_weight)


# ================================================================
# 1. 读取数据（不使用 Month）
# ================================================================
try:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
except NameError:
    BASE_DIR = r"F:\机器学习\XGB"

print("当前工作目录:", BASE_DIR)

input_file_path = os.path.join(BASE_DIR, "FloodInventory_All_Normalized_city20.xlsx")

if not os.path.exists(input_file_path):
    raise FileNotFoundError(f"找不到数据文件: {input_file_path}")

df = pd.read_excel(input_file_path)

indicator_cols = [
    "Disaster-affected area(thousand hectares)",
    "Number of people affected(ten thousand)",
    "Economic losses(ten thousand yuan)",
    "Online popularity(Daily average)",
    "Citywide deaths"
]

# 只要 5 指标全为空才删
df.dropna(subset=indicator_cols, how="all", inplace=True)

# 如果确认缺失值代表 0，可保持 0；否则建议改成 median 填充
df[indicator_cols] = df[indicator_cols].fillna(0)

df.replace([np.inf, -np.inf], 0, inplace=True)

data = df[indicator_cols].copy()


# ================================================================
# 2. AHP 权重
# ================================================================
AHP_matrix = np.array([
    [1, 2, 3, 3, 4],
    [1 / 2, 1, 2, 2, 3],
    [1 / 3, 1 / 2, 1, 2, 2],
    [1 / 3, 1 / 2, 1 / 2, 1, 1],
    [1 / 4, 1 / 3, 1 / 2, 1, 1]
], dtype=float)

eigvals, eigvecs = np.linalg.eig(AHP_matrix)
w = np.real(eigvecs[:, np.argmax(eigvals)])
AHP_weights = w / w.sum()

df["AHP_Expert_Index"] = (data * AHP_weights).sum(axis=1)


# ================================================================
# 3. 熵权法
# ================================================================
norm = (data - data.min()) / (data.max() - data.min() + 1e-9)

k = 1 / np.log(len(norm) + 1e-9)
p = norm / (norm.sum(axis=0) + 1e-9)

entropy = -k * (p * np.log(p + 1e-9)).sum(axis=0)
d = 1 - entropy
ent_weights = d / d.sum()

df["Entropy_Expert_Index"] = (data * ent_weights).sum(axis=1)


# ================================================================
# 4. 综合指数
# ================================================================
df["Final_Severity_Score"] = (
    df["AHP_Expert_Index"] + df["Entropy_Expert_Index"]
) / 2

df.to_excel(
    os.path.join(BASE_DIR, "Final_Severity_Score_Result_noMonth.xlsx"),
    index=False
)

X = df[indicator_cols].copy()
y_AHP = df["AHP_Expert_Index"].copy()
y_ENT = df["Entropy_Expert_Index"].copy()

scaler = StandardScaler()
X_std = scaler.fit_transform(X)


# ================================================================
# 5. 6 模型混合集成
# ================================================================
def get_ensemble_pred(y_target, X_raw, X_scaled):
    preds = []

    # 1) RF
    rf = RandomForestRegressor(
        n_estimators=300,
        random_state=42,
        n_jobs=-1
    )
    preds.append(rf.fit(X_raw, y_target).predict(X_raw))

    # 2) XGB
    xgb = XGBRegressor(
        n_estimators=300,
        random_state=42,
        max_depth=4,
        learning_rate=0.05,
        subsample=0.9,
        colsample_bytree=0.9
    )
    preds.append(xgb.fit(X_raw, y_target).predict(X_raw))

    # 3) LGBM
    lgbm = LGBMRegressor(
        n_estimators=300,
        random_state=42,
        learning_rate=0.05,
        num_leaves=31,
        subsample=0.9,
        colsample_bytree=0.9
    )
    preds.append(lgbm.fit(X_raw, y_target).predict(X_raw))

    # 4) GBDT
    gbdt = GradientBoostingRegressor(random_state=42)
    preds.append(gbdt.fit(X_raw, y_target).predict(X_raw))

    # 5) MLP，标准化输入
    mlp = MLPRegressor(
        hidden_layer_sizes=(64, 32),
        max_iter=2000,
        random_state=42
    )
    preds.append(mlp.fit(X_scaled, y_target).predict(X_scaled))

    # 6) SVR，标准化输入
    svr = SVR()
    preds.append(svr.fit(X_scaled, y_target).predict(X_scaled))

    return np.mean(np.vstack(preds), axis=0)


print("正在训练 6 模型集成...")

ensemble_AHP = get_ensemble_pred(y_AHP, X, X_std)
ensemble_ENT = get_ensemble_pred(y_ENT, X, X_std)


# ================================================================
# 6. Proxy 模型 + fidelity 检验（R²）
# ================================================================
proxy_AHP = RandomForestRegressor(
    n_estimators=500,
    random_state=42,
    n_jobs=-1
)

proxy_ENT = RandomForestRegressor(
    n_estimators=500,
    random_state=42,
    n_jobs=-1
)

# AHP proxy fidelity
X_tr, X_te, y_tr, y_te = train_test_split(
    X,
    ensemble_AHP,
    test_size=0.2,
    random_state=42
)

proxy_AHP.fit(X_tr, y_tr)
r2_ahp = r2_score(y_te, proxy_AHP.predict(X_te))

# Entropy proxy fidelity
X_tr2, X_te2, y_tr2, y_te2 = train_test_split(
    X,
    ensemble_ENT,
    test_size=0.2,
    random_state=42
)

proxy_ENT.fit(X_tr2, y_tr2)
r2_ent = r2_score(y_te2, proxy_ENT.predict(X_te2))

print(f"Proxy fidelity (R²) - AHP: {r2_ahp:.4f} | Entropy: {r2_ent:.4f}")

# 用全量数据重训 proxy，用于最终 SHAP
proxy_AHP.fit(X, ensemble_AHP)
proxy_ENT.fit(X, ensemble_ENT)


# ================================================================
# 6.5 SHAP 计算
# ================================================================
pretty_names = [
    "Affected area",
    "Affected population",
    "Economic losses",
    "Online popularity",
    "Fatalities"
]

X_plot = X.copy()
X_plot.columns = pretty_names

explainer_AHP = shap.TreeExplainer(proxy_AHP)
shap_AHP = explainer_AHP.shap_values(X_plot)

explainer_ENT = shap.TreeExplainer(proxy_ENT)
shap_ENT = explainer_ENT.shap_values(X_plot)


# ================================================================
# 7. SHAP 双图
# ================================================================

# 统一排序
order = np.argsort(np.mean(np.abs(shap_AHP), axis=0))[::-1]

# 统一 x 轴范围
max_abs = max(np.abs(shap_AHP).max(), np.abs(shap_ENT).max())
xlim = (-max_abs * 1.05, max_abs * 1.05)

# 不要 sharey=True，SHAP 会改 y 轴，sharey 容易把标签同步搞没
fig, axes = plt.subplots(
    1,
    2,
    figsize=(18, 8),
    sharey=False
)

# ---- 左图：AHP ----
plt.sca(axes[0])

shap.summary_plot(
    shap_AHP[:, order],
    X_plot.iloc[:, order],
    plot_type="dot",
    show=False,
    color_bar=False
)

axes[0].set_title(
    "(a) AHP hybrid model",
    fontsize=12,
    fontweight="bold",
    fontfamily="Arial"
)

axes[0].set_xlim(xlim)
axes[0].axvline(0, linewidth=1.2)
axes[0].set_xlabel("")

# 设置坐标轴刻度标签字体
axes[0].tick_params(axis="both", which="major", labelsize=10)
axes[0].tick_params(axis="both", which="minor", labelsize=10)

# 手动设置刻度标签加粗 + Arial
for label in axes[0].get_xticklabels():
    label.set_weight("bold")
    label.set_fontfamily("Arial")

for label in axes[0].get_yticklabels():
    label.set_weight("bold")
    label.set_fontfamily("Arial")

# 强制把左侧 yticklabels 写回去
labels_left = [X_plot.columns[i] for i in order]

# 设置坐标轴框线加粗
for spine in axes[0].spines.values():
    spine.set_linewidth(1.5)

# 确保左侧标签可见、加粗、Arial
axes[0].set_yticks(np.arange(len(labels_left)))
axes[0].set_yticklabels(
    labels_left,
    fontsize=10,
    fontweight="bold",
    fontfamily="Arial"
)


# ---- 右图：Entropy ----
plt.sca(axes[1])

shap.summary_plot(
    shap_ENT[:, order],
    X_plot.iloc[:, order],
    plot_type="dot",
    show=False,
    color_bar=False
)

axes[1].set_title(
    "(b) Entropy hybrid model",
    fontsize=12,
    fontweight="bold",
    fontfamily="Arial"
)

axes[1].set_xlim(xlim)
axes[1].axvline(0, linewidth=1.2)
axes[1].set_xlabel("")

# 设置坐标轴刻度标签字体
axes[1].tick_params(axis="both", which="major", labelsize=10)
axes[1].tick_params(axis="both", which="minor", labelsize=10)

# 手动设置刻度标签加粗 + Arial
for label in axes[1].get_xticklabels():
    label.set_weight("bold")
    label.set_fontfamily("Arial")

for label in axes[1].get_yticklabels():
    label.set_weight("bold")
    label.set_fontfamily("Arial")

# 设置坐标轴框线加粗
for spine in axes[1].spines.values():
    spine.set_linewidth(1.5)

# 右图隐藏 y 轴因子说明
axes[1].set_yticks(np.arange(len(labels_left)))
axes[1].set_yticklabels([""] * len(labels_left))
axes[1].set_ylabel("")


# 全局 x 轴标题
fig.text(
    0.52,
    0.04,
    "SHAP value (impact on model output)",
    ha="center",
    va="center",
    fontsize=12,
    fontweight="bold",
    fontfamily="Arial"
)

# 调整布局
fig.subplots_adjust(
    left=0.30,
    right=0.95,
    bottom=0.15,
    top=0.88,
    wspace=0.25
)


# ================================================================
# 8. 保存前再次强制统一字体为 Arial
# ================================================================
force_arial_font(fig, font_name="Arial", font_weight="bold")


# ================================================================
# 9. 保存图片
# ================================================================
out_fig = os.path.join(BASE_DIR, "SHAP_Final_Adjusted_v4_Arial.png")

plt.savefig(
    out_fig,
    dpi=300,
    bbox_inches="tight"
)

plt.show()

print(f"图片已保存至: {out_fig}")