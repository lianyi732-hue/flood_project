import joblib
import pandas as pd
import xgboost as xgb
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import MinMaxScaler
# 步骤1：从sklearn.metrics中同时导入r2_score和mean_squared_error
from sklearn.metrics import r2_score, mean_squared_error
import matplotlib.pyplot as plt

# --- 1. 数据加载与准备 ---
try:
    # 使用 pd.read_excel 来正确读取 .xlsx 文件
    file_path = 'FloodInventory_All_Normalized_city20.xlsx'
    data = pd.read_excel(file_path)
    print(f"成功加载Excel文件: '{file_path}'")
except FileNotFoundError:
    # 备用文件名，以防用户上传的文件名被更改
    try:
        file_path = 'FloodInventory_All_Normalized_city20.xlsx'
        data = pd.read_excel(file_path)
        print(f"成功加载Excel文件: '{file_path}'")
    except FileNotFoundError:
        print(f"错误：未找到洪水数据文件。请确保 'FloodInventory_All_Normalized_city20.xlsx' 与脚本在同一目录下。")
        exit()
except Exception as e:
    print(f"读取Excel文件时发生错误: {e}")
    print("请确保你安装了读取Excel所需的库，如 'openpyxl'。可以运行: pip install openpyxl")
    exit()

# 清理列名，去除可能存在的首尾空格
data.columns = data.columns.str.strip()

# 定义您关心的五个指标
factor_columns = [
    'Number of people affected(ten thousand)',
    'Citywide deaths',
    'Disaster-affected area(thousand hectares)',
    'Economic losses(ten thousand yuan)',
    'Online popularity(Daily average)'
]

# 检查关键列是否存在
missing_cols = [col for col in factor_columns if col not in data.columns]
if missing_cols:
    print(f"\n错误：数据中缺少以下关键列: {missing_cols}")
    exit()

# 删除包含缺失值的行
data_factors = data[factor_columns].dropna()
print(f"数据清理完成，用于分析的记录共有 {len(data_factors)} 条。")


# --- 2. 特征工程与目标变量创建 ---
# 使用对数变换来减少极端值的影响，这通常能提升树模型的性能
print("\n正在对特征数据进行对数变换以减少偏度...")
X_features = data_factors.apply(np.log1p)

# 创建一个综合的“洪水严重性指数”作为预测目标
# 首先将变换后的特征归一化到0-1之间
scaler = MinMaxScaler()
factors_scaled = scaler.fit_transform(X_features)

# 然后将归一化后的指标相加，得到严重性指数
y_target = np.sum(factors_scaled, axis=1)

print("已成功创建“洪水严重性指数”作为模型预测目标。")


# --- 3. 划分训练集和测试集 ---
# 注意：XGBoost等树模型对数据标准化不敏感，所以我们不需要StandardScaler
x_train, x_test, y_train, y_test = train_test_split(X_features, y_target, random_state=42, test_size=0.3)


# --- 4. 使用GridSearchCV寻找最佳XGBoost回归器 ---
# 关键：使用 XGBRegressor 进行回归任务
estimator = xgb.XGBRegressor(objective='reg:squarederror', eval_metric='rmse')

# 定义参数网格
param_grid = {
    'n_estimators': [100, 200],
    'max_depth': [3, 5, 7],
    'learning_rate': [0.05, 0.1],
    'gamma': [0, 0.1],
    'random_state': [42]
}

print("\n正在使用GridSearchCV进行XGBoost回归模型参数调优...")
# 对于回归任务，评分标准应使用 'r2'
grid_search = GridSearchCV(estimator, param_grid, cv=5, scoring='r2', n_jobs=-1)
grid_search.fit(x_train, y_train)

# 获取最佳模型
best_estimator = grid_search.best_estimator_
print(f"参数调优完成，找到的最佳参数为: {grid_search.best_params_}")


# --- 5. 提取并展示特征重要性（权重） ---
importances = best_estimator.feature_importances_

importance_df = pd.DataFrame({
    '指标 (Factor)': factor_columns,
    '重要性 (Importance)': importances
}).sort_values(by='重要性 (Importance)', ascending=False)

total_importance = importance_df['重要性 (Importance)'].sum()
if total_importance > 0:
    importance_df['重要性百分比 (Weight %)'] = (importance_df['重要性 (Importance)'] / total_importance * 100).round(2)
else:
    importance_df['重要性百分比 (Weight %)'] = 0.0


# --- 6. 展示最终结果与模型评估 ---
print('\n\n====== 各项洪水影响指标的权重分析结果 (XGBoost模型) ======')
print(importance_df[['指标 (Factor)', '重要性百分比 (Weight %)']])

# 评估模型性能
y_pred = best_estimator.predict(x_test)
r2 = r2_score(y_test, y_pred)
# 步骤2：计算均方误差 (MSE)
mse = mean_squared_error(y_test, y_pred)

print('\n--- 模型性能评估 ---')
print(f'R² 分数: {r2:.4f}')
# 步骤3：打印MSE结果
print(f'均方误差 (MSE): {mse:.4f}')
print(f'(R²分数越接近1，说明XGBoost模型越能解释数据的变异，特征重要性的结果也越可靠)')


# 可视化展示
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
plt.figure(figsize=(12, 8))
plt.barh(importance_df['指标 (Factor)'], importance_df['重要性 (Importance)'], color='darkgreen')
plt.xlabel('特征重要性 (Gain)', fontsize=14)
plt.ylabel('影响指标', fontsize=14)
plt.title('XGBoost模型分析：各影响指标的权重', fontsize=16)
plt.gca().invert_yaxis()
plt.grid(axis='x', linestyle='--', alpha=0.7)

# 保存模型
joblib.dump(best_estimator, 'xgboost_flood_model.pkl')
print("\n最佳XGBoost回归模型已保存为 'xgboost_flood_model.pkl'")

plt.show()
