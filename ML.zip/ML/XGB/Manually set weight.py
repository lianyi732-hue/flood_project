 #这个代码是将死亡人数的权重设定成0.8  其他的根据熵权法计算权重 最终得到每一个洪涝事件的评级

import pandas as pd
import numpy as np

# ==============================================================================
# --- 1. 用户配置区 ---
# ==============================================================================
# 在这里，您可以手动设定您最关心指标的权重
FIXED_FACTOR = 'Citywide deaths'
FIXED_WEIGHT = 0.8  # 您可以根据需要调整，例如 0.7, 0.8, 0.9

# ==============================================================================
# --- 2. 数据加载与准备 ---
# ==============================================================================
try:
    file_path = 'FloodInventory_All_Normalized_city20.xlsx'
    data = pd.read_excel(file_path)
    print(f"✅ 成功加载Excel文件: '{file_path}'")
except Exception as e:
    print(f"读取Excel文件时发生错误: {e}")
    exit()

data.columns = data.columns.str.strip()
factor_columns = [
    'Number of people affected(ten thousand)',
    'Citywide deaths',
    'Disaster-affected area(thousand hectares)',
    'Economic losses(ten thousand yuan)',
    'Online popularity(Daily average)'
]
data_factors = data[factor_columns].dropna()

# 归一化数据，用于计算权重和最终得分
from sklearn.preprocessing import MinMaxScaler

scaler = MinMaxScaler()
data_normalized = pd.DataFrame(scaler.fit_transform(data_factors), columns=factor_columns)

# ==============================================================================
# --- 3. 计算最终混合权重 ---
# ==============================================================================
print(f"\n正在构建混合权重，其中 '{FIXED_FACTOR}' 的权重被固定为 {FIXED_WEIGHT}...")


# --- a) 计算熵权法权重，作为分配基础 ---
def calculate_entropy_weights(df):
    p = df / df.sum(axis=0)
    p[p == 0] = 1e-10
    k = 1 / np.log(df.shape[0])
    e = -k * (p * np.log(p)).sum(axis=0)
    d = 1 - e
    return d / d.sum()


entropy_weights = calculate_entropy_weights(data_normalized)

# --- b) 分配剩余权重 ---
remaining_weight_total = 1 - FIXED_WEIGHT
# 选出除固定权重因子外的其他因子
other_factors = [col for col in factor_columns if col != FIXED_FACTOR]
# 计算这些其他因子的原始熵权法权重总和
other_factors_entropy_sum = entropy_weights[other_factors].sum()

# 构建最终权重
final_weights = {}
final_weights[FIXED_FACTOR] = FIXED_WEIGHT
for factor in other_factors:
    # 按比例分配
    proportion = entropy_weights[factor] / other_factors_entropy_sum
    final_weights[factor] = remaining_weight_total * proportion

final_weights_series = pd.Series(final_weights, name="Final_Hybrid_Weight")

print("\n" + "=" * 60)
print("--- 最终构建的混合权重 ---")
print(final_weights_series.sort_values(ascending=False))
print(f"权重总和: {final_weights_series.sum():.2f}")  # 验证总和是否为1
print("=" * 60)

# ==============================================================================
# --- 4. 使用新权重计算最终严重性得分并保存 ---
# ==============================================================================
print("\n正在使用新的混合权重计算最终的洪水严重性得分...")

# 使用 .values 确保矩阵乘法
final_scores = np.dot(data_normalized.values, final_weights_series[data_normalized.columns].values)

# 将最终得分添加回原始数据框
data_with_scores = data_factors.copy()
# 将其他信息也加回来
for col in ['Year', 'City', 'County']:
    if col in data.columns:
        data_with_scores[col] = data[col]

data_with_scores['Final_Severity_Score'] = final_scores

# 保存结果
output_filename = 'Final_Severity_Scores_Expert_Weighted.xlsx'
try:
    data_with_scores.to_excel(output_filename, index=False)
    print(f"\n✅ 包含最终严重性得分的文件已成功保存到: '{output_filename}'")
except Exception as e:
    print(f"\n❌ 保存文件时出错: {e}")