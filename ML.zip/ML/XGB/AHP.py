#代码的作用是进行AHP权重计算，在进行一致性检验，计算出CR值。

import numpy as np
import pandas as pd


def ahp_weight_calculation(judgment_matrix):
    """
    接收一个AHP的判断矩阵，计算权重向量并进行一致性检验。

    参数:
    judgment_matrix (numpy.ndarray): N x N 的方阵，代表两两比较的结果。

    返回:
    tuple: (权重向量, 一致性比率CR) 或 (None, None) 如果矩阵无效。
    """
    n = judgment_matrix.shape[0]
    if n != judgment_matrix.shape[1]:
        print("错误：判断矩阵必须是方阵！")
        return None, None

    # --- 步骤 1: 权重计算 (和法/方根法的一种近似计算) ---

    # 1a. 将判断矩阵的每一列进行归一化 (每个元素除以其所在列的和)
    col_sums = judgment_matrix.sum(axis=0)
    normalized_matrix = judgment_matrix / col_sums

    # 1b. 将归一化后的矩阵按行求和
    row_sums = normalized_matrix.sum(axis=1)

    # 1c. 将行和向量进行归一化，得到权重向量
    weights = row_sums / n

    # --- 步骤 2: 一致性检验 ---

    # 2a. 计算最大特征根 lambda_max
    # AW = 判断矩阵 * 权重向量
    AW = np.dot(judgment_matrix, weights)
    lambda_max = np.mean(AW / weights)

    # 2b. 计算一致性指标 CI (Consistency Index)
    CI = (lambda_max - n) / (n - 1)

    # 2c. 查找随机一致性指标 RI (Random Inconsistency Index)
    # RI值是固定的，由Saaty教授通过大量实验得出
    RI_dict = {
        1: 0.00, 2: 0.00, 3: 0.58, 4: 0.90, 5: 1.12,
        6: 1.24, 7: 1.32, 8: 1.41, 9: 1.45, 10: 1.49,
        11: 1.51, 12: 1.54, 13: 1.56, 14: 1.57, 15: 1.59
    }
    RI = RI_dict.get(n)
    if RI is None:
        print(f"错误：阶数n={n}过大，未找到对应的RI值。")
        return weights, None

    # 2d. 计算一致性比率 CR (Consistency Ratio)
    # 只有当RI不为0时才计算
    CR = CI / RI if RI != 0 else 0

    return weights, CR


# ==============================================================================
# --- 主程序 ---
# ==============================================================================

# --- 1. 定义评价准则 (您的5个因子) ---
criteria = [
    'Citywide deaths',
    'Economic losses(ten thousand yuan)',
    'Number of people affected(ten thousand)',
    'Disaster-affected area(thousand hectares)',
    'Online popularity(Daily average)'
]
n_criteria = len(criteria)

# --- 2. 构建判断矩阵 ---
# !! 重要 !!: 这是AHP的核心，需要您邀请专家，根据1-9标度法进行两两比较打分。
# 这里的数值是我为了演示，根据您“想强调死亡人数和经济损失”的偏好而设定的示例。
# 矩阵的解读方式：行因素相对于列因素的重要性。例如，第一行第二列的 3.0 代表
# 'Citywide deaths' 比 'Economic losses' “稍微重要”。
judgment_matrix = np.array([
    # Deaths, EconLoss, People, Area,   Popularity
    [1.0, 3.0, 5.0, 5.0, 7.0],  # Citywide deaths
    [1 / 3, 1.0, 3.0, 3.0, 5.0],  # Economic losses
    [1 / 5, 1 / 3, 1.0, 1.0, 3.0],  # Number of people affected
    [1 / 5, 1 / 3, 1.0, 1.0, 3.0],  # Disaster-affected area
    [1 / 7, 1 / 5, 1 / 3, 1 / 3, 1.0]  # Online popularity
])

print("--- 专家判断矩阵 ---")
print(pd.DataFrame(judgment_matrix, index=criteria, columns=criteria))

# --- 3. 执行AHP分析 ---
weights, CR = ahp_weight_calculation(judgment_matrix)

# --- 4. 显示结果 ---
if weights is not None:
    print("\n" + "=" * 50)
    print("--- AHP分析结果 ---")




    # 显示权重
    weights_series = pd.Series(weights, index=criteria, name="Weights")
    print("\n计算出的各指标权重:")
    print(weights_series.sort_values(ascending=False))

    # 显示一致性检验结果
    print(f"\n一致性比率 (CR): {CR:.4f}")

    # 给出最终判断
    if CR < 0.10:
        print("✅ 一致性检验通过 (CR < 0.1)。权重结果有效，可以使用。")
    else:
        print("❌ 一致性检验失败 (CR >= 0.1)。")
        print("说明判断矩阵中的专家打分存在逻辑矛盾，建议重新审视和调整判断矩阵。")
    print("=" * 50)