# 生成中国20城市历年洪水平均严重等级热力图（最终版式微调） Figure_6的出图

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.neural_network import MLPClassifier

# =========================
# 字体与尺寸配置
# =========================
FONT_FAMILY = 'Times New Roman'
AXIS_LABEL_SIZE = 22
TICK_LABEL_SIZE = 22
ANNOT_SIZE = 22
CBAR_LABEL_SIZE = 22
CBAR_TICK_SIZE = 22

plt.rcParams['font.family'] = FONT_FAMILY
plt.rcParams['font.size'] = TICK_LABEL_SIZE
plt.rcParams['axes.unicode_minus'] = False

# =========================
# 读取数据
# =========================
file_path = 'FloodInventory_All_Normalized_city20.xlsx'
data = pd.read_excel(file_path)
data.columns = data.columns.str.strip()

factor_columns = [
    'Number of people affected(ten thousand)',
    'Citywide deaths',
    'Disaster-affected area(thousand hectares)',
    'Economic losses(ten thousand yuan)',
    'Online popularity(Daily average)'
]

data.dropna(subset=factor_columns, inplace=True)

data['City'] = (
    data['City'].astype(str)
    .str.replace(' City', '', regex=False)
    .str.replace('市', '', regex=False)
    .str.strip()
)

# =========================
# 模型与分级
# =========================
X = StandardScaler().fit_transform(data[factor_columns])
y_reg = MinMaxScaler().fit_transform(data[factor_columns]).sum(axis=1)
y_cls = pd.qcut(y_reg, q=5, labels=False, duplicates='drop')

model = MLPClassifier(
    random_state=42,
    max_iter=2000,
    hidden_layer_sizes=(100, 50)
)
model.fit(X, y_cls)
data['Predicted_Severity_Class'] = model.predict(X)

# =========================
# 年度平均
# =========================
annual_severity = (
    data.groupby(['City', 'Year'])['Predicted_Severity_Class']
    .mean()
    .reset_index(name='Avg_Severity_Class')
)

pivot_data = annual_severity.pivot(
    index='City',
    columns='Year',
    values='Avg_Severity_Class'
)

city_order = pivot_data.mean(axis=1).sort_values(ascending=False).index
pivot_data = pivot_data.loc[city_order]

# =========================
# 绘图
# =========================
sns.set_style("whitegrid")
fig, ax = plt.subplots(figsize=(20, 12))

heatmap = sns.heatmap(
    pivot_data,
    ax=ax,
    cmap='Reds',
    annot=True,
    fmt=".1f",
    linewidths=0.5,
    linecolor='lightgray',
    vmin=0,
    vmax=4,
    cbar_kws={'label': 'Average Severity Level (0–4)'},
    annot_kws={
        'fontsize': ANNOT_SIZE,
        'fontfamily': FONT_FAMILY   # ❗ 不再加粗
    }
)

# 坐标轴标题
ax.set_xlabel('Year', fontsize=AXIS_LABEL_SIZE, fontweight='bold')
ax.set_ylabel('City', fontsize=AXIS_LABEL_SIZE, fontweight='bold')

# =========================
# 刻度设置（关键修改点）
# =========================
ax.tick_params(axis='x', labelsize=TICK_LABEL_SIZE)
ax.tick_params(axis='y', labelsize=TICK_LABEL_SIZE)

for tick in ax.get_xticklabels():
    tick.set_rotation(45)              # ✅ 横坐标倾斜 45°
    tick.set_ha('right')
    tick.set_fontfamily(FONT_FAMILY)
    tick.set_fontweight('bold')

for tick in ax.get_yticklabels():
    tick.set_rotation(0)
    tick.set_fontfamily(FONT_FAMILY)
    tick.set_fontweight('bold')

# =========================
# colorbar
# =========================
cbar = heatmap.collections[0].colorbar
cbar.set_label(
    'Average Severity Level (0–4)',
    fontsize=CBAR_LABEL_SIZE,
    fontweight='bold',
    fontfamily=FONT_FAMILY
)
cbar.ax.tick_params(labelsize=CBAR_TICK_SIZE)
for tick in cbar.ax.get_yticklabels():
    tick.set_fontfamily(FONT_FAMILY)
    tick.set_fontweight('bold')

plt.tight_layout()
plt.savefig('city_year_severity_heatmap.png', dpi=300, bbox_inches='tight')
plt.show()
