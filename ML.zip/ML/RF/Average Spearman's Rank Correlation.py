import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np

# =========================
# Font settings
# =========================
FONT_FAMILY = "Times New Roman"
FONT_WEIGHT = "bold"
AXIS_FONT_SIZE = 12      # x/y ticks
ANNOT_FONT_SIZE = 18     # inside cells

plt.rcParams.update({
    "font.family": FONT_FAMILY,
    "axes.unicode_minus": False
})
sns.set_theme(style="white")

# =========================
# Data config
# =========================
datasets = [
    ("Flood_Severity_Scores_Final_Weighs_AHP.xlsx", "(1) AHP"),
    ("Flood_Severity_Scores_Final_Weighs_Entropy.xlsx", "(2) Entropy Weight")
]
score_columns = [
    "Score_GBDT", "Score_XGBoost", "Score_RF",
    "Score_SVM", "Score_LightGBM", "Score_MLP"
]

corr_mats = []
for file_path, _ in datasets:
    df = pd.read_excel(file_path, engine="openpyxl")
    corr_mats.append(df[score_columns].corr(method="spearman"))

# =========================
# Plot settings
# =========================
VMIN, VMAX = 0.96, 1.00
CBAR_TICKS = np.arange(0.965, 1.001, 0.005)
CMAP = "Blues"

# --- Key layout change: dedicate a narrow axis for ONE shared colorbar ---
fig = plt.figure(figsize=(20, 8))
gs = fig.add_gridspec(1, 3, width_ratios=[1, 1, 0.04], wspace=0.15)

ax1 = fig.add_subplot(gs[0, 0])
ax2 = fig.add_subplot(gs[0, 1])
cax = fig.add_subplot(gs[0, 2])  # shared colorbar axis

axes = [ax1, ax2]

# Control margins: reduce bottom blank, avoid label collisions
fig.subplots_adjust(left=0.10, right=0.97, bottom=0.16, top=0.98)

# =========================
# Draw heatmaps (ONLY ax2 creates the colorbar on cax)
# =========================
for i, (ax, (_, panel_label), corr) in enumerate(zip(axes, datasets, corr_mats)):
    show_cbar = (i == 1)  # only right panel draws the single shared colorbar

    hm = sns.heatmap(
        corr,
        ax=ax,
        cmap=CMAP,
        vmin=VMIN,
        vmax=VMAX,
        annot=True,
        fmt=".3f",
        linewidths=0.5,
        linecolor="white",
        cbar=show_cbar,
        cbar_ax=cax if show_cbar else None,
        cbar_kws={"ticks": CBAR_TICKS} if show_cbar else None,
        annot_kws={"size": ANNOT_FONT_SIZE, "weight": FONT_WEIGHT, "family": FONT_FAMILY}
    )

    # X ticks: 0°
    ax.tick_params(axis="x", pad=6)
    for t in ax.get_xticklabels():
        t.set_rotation(0)
        t.set_ha("center")
        t.set_fontfamily(FONT_FAMILY)
        t.set_fontsize(AXIS_FONT_SIZE)
        t.set_fontweight(FONT_WEIGHT)

    # Y ticks: 90°
    ax.tick_params(axis="y", pad=6)
    for t in ax.get_yticklabels():
        t.set_rotation(90)
        t.set_va("center")
        t.set_ha("center")
        t.set_fontfamily(FONT_FAMILY)
        t.set_fontsize(AXIS_FONT_SIZE)
        t.set_fontweight(FONT_WEIGHT)

    # Panel label at bottom (inside figure margin, not stretching layout)
    ax.text(
        0.5, -0.14,
        panel_label,
        transform=ax.transAxes,
        ha="center",
        va="top",
        fontsize=ANNOT_FONT_SIZE,
        fontfamily=FONT_FAMILY,
        fontweight=FONT_WEIGHT
    )

# =========================
# Shared colorbar formatting (rotate 90°)
# =========================
cbar = ax2.collections[0].colorbar
cbar.ax.tick_params(labelsize=AXIS_FONT_SIZE, pad=6)

for t in cbar.ax.get_yticklabels():
    t.set_rotation(90)
    t.set_va("center")
    t.set_ha("center")
    t.set_fontfamily(FONT_FAMILY)
    t.set_fontsize(AXIS_FONT_SIZE)
    t.set_fontweight(FONT_WEIGHT)

# =========================
# Save
# =========================
out_png = "spearman_heatmap_AHP_vs_Entropy_shared_cbar_compact.png"
plt.savefig(out_png, dpi=300, bbox_inches="tight", pad_inches=0.05)
plt.show()

print(f"✅ 已压缩中间空白（共用一个 colorbar）：{out_png}")
