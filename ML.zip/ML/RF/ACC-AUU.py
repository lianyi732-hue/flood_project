#绘制学习曲线

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, learning_curve   # ← 新增 learning_curve
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.metrics import accuracy_score
import warnings
from sklearn.exceptions import ConvergenceWarning

# Models
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from xgboost import XGBClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC                                           # ← 新增 SVM
import lightgbm as lgb                                                # ← 新增 LightGBM

# --- 1. Load and Prepare Data ---
try:
    file_path = 'Flood_Severity_Scores_Final_Weighs_Entropy.xlsx'
    data = pd.read_excel(file_path)
    print(f"Successfully loaded Excel file: '{file_path}'")
except Exception as e:
    print(f"Error reading Excel file: {e}")
    exit()

data.columns = data.columns.str.strip()
factor_columns = [
    'Number of people affected(ten thousand)', 'Citywide deaths',
    'Disaster-affected area(thousand hectares)', 'Economic losses(ten thousand yuan)',
    'Online popularity(Daily average)'
]
data_factors = data[factor_columns].dropna()
X_features = data_factors.values

# Create regression and 5-class target variables
scaler_y = MinMaxScaler()
factors_scaled = scaler_y.fit_transform(data_factors)
y_reg = np.sum(factors_scaled, axis=1)
y_multi_class = pd.qcut(y_reg, q=5, labels=False, duplicates='drop')

# Standardize features
scaler_X = StandardScaler()
X_scaled = scaler_X.fit_transform(X_features)

# --- 2. Split into Training and Validation Sets ---
X_train, X_val, y_train, y_val = train_test_split(
    X_scaled, y_multi_class,
    test_size=0.2,
    random_state=42,
    stratify=y_multi_class
)
print(f"\nData split: {len(X_train)} training samples, {len(X_val)} validation samples")

# --- 3. Record and Plot Learning Curves ---
# 改为 3x2 共 6 个子图
fig, axes = plt.subplots(3, 2, figsize=(18, 18))
axes = axes.flatten()
fig.suptitle('Model Learning Curves (Train vs Validation Accuracy)', fontsize=20)

# --- A. MLP Learning Curve ---
ax = axes[0]
train_accs, val_accs = [], []
n_epochs = 100
mlp = MLPClassifier(random_state=42, warm_start=True, max_iter=1)

with warnings.catch_warnings():
    warnings.filterwarnings("ignore", category=ConvergenceWarning, module="sklearn")
    for epoch in range(n_epochs):
        mlp.fit(X_train, y_train)
        train_accs.append(accuracy_score(y_train, mlp.predict(X_train)))
        val_accs.append(accuracy_score(y_val, mlp.predict(X_val)))

ax.plot(range(1, n_epochs + 1), train_accs, 'o-', label='Train ACC')
ax.plot(range(1, n_epochs + 1), val_accs, 's-', label='Val ACC')
ax.set_title('MLP Learning Curve', fontsize=16)
ax.set_xlabel('Epoch', fontsize=12)
ax.set_ylabel('Accuracy', fontsize=12)
ax.grid(True, linestyle='--', alpha=0.6)
ax.legend()

# --- B. GBDT Learning Curve ---
ax = axes[1]
train_accs, val_accs = [], []
n_estimators = 100
gbdt = GradientBoostingClassifier(random_state=42, n_estimators=n_estimators)
gbdt.fit(X_train, y_train)

for y_pred_train, y_pred_val in zip(gbdt.staged_predict(X_train),
                                    gbdt.staged_predict(X_val)):
    train_accs.append(accuracy_score(y_train, y_pred_train))
    val_accs.append(accuracy_score(y_val, y_pred_val))

ax.plot(range(1, n_estimators + 1), train_accs, 'o-', label='Train ACC')
ax.plot(range(1, n_estimators + 1), val_accs, 's-', label='Val ACC')
ax.set_title('GBDT Learning Curve', fontsize=16)
ax.set_xlabel('n_estimators', fontsize=12)
ax.set_ylabel('Accuracy', fontsize=12)
ax.grid(True, linestyle='--', alpha=0.6)
ax.legend()

# --- C. XGBoost Learning Curve ---
ax = axes[2]
xgb = XGBClassifier(
    random_state=42,
    n_estimators=100,
    eval_metric='merror'     # 多分类错误率
)
xgb.fit(
    X_train, y_train,
    eval_set=[(X_train, y_train), (X_val, y_val)],
    verbose=False
)
results = xgb.evals_result()
epochs = len(results['validation_0']['merror'])

train_accs = [1 - err for err in results['validation_0']['merror']]
val_accs = [1 - err for err in results['validation_1']['merror']]

ax.plot(range(1, epochs + 1), train_accs, 'o-', label='Train ACC')
ax.plot(range(1, epochs + 1), val_accs, 's-', label='Val ACC')
ax.set_title('XGBoost Learning Curve', fontsize=16)
ax.set_xlabel('Boosting Iteration', fontsize=12)
ax.set_ylabel('Accuracy', fontsize=12)
ax.grid(True, linestyle='--', alpha=0.6)
ax.legend()

# --- D. RF "Learning" Curve ---
ax = axes[3]
train_accs, val_accs = [], []
n_estimators_range = range(1, 101)
rf = RandomForestClassifier(random_state=42, warm_start=True)

for n in n_estimators_range:
    rf.set_params(n_estimators=n)
    rf.fit(X_train, y_train)
    train_accs.append(accuracy_score(y_train, rf.predict(X_train)))
    val_accs.append(accuracy_score(y_val, rf.predict(X_val)))

ax.plot(n_estimators_range, train_accs, 'o-', label='Train ACC')
ax.plot(n_estimators_range, val_accs, 's-', label='Val ACC')
ax.set_title('RF "Learning" Curve (vs n_estimators)', fontsize=16)
ax.set_xlabel('n_estimators', fontsize=12)
ax.set_ylabel('Accuracy', fontsize=12)
ax.grid(True, linestyle='--', alpha=0.6)
ax.legend()

# --- E. LightGBM Learning Curve ---
ax = axes[4]
eval_result = {}
num_classes = len(np.unique(y_train))

lgbm = lgb.LGBMClassifier(
    boosting_type='gbdt',
    n_estimators=100,
    objective='multiclass',
    num_class=num_classes,
    random_state=42
)

lgbm.fit(
    X_train, y_train,
    eval_set=[(X_train, y_train), (X_val, y_val)],
    eval_metric='multi_error',                # 多分类错误率
    callbacks=[lgb.record_evaluation(eval_result)]
)

# LightGBM 返回错误率，转成准确率
train_err = eval_result['training']['multi_error']
val_err = eval_result['valid_1']['multi_error']
train_accs = [1 - e for e in train_err]
val_accs = [1 - e for e in val_err]
epochs = len(train_accs)

ax.plot(range(1, epochs + 1), train_accs, 'o-', label='Train ACC')
ax.plot(range(1, epochs + 1), val_accs, 's-', label='Val ACC')
ax.set_title('LightGBM Learning Curve', fontsize=16)
ax.set_xlabel('Boosting Iteration', fontsize=12)
ax.set_ylabel('Accuracy', fontsize=12)
ax.grid(True, linestyle='--', alpha=0.6)
ax.legend()

# --- F. SVM Learning Curve (using sklearn.learning_curve) ---
ax = axes[5]

svm = SVC(
    kernel='rbf',
    C=1.0,
    gamma='scale',
    random_state=42
)

# 使用 learning_curve 画“训练样本量 vs 准确率”的学习曲线
train_sizes = np.linspace(0.1, 1.0, 20)
train_sizes_abs, train_scores, val_scores = learning_curve(
    svm,
    X_scaled,
    y_multi_class,
    train_sizes=train_sizes,
    cv=5,
    scoring='accuracy',
    shuffle=True,
    random_state=42
)

train_mean = train_scores.mean(axis=1)
val_mean = val_scores.mean(axis=1)

ax.plot(train_sizes_abs, train_mean, 'o-', label='Train ACC')
ax.plot(train_sizes_abs, val_mean, 's-', label='Val ACC')
ax.set_title('SVM Learning Curve', fontsize=16)
ax.set_xlabel('Training samples', fontsize=12)
ax.set_ylabel('Accuracy', fontsize=12)
ax.grid(True, linestyle='--', alpha=0.6)
ax.legend()

# --- Finalize and save the plot ---
plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.savefig('model_learning_curves_all_models.png', dpi=300)
print("\nAll model learning curve plots have been saved to 'model_learning_curves_all_models.png'")
plt.show()
