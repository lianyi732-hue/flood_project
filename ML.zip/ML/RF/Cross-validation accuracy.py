#交叉检验的代码

import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import KFold
from sklearn.metrics import r2_score

print("--- 开始进行交叉验证 ---")

# --- 1. 数据加载与准备 ---
try:
    file_path = 'FloodInventory_All_Normalized_city20.xlsx'
    data = pd.read_excel(file_path)
    print(f"成功加载Excel文件: '{file_path}'")
except FileNotFoundError:
    print(f"错误：未找到文件 '{file_path}'。")
    exit()

data.columns = data.columns.str.strip()
factor_columns = [
    'Number of people affected(ten thousand)',
    'Economic losses(ten thousand yuan)',
    'Online popularity(Daily average)',
    'Citywide deaths',
    'Disaster-affected area(thousand hectares)'
]
data_factors = data[factor_columns].dropna().copy()
print(f"数据清理完成，用于计算的记录共有 {len(data_factors)} 条。")

# --- 2. 定义最终模型权重 (将图片中的数值转换为小数形式) ---
model_weights = {
    'GBDT': {
        'Number of people affected(ten thousand)': 0.0846,
        'Economic losses(ten thousand yuan)': 0.0331,
        'Online popularity(Daily average)': 0.0520,
        'Citywide deaths': 0.0164,
        'Disaster-affected area(thousand hectares)': 0.8140
    },
    'XGBoost': {
        'Number of people affected(ten thousand)': 0.1066,
        'Economic losses(ten thousand yuan)': 0.1183,
        'Online popularity(Daily average)': 0.0417,
        'Citywide deaths': 0.0922,
        'Disaster-affected area(thousand hectares)': 0.6412
    },
    'RF': {
        'Number of people affected(ten thousand)': 0.0785,
        'Economic losses(ten thousand yuan)': 0.0277,
        'Online popularity(Daily average)': 0.0497,
        'Citywide deaths': 0.0159,
        'Disaster-affected area(thousand hectares)': 0.8282
    },
    'SVM': {
        'Number of people affected(ten thousand)': 0.1068,
        'Economic losses(ten thousand yuan)': 0.0333,
        'Online popularity(Daily average)': 0.0287,
        'Citywide deaths': 0.0383,
        'Disaster-affected area(thousand hectares)': 0.7929
    },
    'MLP': {
        'Number of people affected(ten thousand)': 0.2349,
        'Economic losses(ten thousand yuan)': 0.0173,
        'Online popularity(Daily average)': 0.0340,
        'Citywide deaths': 0.0689,
        'Disaster-affected area(thousand hectares)': 0.6449
    }
}
print("\n已加载图片中提供的最终模型权重（已转换为小数形式）。")

# --- 3. 数据预处理与目标变量定义 ---
data_log_transformed = data_factors.apply(np.log1p)
scaler = MinMaxScaler()
data_scaled = pd.DataFrame(scaler.fit_transform(data_log_transformed), columns=factor_columns, index=data_factors.index)
y_target = data_scaled.sum(axis=1).values
print("数据归一化处理完成，并已定义用于评估的目标变量。")

# --- 4. 设置并执行交叉验证 ---
N_SPLITS = 10
kf = KFold(n_splits=N_SPLITS, shuffle=True, random_state=42)

cv_results = {model_name: [] for model_name in model_weights.keys()}

print(f"\n--- 开始进行 {N_SPLITS}-折交叉验证 ---")
for fold, (train_index, test_index) in enumerate(kf.split(data_scaled)):
    X_test_fold = data_scaled.iloc[test_index]
    y_test_fold = y_target[test_index]

    for model_name, weights in model_weights.items():
        y_pred_fold = pd.Series(np.zeros(len(X_test_fold)), index=X_test_fold.index)
        for factor, weight in weights.items():
            if factor in X_test_fold.columns:
                y_pred_fold += X_test_fold[factor] * weight

        score = r2_score(y_test_fold, y_pred_fold.values)
        cv_results[model_name].append(score)

print("交叉验证计算完成。")

# --- 5. 汇总并展示最终结果 ---
print("\n--- 最终准确性评估结果 ---")
validation_summary_list = []
for model_name, scores in cv_results.items():
    validation_summary_list.append({
        'Model': model_name,
        'Mean_R2_Score': np.mean(scores),
        'Std_Dev_R2': np.std(scores)
    })

validation_summary = pd.DataFrame(validation_summary_list)
validation_summary = validation_summary.sort_values(by='Mean_R2_Score', ascending=False).reset_index(drop=True)

print(validation_summary)