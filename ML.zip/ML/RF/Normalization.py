#对数据做归一化处理，做了所有数据的归一化
# 导入所需的库
import pandas as pd
from sklearn.preprocessing import MinMaxScaler

# --- 1. 用户配置区 ---
# 请在这里修改你的文件路径和需要处理的列名

# 原始数据文件的完整路径
input_file_path = r'FloodInventory_Combined_beijing.csv'

# 处理后文件的保存路径
output_file_path = r'FloodInventory_All_Normalized_beijing.csv'

# 需要进行归一化处理的列的名称列表
columns_to_process = ['Economic losses(ten thousand yuan)', 'Online popularity(Daily average)', 'Number of people affected(ten thousand)', 'Citywide deaths', 'Disaster-affected area(thousand hectares)']


# --- 2. 加载数据 ---
try:
    # 【核心修正】在这里，我们明确指定使用 'gbk' 编码来读取文件
    df = pd.read_csv(input_file_path, encoding='gbk')
    print("✅ 数据加载成功！")
    print(f"数据形状: {df.shape}")
    print("\n原始数据前5行:")
    print(df.head())
except FileNotFoundError:
    print(f"❌ 错误：找不到文件 '{input_file_path}'。请检查文件路径是否正确。")
    exit() # 如果文件不存在，则停止脚本
except Exception as e:
    print(f"❌ 读取文件时发生错误: {e}")
    exit()

# --- 3. 执行归一化 ---
print(f"\n将对以下列进行 Min-Max 归一化处理 (缩放到 [0, 1] 区间): {columns_to_process}")

# 显示处理前目标列的统计信息
print("\n处理前，目标列的描述性统计:")
print(df[columns_to_process].describe())

# 初始化MinMaxScaler
scaler = MinMaxScaler(feature_range=(0, 1))

# 创建一个数据的副本，以保留原始数据不被修改
df_normalized = df.copy()

# 对指定列进行拟合和转换
df_normalized[columns_to_process] = scaler.fit_transform(df[columns_to_process])

print("\n✅ 整个数据集的 Min-Max 归一化处理完成！")


# --- 4. 显示和验证结果 ---
# 显示处理后目标列的统计信息
print("\n整个数据集归一化后，目标列的描述性统计:")
print(df_normalized[columns_to_process].describe())

# 显示处理后数据的前5行
print("\n整个数据集归一化后前5行 (仅显示被处理的列):")
print(df_normalized[columns_to_process].head())


# --- 5. 保存结果到新文件 ---
try:
    # encoding='utf-8-sig' 可以确保中文在Excel中打开时不会乱码
    df_normalized.to_csv(output_file_path, index=False, encoding='utf-8-sig')
    print(f"\n✅ 包含所有归一化数据的完整文件已保存为: {output_file_path}")
except Exception as e:
    print(f"\n❌ 保存文件时出错: {e}")