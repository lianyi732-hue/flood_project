#这个代码的作用是将城市水体面积和建成区面积与城市风险等级数据进行相关性分析

#目前我还没有水体面积数据 以及建成区面积 这部分还没有实现!!

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import pearsonr

# ==============================================================================
# --- 主程序 ---
# ==============================================================================
# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# --- 1. 准备数据 ---
# a) 从您的图片中手动录入水体数据
water_data = {
    'City': ['Beijing', 'Shanghai', 'Wuhan', 'Chengdu', 'Guangzhou', 'Hangzhou', 'Shenzhen', 'Nanjing',
             'Suzhou', 'Wuxi', 'Ningbo', 'Tianjin', 'Dalian', 'Shenyang', 'Jinan', 'Qingdao', 'Yantai',
             'Tangshan', 'Zhengzhou', 'Xi\'an'],
    '水域总面积(km^2)': [125.78, 482.51, 186.29, 95.34, 169.37, 219.86, 126.34, 175.05, 337.89, 164.73,
                      139.56, 174.92, 69.32, 115.79, 68.43, 75.16, 89.24, 98.67, 45.31, 58.93],
    '建成区面积(km^2)': [1401.00, 1563.45, 864.09, 996.57, 1347.53, 943.18, 937.16, 923.84, 814.76,
                       754.12, 732.89, 1247.38, 712.98, 831.25, 693.17, 789.23, 678.14, 654.32,
                       743.29, 698.45],
    '水体占比(%)': [8.98, 30.86, 21.56, 9.57, 12.57, 23.31, 13.48, 18.95, 41.47, 21.84, 19.04, 14.02,
                   9.72, 13.93, 9.87, 9.52, 13.16, 15.08, 6.09, 8.44]
}
water_df = pd.DataFrame(water_data)

# b) 加载您之前计算的城市风险分析结果
try:
    risk_df = pd.read_csv('city_flood_risk_analysis.csv')
    print("✅ 成功加载预计算的城市风险数据！")
except FileNotFoundError:
    print("❌ 错误：找不到 'city_flood_risk_analysis.csv' 文件。")
    print("请确保该文件与本脚本在同一目录下。")
    exit()

# c) 合并两个数据表
# 清理城市名格式以确保能成功匹配
risk_df['City'] = risk_df['City'].astype(str).str.replace(' City', '').str.replace('市', '').str.strip()
merged_df = pd.merge(risk_df, water_df, on='City', how='inner')

if merged_df.empty:
    print("❌ 错误：数据合并失败，没有匹配到任何城市。请检查两个文件中的城市名是否一致。")
    exit()

print(f"✅ 数据合并成功！共匹配到 {len(merged_df)} 个城市。")
print("\n--- 合并后的数据预览 ---")
print(merged_df.head())


# --- 2. 可视化探索：绘制散点图与回归线 ---
plt.figure(figsize=(12, 8))
# 使用seaborn的regplot可以同时绘制散点图和线性回归拟合线
sns.regplot(x='水体占比(%)', y='avg_severity_class', data=merged_df,
            scatter_kws={'s': 80, 'alpha': 0.7},  # 设置点的大小和透明度
            line_kws={'color': 'red', 'lw': 2}) # 设置线的颜色和宽度

# 在每个点旁边标注城市名
for i in range(merged_df.shape[0]):
    plt.text(merged_df['水体占比(%)'][i] + 0.5, merged_df['avg_severity_class'][i],
             merged_df['City'][i], fontsize=10)

plt.title('城市建成区水体占比 vs. 平均洪水严重等级', fontsize=18, pad=15)
plt.xlabel('建成区水体占比 (%)', fontsize=12)
plt.ylabel('平均洪水严重等级 (0-4)', fontsize=12)
plt.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()
plt.savefig('water_percentage_vs_severity.png', dpi=300)
print("\n✅ 关系探索图已保存为 'water_percentage_vs_severity.png'")
plt.show()


# --- 3. 统计关系检验：计算皮尔逊相关系数 ---
# 提取需要分析的两列数据
x = merged_df['水体占比(%)']
y = merged_df['avg_severity_class']

# 计算相关系数和p值
corr, p_value = pearsonr(x, y)

print("\n--- 统计检验结果 ---")
print(f"皮尔逊相关系数 (Pearson Correlation): {corr:.4f}")
print(f"P值 (P-value): {p_value:.4f}")

# 解读结果
if p_value < 0.05:
    print("\n统计显著性：P值小于0.05，表明两者之间的相关关系在统计上是显著的。")
    if corr > 0:
        print("关系解读：存在显著的正相关关系。即，建成区水体占比较高的城市，其平均洪水严重等级也倾向于较高。这可能支持“暴露风险”假说。")
    elif corr < 0:
        print("关系解读：存在显著的负相关关系。即，建成区水体占比较高的城市，其平均洪水严重等级倾向于较低。这可能支持“海绵城市”假说。")
    else:
        print("关系解读：相关系数接近于0，关系不强。")
else:
    print("\n统计显著性：P值大于或等于0.05，我们不能认为两者之间存在显著的线性相关关系。")