#这个代码用于生成柱状图，也是一个分组对比图
#第二组图生成了两张年度趋势图（AHP 和Entropy）

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.ticker import MaxNLocator  # 导入我们需要的智能刻度工具

# 设置英文字体 - 新罗马字体，统一使用12号字体
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 12  # 所有字体统一设为12号
plt.rcParams['axes.unicode_minus'] = False

# ==============================================================================
# --- 1. 数据加载 ---
# ==============================================================================
# 加载两个数据集：AHP和Entropy
ahp_file_path = 'Flood_Severity_Scores_Final_Weighs_AHP.xlsx'  # AHP数据文件
entropy_file_path = 'Flood_Severity_Scores_Final_Weighs_Entropy.xlsx'  # Entropy数据文件

try:
    data_ahp = pd.read_excel(ahp_file_path, engine='openpyxl')
    print(f"✅ 成功加载AHP模型分数文件: '{ahp_file_path}'")
except Exception as e:
    print(f"❌ 读取AHP文件时发生错误: {e}")
    exit()

try:
    data_entropy = pd.read_excel(entropy_file_path, engine='openpyxl')
    print(f"✅ 成功加载Entropy模型分数文件: '{entropy_file_path}'")
except Exception as e:
    print(f"❌ 读取Entropy文件时发生错误: {e}")
    exit()


# ==============================================================================
# --- 2. 分别计算两个数据集的"集成得分"(Ensemble Score) ---
# ==============================================================================
def calculate_ensemble_score(data, dataset_name):
    score_columns = [
        'Score_GBDT', 'Score_XGBoost', 'Score_RF',
        'Score_SVM', 'Score_LightGBM', 'Score_MLP'
    ]

    # 修正了列名检查的逻辑
    existing_cols = [col for col in score_columns if col in data.columns]
    if len(existing_cols) == 0:
        print(f"\n❌ 错误：{dataset_name}数据中缺少任何一个模型分数列。")
        return None

    data['Ensemble_Score'] = data[existing_cols].mean(axis=1)
    print(f"\n✅ 已成功计算{dataset_name}所有事件的集成得分。")
    return data


# 分别计算AHP和Entropy的集成得分
data_ahp = calculate_ensemble_score(data_ahp, "AHP")
data_entropy = calculate_ensemble_score(data_entropy, "Entropy")

# ==============================================================================
# --- 3. 基于"集成得分"进行最终的五等级划分 ---
# ==============================================================================
class_names_english = ['Very Low', 'Low', 'Medium', 'High', 'Very High']


def assign_severity_levels(data, dataset_name):
    try:
        data['Final_Severity_Level'] = pd.qcut(data['Ensemble_Score'], q=5, labels=class_names_english)
        print(f"✅ 已根据{dataset_name}集成得分完成最终的五等级划分。")
        print(f"\n{dataset_name}最终各类别样本数量分布：")
        print(data['Final_Severity_Level'].value_counts().sort_index())
        return data
    except Exception as e:
        print(f"{dataset_name}分级时发生错误：{e}。可能是数据量过少或Ensemble_Score值完全相同。")
        return None


# 分别对两个数据集进行分级
data_ahp = assign_severity_levels(data_ahp, "AHP")
data_entropy = assign_severity_levels(data_entropy, "Entropy")

# ==============================================================================
# --- 4. 保存最终分级结果 ---
# ==============================================================================
output_columns = [
    'Year', 'Province', 'City', 'County', 'Longitude', 'latitude',
    'Number of people affected(ten thousand)', 'Citywide deaths',
    'Disaster-affected area(thousand hectares)', 'Economic losses(ten thousand yuan)',
    'Online popularity(Daily average)',
    'Ensemble_Score', 'Final_Severity_Level'
]


def save_results(data, dataset_name):
    output_columns_exist = [col for col in output_columns if col in data.columns]
    final_result_df = data[output_columns_exist]

    output_filename = f'Historical_Events_Final_Classification_{dataset_name}.xlsx'
    try:
        final_result_df.to_excel(output_filename, index=False)
        print(f"\n✅ 包含{dataset_name}最终分级结果的文件已成功保存到: '{output_filename}'")
    except Exception as e:
        print(f"\n❌ 保存{dataset_name}文件时出错: {e}")


save_results(data_ahp, "AHP")
save_results(data_entropy, "Entropy")

# ==============================================================================
# --- 5. 可视化分析 ---
# ==============================================================================
print("\n--- 正在生成可视化图表 ---")


# --- a) 图一：不同城市洪涝灾害等级构成图（组合图：上下分别为AHP和Entropy）---
def prepare_city_data(data, dataset_name):
    if 'City' not in data.columns or 'Final_Severity_Level' not in data.columns:
        print(f"⚠️ {dataset_name}数据中缺少'City'或'Final_Severity_Level'列，无法生成城市构成图")
        return None

    city_level_counts = data.groupby(['City', 'Final_Severity_Level']).size().unstack(fill_value=0)
    city_level_proportions = city_level_counts.div(city_level_counts.sum(axis=1), axis=0)

    # 确保排序是基于所有定义的类别
    # 按照class_names_english的顺序重新排列列，以确保colormap顺序正确
    for level in class_names_english:
        if level not in city_level_proportions.columns:
            city_level_proportions[level] = 0

    city_level_proportions = city_level_proportions[class_names_english]

    if 'Very High' in city_level_proportions.columns and 'High' in city_level_proportions.columns:
        city_level_proportions['high_risk_sum'] = city_level_proportions['Very High'] + city_level_proportions['High']
        city_level_proportions.sort_values(by='high_risk_sum', ascending=False, inplace=True)
        city_level_proportions.drop(columns='high_risk_sum', inplace=True)

    return city_level_proportions


# 准备两个数据集的城市数据
city_data_ahp = prepare_city_data(data_ahp, "AHP")
city_data_entropy = prepare_city_data(data_entropy, "Entropy")

if city_data_ahp is not None and city_data_entropy is not None:
    # 删除城市名称中的"City"字样
    def clean_city_names(city_data):
        # 创建一个新的索引，删除"City"字样
        new_index = city_data.index.str.replace(' City', '', regex=False)
        city_data.index = new_index
        return city_data


    city_data_ahp = clean_city_names(city_data_ahp)
    city_data_entropy = clean_city_names(city_data_entropy)

    # 创建组合图：上下两个子图
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(20, 16), sharex=True)

    # 上子图：AHP数据
    city_data_ahp.plot(
        kind='bar', stacked=True, ax=ax1,
        colormap='coolwarm',  # 蓝红色
        edgecolor='white'
    )
    ax1.set_title('AHP: Historical Flood Severity Composition by City', fontsize=12, fontname='Times New Roman')
    ax1.set_ylabel('Proportion of Events', fontsize=12, fontname='Times New Roman')
    ax1.set_ylim([0, 1])
    ax1.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
    ax1.set_yticklabels(['0%', '25%', '50%', '75%', '100%'], fontname='Times New Roman', fontsize=12)
    ax1.grid(axis='y', linestyle='--', alpha=0.7)

    # 下子图：Entropy数据
    city_data_entropy.plot(
        kind='bar', stacked=True, ax=ax2,
        colormap='coolwarm',  # 蓝红色
        edgecolor='white'
    )
    ax2.set_title('Entropy: Historical Flood Severity Composition by City', fontsize=12, fontname='Times New Roman')
    ax2.set_xlabel('City', fontsize=12, fontname='Times New Roman')
    ax2.set_ylabel('Proportion of Events', fontsize=12, fontname='Times New Roman')
    ax2.set_ylim([0, 1])
    ax2.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
    ax2.set_yticklabels(['0%', '25%', '50%', '75%', '100%'], fontname='Times New Roman', fontsize=12)
    ax2.grid(axis='y', linestyle='--', alpha=0.7)

    # 设置x轴刻度标签
    plt.setp(ax1.get_xticklabels(), visible=False)  # 隐藏上子图的x轴标签
    ax2.tick_params(axis='x', rotation=0, labelsize=12)

    # 统一设置刻度标签字体
    for ax in [ax1, ax2]:
        ax.tick_params(axis='both', which='major', labelsize=12)
        for label in ax.get_xticklabels():
            label.set_fontfamily('Times New Roman')
            label.set_fontsize(12)
        for label in ax.get_yticklabels():
            label.set_fontfamily('Times New Roman')
            label.set_fontsize(12)

    # 添加图例（只在下子图添加，避免重复）
    ax1.legend().remove()  # 移除上子图的图例
    legend = ax2.legend(title='Severity Level', bbox_to_anchor=(1.01, 1), loc='upper left', fontsize=12)
    plt.setp(legend.get_texts(), fontfamily='Times New Roman', fontsize=12)
    plt.setp(legend.get_title(), fontfamily='Times New Roman', fontsize=12)

    plt.tight_layout()
    plt.savefig('city_severity_composition_combined.png', dpi=300, bbox_inches='tight')
    print("✅ 城市灾害等级构成组合图已保存为 'city_severity_composition_combined.png'")
    plt.show()


# --- b) 图二：分别生成AHP和Entropy的年度趋势图 ---
def create_year_trend_plot(data, dataset_name):
    if 'Year' not in data.columns or 'Final_Severity_Level' not in data.columns:
        print(f"⚠️ {dataset_name}数据中缺少'Year'或'Final_Severity_Level'列，无法生成年度趋势图")
        return

    # 检查并清理Year列数据
    print(f"\n{dataset_name} - Year列数据类型: {data['Year'].dtype}")
    print(f"{dataset_name} - Year列唯一值示例: {sorted(data['Year'].unique())[:10]}")  # 显示前10个值

    # 确保Year列为数值类型，并处理可能的异常值
    data['Year'] = pd.to_numeric(data['Year'], errors='coerce')

    # 过滤掉异常年份（比如未来年份或明显错误的年份）
    current_year = pd.Timestamp.now().year
    data = data[(data['Year'] >= 1900) & (data['Year'] <= current_year + 1)]

    # 将年份转换为整数
    data['Year'] = data['Year'].astype(int)

    # 按年份和等级分组统计（原始计数）
    year_level_counts = data.groupby(['Year', 'Final_Severity_Level']).size().unstack(fill_value=0)

    # 确保所有等级都有列（即使某些年份没有该等级的事件）
    for level in class_names_english:
        if level not in year_level_counts.columns:
            year_level_counts[level] = 0

    # 按年份排序
    year_level_counts = year_level_counts.sort_index()

    # ========= 关键新增：对每个等级做滚动平均，得到平滑趋势 =========
    # 这里用 3 年窗口，你可以根据需要改成 5 年等
    window_size = 3
    year_level_counts_smooth = year_level_counts.rolling(
        window=window_size,
        center=True,
        min_periods=1
    ).mean()

    # 创建图表
    plt.figure(figsize=(20, 10))

    colors = plt.cm.viridis(np.linspace(0, 1, len(class_names_english)))

    years = year_level_counts.index

    for i, level in enumerate(class_names_english):
        # 1）先画"原始折线"——细线、半透明，只作为背景参考
        plt.plot(
            years,
            year_level_counts[level],
            linestyle=':',
            linewidth=1.2,
            alpha=0.35,
            marker='o',
            markersize=4,
            color=colors[i]
        )

        # 2）再画"平滑趋势线"——主线，更粗、更明显
        plt.plot(
            years,
            year_level_counts_smooth[level],
            linewidth=2.8,
            alpha=0.95,
            label=level,
            color=colors[i]
        )

    # 统一字体大小为12
    plt.title(f'{dataset_name}: Trend of Flood Events by Severity Level Over Years', fontsize=12,
              fontname='Times New Roman')
    plt.xlabel('Year', fontsize=12, fontname='Times New Roman')
    plt.ylabel('Number of Events', fontsize=12, fontname='Times New Roman')

    # 图例（仅对应平滑曲线的label），统一字体大小为12
    legend = plt.legend(title='Severity Level', fontsize=12)
    plt.setp(legend.get_texts(), fontfamily='Times New Roman', fontsize=12)
    plt.setp(legend.get_title(), fontfamily='Times New Roman', fontsize=12)

    plt.grid(True, linestyle='--', alpha=0.7)

    # 设置X轴刻度 - 根据实际年份范围智能调整
    if len(years) > 0:
        ax = plt.gca()
        ax.xaxis.set_major_locator(MaxNLocator(integer=True, nbins=min(15, len(years))))
        ax.tick_params(axis='both', which='major', labelsize=12)

        # 设置刻度标签字体，统一字体大小为12
        for label in ax.get_xticklabels():
            label.set_fontfamily('Times New Roman')
            label.set_fontsize(12)  # 明确设置刻度标签字体大小为12
        for label in ax.get_yticklabels():
            label.set_fontfamily('Times New Roman')
            label.set_fontsize(12)  # 明确设置刻度标签字体大小为12

        # 修改这里：无论年份数量多少，横坐标标签都设置为0度旋转
        plt.xticks(rotation=0)  # 将旋转角度设为0°

    plt.tight_layout()
    output_filename = f'year_severity_trend_smooth_{dataset_name}.png'
    plt.savefig(output_filename, dpi=300, bbox_inches='tight')
    print(f"✅ {dataset_name}年度灾害等级趋势图已保存为 '{output_filename}'")
    plt.show()


# 分别为AHP和Entropy生成年度趋势图
create_year_trend_plot(data_ahp, "AHP")
create_year_trend_plot(data_entropy, "Entropy")