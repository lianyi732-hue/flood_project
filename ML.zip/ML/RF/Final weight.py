#先通过AHP或熵权法进行人工/客观赋权，再利用机器学习模型xgb进行学习和修正
#这里AHP的权重是我计算得到的
#这个代码的作用是在AHP和熵权法权重的基础上 根据机器学习进行修正 得到一套新的权重

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, MinMaxScaler
# 导入随机森林回归器
from sklearn.ensemble import RandomForestRegressor

# ==============================================================================
# --- 1. 数据加载与准备 ---
# ==============================================================================
try:
    file_path = 'FloodInventory_All_Normalized_city20.xlsx'
    data = pd.read_excel(file_path)
    print(f"成功加载Excel文件: '{file_path}'")
except Exception as e:
    print(f"读取Excel文件时发生错误: {e}")
    exit()

data.columns = data.columns.str.strip()
factor_columns = [
    'Number of people affected(ten thousand)',
    'Citywide deaths',
    'Disaster-affected area(thousand hectares)',
    'Economic losses(ten thousand yuan)',
    'Online popularity(Daily average)'
]
data_factors = data[factor_columns].dropna()
X_features = data_factors.values

# 创建回归目标 y_reg 和标准化特征 X_scaled
scaler_y = MinMaxScaler()
factors_scaled = scaler_y.fit_transform(data_factors)
y_reg = np.sum(factors_scaled, axis=1)
scaler_X = StandardScaler()
X_scaled = scaler_X.fit_transform(X_features)

# ==============================================================================
# --- 2. AHP混合模型分析 (修正模型: 随机森林) ---
# ==============================================================================
print("\n" + "=" * 80)
print("--- 分析AHP混合模型 (修正模型: 随机森林) ---")

# a) 原始AHP权重
ahp_weights_dict = {
    'Citywide deaths': 0.497,
    'Economic losses(ten thousand yuan)': 0.245,
    'Number of people affected(ten thousand)': 0.105,
    'Disaster-affected area(thousand hectares)': 0.105,
    'Online popularity(Daily average)': 0.048
}
ahp_series = pd.Series(ahp_weights_dict, name="Original_AHP_Weight")
ahp_weights = np.array([ahp_weights_dict[col] for col in factor_columns])
expert_index_ahp = np.dot(factors_scaled, ahp_weights)
X_hybrid_ahp = np.c_[X_scaled, expert_index_ahp]
ahp_features_names = factor_columns + ['AHP_Expert_Index']

# b) 使用随机森林训练并提取特征重要性
rf_corrector_ahp = RandomForestRegressor(random_state=42, n_estimators=100)
rf_corrector_ahp.fit(X_hybrid_ahp, y_reg)
ahp_corrected_importances = rf_corrector_ahp.feature_importances_
ahp_importance_df = pd.DataFrame({
    'Feature': ahp_features_names,
    'Importance_In_Hybrid_Model': ahp_corrected_importances
})

# ==============================================================================
# --- 3. 熵权法混合模型分析 (修正模型: 随机森林) ---
# ==============================================================================
print("\n" + "=" * 80)
print("--- 分析熵权法混合模型 (修正模型: 随机森林) ---")


# a) 原始熵权法权重
def calculate_entropy_weights(data):
    p = data / data.sum(axis=0)
    p[p == 0] = 1e-10
    k = 1 / np.log(data.shape[0])
    e = -k * (p * np.log(p)).sum(axis=0)
    d = 1 - e
    return d / d.sum()


entropy_weights = calculate_entropy_weights(factors_scaled)
entropy_series = pd.Series(dict(zip(factor_columns, entropy_weights)), name="Original_Entropy_Weight")
expert_index_entropy = np.dot(factors_scaled, entropy_weights)
X_hybrid_entropy = np.c_[X_scaled, expert_index_entropy]
entropy_features_names = factor_columns + ['Entropy_Expert_Index']

# b) 使用随机森林训练并提取特征重要性
rf_corrector_entropy = RandomForestRegressor(random_state=42, n_estimators=100)
rf_corrector_entropy.fit(X_hybrid_entropy, y_reg)
entropy_corrected_importances = rf_corrector_entropy.feature_importances_
entropy_importance_df = pd.DataFrame({
    'Feature': entropy_features_names,
    'Importance_In_Hybrid_Model': entropy_corrected_importances
})


# ==============================================================================
# --- 4. 计算最终“修正后”的权重 ---
# ==============================================================================
def calculate_corrected_weights(original_weights, corrected_importances_df, index_name):
    final_weights = {}
    importance_of_index = \
    corrected_importances_df.loc[corrected_importances_df['Feature'] == index_name, 'Importance_In_Hybrid_Model'].iloc[
        0]

    for factor_name, original_weight in original_weights.items():
        indirect_importance = importance_of_index * original_weight
        direct_importance_series = corrected_importances_df.loc[
            corrected_importances_df['Feature'] == factor_name, 'Importance_In_Hybrid_Model']
        direct_importance = direct_importance_series.iloc[0] if not direct_importance_series.empty else 0
        final_weights[factor_name] = indirect_importance + direct_importance

    total_weight = sum(final_weights.values())
    return pd.Series({name: weight / total_weight for name, weight in final_weights.items()})


# 计算AHP修正权重
final_ahp_weights = calculate_corrected_weights(ahp_weights_dict, ahp_importance_df, 'AHP_Expert_Index')
final_ahp_weights.name = "Final_AHP_Hybrid_Weight(RF)"

# 计算熵权法修正权重
final_entropy_weights = calculate_corrected_weights(entropy_series.to_dict(), entropy_importance_df,
                                                    'Entropy_Expert_Index')
final_entropy_weights.name = "Final_Entropy_Hybrid_Weight(RF)"

# ==============================================================================
# --- 5. 最终结果展示与保存 ---
# ==============================================================================
comparison_df = pd.concat([ahp_series, final_ahp_weights, entropy_series, final_entropy_weights], axis=1)
comparison_df.sort_values(by="Final_AHP_Hybrid_Weight(RF)", ascending=False, inplace=True)

print("\n" + "=" * 80)
print("--- 原始权重 与 随机森林修正后最终权重 的对比 ---")
print(comparison_df)
print("=" * 80)

# 保存最终结果
try:
    output_filename = 'final_rf_hybrid_weights_comparison.xlsx'
    comparison_df.to_excel(output_filename, sheet_name='RF_Hybrid_Weights')
    print(f"\n✅ 完整的权重对比结果(由RF修正)已成功保存到Excel文件: '{output_filename}'")
except Exception as e:
    print(f"\n❌ 保存文件时出错: {e}")