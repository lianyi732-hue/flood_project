#不再使用原始数据从头训练一个模型来预测等级。而是直接使用您之前已经计算好的、根据AHP/熵权法等权重计算出的6组模型得分 (Score_RF, Score_MLP等)作为分析的基础。

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# ==============================================================================
# --- 1. 数据加载 ---
# ==============================================================================
file_path = 'Flood_Severity_Scores_Final_Weighs_Entropy.xlsx'  # 确保文件名正确
try:
    data = pd.read_excel(file_path, engine='openpyxl')
    print(f"✅ 成功加载模型分数文件: '{file_path}'")
except Exception as e:
    print(f"❌ 读取文件时发生错误: {e}")
    exit()

# ==============================================================================
# --- 2. 计算“集成得分”(Ensemble Score) ---
# ==============================================================================
score_columns = [
    'Score_GBDT', 'Score_XGBoost', 'Score_RF',
    'Score_SVM', 'Score_LightGBM', 'Score_MLP'
]
data['Ensemble_Score'] = data[score_columns].mean(axis=1)
print("\n已成功计算所有事件的“集成得分”。")

# ==============================================================================
# --- 3. 基于“集成得分”进行最终的五等级划分 ---
# ==============================================================================
class_names = ['极低严重', '低严重', '中严重', '高严重', '极高严重']
try:
    # 创建文本标签的等级列，用于展示和理解
    data['Final_Severity_Level'] = pd.qcut(data['Ensemble_Score'], q=5, labels=class_names)

    # 【核心修正】创建一个对应的数字等级列 (0-4)，用于数学计算
    data['Final_Severity_Class_Num'] = pd.qcut(data['Ensemble_Score'], q=5, labels=False)

    print("已根据“集成得分”完成最终的五等级划分。")
    print("\n最终各类别样本数量分布：")
    print(data['Final_Severity_Level'].value_counts().sort_index())
except Exception as e:
    print(f"分级时发生错误：{e}。")
    exit()

# ==============================================================================
# --- 4. 按城市进行汇总分析 ---
# ==============================================================================
print("\n开始按城市进行风险汇总分析...")
if 'City' not in data.columns:
    print("错误：数据中缺少 'City' 列，无法按城市进行分析。")
    exit()

# 清理城市名
data['City'] = data['City'].astype(str).str.replace(' City', '').str.replace('市', '').str.strip()

# 【核心修正】在聚合计算时，使用我们新创建的数字等级列
city_risk_analysis = data.groupby('City').agg(
    total_events=('City', 'count'),
    # 使用 Final_Severity_Class_Num 来计算平均值
    avg_severity_class=('Final_Severity_Class_Num', 'mean'),
    # 使用 Final_Severity_Class_Num 来统计高危事件
    high_severity_events=('Final_Severity_Class_Num', lambda x: (x >= 3).sum())
).reset_index()

# ... (后续代码保持不变) ...
# 计算高危事件比例
city_risk_analysis['high_severity_ratio'] = city_risk_analysis['high_severity_events'] / city_risk_analysis[
    'total_events']
city_risk_analysis_sorted = city_risk_analysis.sort_values(by='avg_severity_class', ascending=False)

print("\n--- 城市洪水灾害风险分析报告 ---")
print(city_risk_analysis_sorted)

# 保存分析结果
city_risk_analysis_sorted.to_csv('city_flood_risk_analysis.csv', index=False, encoding='utf-8-sig')
print("\n城市风险分析结果已保存到 'city_flood_risk_analysis.csv'")

# ==============================================================================
# --- 5. 可视化风险最高的城市 ---
# ==============================================================================
top_n = 20
top_cities = city_risk_analysis_sorted.head(top_n)

# 图一：平均严重等级排名
plt.figure(figsize=(12, 10))
sns.barplot(x='avg_severity_class', y='City', data=top_cities, palette='viridis')
plt.title(f'洪水灾害平均严重等级最高的 {top_n} 个城市', fontsize=18)
plt.xlabel('平均严重等级 (0-4)', fontsize=12)
plt.ylabel('城市', fontsize=12)
plt.grid(axis='x', linestyle='--', alpha=0.7)
plt.tight_layout()
plt.savefig('top_risk_cities_by_avg_severity.png', dpi=300)
plt.show()

# 图二：高危事件占比排名
plt.figure(figsize=(12, 10))
top_cities_by_ratio = city_risk_analysis.sort_values(by='high_severity_ratio', ascending=False).head(top_n)
sns.barplot(x='high_severity_ratio', y='City', data=top_cities_by_ratio, palette='plasma')
plt.title(f'高危洪水事件 (等级3&4) 占比最高的 {top_n} 个城市', fontsize=18)
plt.xlabel('高危事件占比', fontsize=12)
plt.ylabel('城市', fontsize=12)
plt.grid(axis='x', linestyle='--', alpha=0.7)
plt.tight_layout()
plt.savefig('top_risk_cities_by_high_severity_ratio.png', dpi=300)
plt.show()