#组内相关系数(ICC)  “我的这6个模型，作为一组评估员，它们的打分结果有多可靠和一致？”

import pandas as pd
import pingouin as pg

# --- 1. 数据加载与准备 ---
file_path = 'Flood_Severity_Scores_Final_Weighs_Entropy.xlsx'
try:
    data = pd.read_excel(file_path, engine='openpyxl')
    print(f"✅ 成功加载Excel文件: '{file_path}'")
except Exception as e:
    print(f"❌ 读取文件时发生错误: {e}")
    exit()

score_columns = [
    'Score_GBDT', 'Score_XGBoost', 'Score_RF',
    'Score_SVM', 'Score_LightGBM', 'Score_MLP'
]
scores_df = data[score_columns]
# 添加一个唯一的事件ID，用于后续数据转换
scores_df['event_id'] = range(len(scores_df))

# --- 2. 转换数据为“长格式” ---
# pingouin计算ICC需要长格式数据
df_long = scores_df.melt(id_vars='event_id', var_name='model', value_name='score')

# --- 3. 计算ICC ---
print("\n正在计算组内相关系数 (ICC)...")
# targets: 事件ID, raters: 模型, ratings: 分数
# 我们关心的是模型之间的一致性，所以选择ICC2k或ICC3k
icc_results = pg.intraclass_corr(data=df_long, targets='event_id', raters='model', ratings='score')

# --- 4. 展示结果 ---
print("\n" + "="*60)
print("--- 模型一致性评估 (组内相关系数ICC) ---")
# 我们通常关注 'ICC2k' (A-k) 或 'ICC3k' (C-k)，它们都代表了“绝对一致性”
# .set_index('Type') 让输出更美观
print(icc_results.set_index('Type'))
print("="*60)

# 提取我们最关心的ICC值
icc_consistency = icc_results.loc[icc_results['Type'] == 'ICC3k', 'ICC'].iloc[0]
print(f"\n最终一致性评估 (ICC3k - 绝对一致性): {icc_consistency:.4f}")
print("\n--- 解读 ---")
print("ICC值也在0到1之间，越接近1，说明您的6个模型作为一组评估员，其打分结果越一致、越可靠。")