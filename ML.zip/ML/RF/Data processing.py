#主要功能是读取一个Excel数据文件，对其中的指定列用中位数填充缺失值，并保存处理后的新文件

import pandas as pd
import os # 导入os模块

# --- 第1步：动态获取文件路径 ---
# 获取当前脚本文件所在的目录
script_directory = os.path.dirname(os.path.abspath(__file__))

# *** 核心修改点1：将文件后缀改为 .xlsx ***
# 构建Excel文件的完整、绝对路径
excel_file_path = os.path.join(script_directory, "FloodInventory_Combined.xlsx")

print(f"正在从以下路径加载文件: {excel_file_path}")

# --- 第2步：加载您的数据文件 ---
try:
    # *** 核心修改点2：使用 pd.read_excel() 加载文件 ***
    # 使用构建好的完整路径加载Excel文件
    df = pd.read_excel(excel_file_path)
    print("数据文件加载成功！")
except FileNotFoundError:
    # 错误消息也要更新一下，以反映是Excel文件
    print(f"错误：在路径 '{excel_file_path}' 下找不到Excel文件。请再次检查！")
    exit()
except Exception as e: # 添加一个更通用的异常捕获，以防Excel文件有其他读取问题
    print(f"读取Excel文件时发生错误: {e}")
    exit()

# ... (您后续的代码保持不变) ...

# --- 第2步：指定需要填充的列 ---
columns_to_fill = [
    'Number of people affected(ten thousand)',
    'Disaster-affected area(thousand hectares)',
    'Economic losses(ten thousand yuan)'
]

# --- 第3步：检查填充前的缺失值数量 ---
print("\n--- 填充前各列的缺失值数量 ---")
# 使用 .isnull().sum() 统计每列的缺失值个数
for col in columns_to_fill:
    # 确保列存在于DataFrame中
    if col in df.columns:
        missing_count = df[col].isnull().sum()
        print(f"'{col}': {missing_count} 个")
    else:
        print(f"警告: 列 '{col}' 在数据中不存在。")

# --- 第4步：循环计算并填充每一列 ---
print("\n--- 开始填充... ---")
for col in columns_to_fill:
    if col in df.columns:
        # 1. 计算当前列的中位数
        median_value = df[col].median()

        # 2. 使用 fillna() 方法填充缺失值
        #    inplace=True 表示直接在原始数据上进行修改
        df[col].fillna(median_value, inplace=True)

        print(f"已使用中位数 '{median_value}' 填充 '{col}' 列。")

# --- 第5步：验证填充后的结果 ---
print("\n--- 填充后各列的缺失值数量 ---")
for col in columns_to_fill:
    if col in df.columns:
        missing_count = df[col].isnull().sum()
        print(f"'{col}': {missing_count} 个")

# --- 第6步 (可选): 保存处理好的新文件 ---
# 移除前面的 '#' 符号即可运行
# *** 核心修改点3：如果保存，也应该保存为 .xlsx 或指定为新的CSV文件 ***
output_filename = "FloodInventory_Fully_Filled.xlsx" # 也可以保存为CSV: "FloodInventory_Fully_Filled.csv"
df.to_excel(output_filename, index=False) # 如果保存为Excel，使用 df.to_excel
# df.to_csv(output_filename, index=False) # 如果想保存为CSV，使用 df.to_csv
print(f"\n✅ 已将填充完毕的数据保存为新文件: {output_filename}")