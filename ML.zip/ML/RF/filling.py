#这个代码是由于网络热度值 很难获得到研究区域内的所有值，所以这个Python代码执行的是一个网络热度值按权重分配的数据处理任务。

import pandas as pd
import numpy as np

# ==============================================================================
# --- 配置区域 ---
# ==============================================================================
# !! 重要 !!: 请确保这两个文件名是您正确的CSV文件名
main_data_path = 'beijing.csv'  # 包含区县级别数据
popularity_lookup_path = 'beijing.csv'  # 包含城市月度总热度
WEIGHT_CHOICE = 'Economic losses(ten thousand yuan)'  # 使用的权重列

# ==============================================================================
# --- 主程序 ---
# ==============================================================================
try:
    # --- 步骤 1: 加载数据 ---
    print("正在加载数据...")

    # 【已修正】使用 pd.read_csv 并增加编码容错
    try:
        main_data = pd.read_csv(main_data_path)
        lookup_df = pd.read_csv(popularity_lookup_path)
    except UnicodeDecodeError:
        print("UTF-8解码失败，正在尝试GBK编码...")
        main_data = pd.read_csv(main_data_path, encoding='gbk')
        lookup_df = pd.read_csv(popularity_lookup_path, encoding='gbk')

    print("主数据和宏观热度查找表加载成功！")

    # 显示数据的基本信息
    print(f"主数据形状: {main_data.shape}")
    print(f"查找表形状: {lookup_df.shape}")

    # --- 步骤 2: 数据清洗与标准化 ---
    print("\n正在进行数据清洗与标准化...")

    # 清洗列名
    main_data.columns = main_data.columns.str.strip()
    lookup_df.columns = lookup_df.columns.str.strip()

    # 统一城市名称格式 (假设城市名可能包含'市'字)
    main_data['City'] = main_data['City'].astype(str).str.replace('市', '').str.strip()
    lookup_df['City'] = lookup_df['City'].astype(str).str.replace('市', '').str.strip()

    # 确保关键列的数据类型正确
    for df in [main_data, lookup_df]:
        df['Year'] = pd.to_numeric(df['Year'], errors='coerce')
        df['Month'] = pd.to_numeric(df['Month'], errors='coerce')

    # 删除关键列中的空值
    main_data.dropna(subset=['Year', 'Month', 'City'], inplace=True)
    lookup_df.dropna(subset=['Year', 'Month', 'City'], inplace=True)

    # 转换年份和月份为整数
    main_data['Year'] = main_data['Year'].astype(int)
    main_data['Month'] = main_data['Month'].astype(int)
    lookup_df['Year'] = lookup_df['Year'].astype(int)
    lookup_df['Month'] = lookup_df['Month'].astype(int)

    print("数据清洗与标准化完成。")

    # --- 步骤 3: 检查权重列是否存在 ---
    if WEIGHT_CHOICE not in main_data.columns:
        print(f"错误: 权重列 '{WEIGHT_CHOICE}' 不在主数据中")
        exit()
    # 将权重列转换为数值，无法转换的设为0
    main_data[WEIGHT_CHOICE] = pd.to_numeric(main_data[WEIGHT_CHOICE], errors='coerce').fillna(0)

    # --- 步骤 4: 准备查找表（城市级别的总热度）---
    print("\n准备城市级别的总热度数据...")

    # 查找表应该只包含城市级别的数据（不包含区县）
    # 我们通过分组求和来确保得到的是每个城市每月的总热度
    city_popularity = lookup_df.groupby(['Year', 'Month', 'City'])[
        'Online popularity(Daily average)'].sum().reset_index()

    print(f"城市级别热度表形状: {city_popularity.shape}")

    # --- 步骤 5: 计算每个城市每月的权重总和 ---
    print(f"\n正在使用 '{WEIGHT_CHOICE}' 作为权重进行分配...")

    # 计算每个分组（同年同月同城）内的权重总和
    main_data['Total_Weight_Sum'] = main_data.groupby(['Year', 'Month', 'City'])[WEIGHT_CHOICE].transform('sum')

    # 处理权重总和为0的情况（避免除以0）
    main_data.loc[main_data['Total_Weight_Sum'] == 0, 'Total_Weight_Sum'] = 1

    # 计算每个记录的权重比例
    main_data['Weight_Proportion'] = main_data[WEIGHT_CHOICE] / main_data['Total_Weight_Sum']
    main_data['Weight_Proportion'].fillna(0, inplace=True)

    # --- 步骤 6: 合并城市总热度 ---
    print("正在合并城市月度总热度...")

    merged_df = pd.merge(
        main_data,
        city_popularity.rename(columns={'Online popularity(Daily average)': 'City_Total_Popularity'}),
        on=['Year', 'Month', 'City'],
        how='left'
    )

    # 检查是否有未匹配的记录
    unmatched_count = merged_df['City_Total_Popularity'].isnull().sum()
    if unmatched_count > 0:
        print(f"警告: 有 {unmatched_count} 条记录未能匹配到城市总热度")
        merged_df['City_Total_Popularity'].fillna(0, inplace=True)
    else:
        print("所有记录均成功匹配到城市总热度！")

    # --- 步骤 7: 重新计算所有热度值（覆盖原有值）---
    print("正在重新计算所有热度值...")

    # 计算每个区县应得的热度值
    merged_df['Calculated_Popularity'] = merged_df['City_Total_Popularity'] * merged_df['Weight_Proportion']

    # 四舍五入为整数
    merged_df['Calculated_Popularity'] = merged_df['Calculated_Popularity'].round().astype(int)

    # 关键修改：完全覆盖原有的热度值
    merged_df['Online popularity(Daily average)'] = merged_df['Calculated_Popularity']

    # --- 步骤 8: 清理并导出结果 ---
    print("正在准备导出数据...")

    # 删除计算过程中使用的临时列
    columns_to_drop = ['Total_Weight_Sum', 'Weight_Proportion', 'City_Total_Popularity', 'Calculated_Popularity']
    final_data = merged_df.drop(columns=columns_to_drop)

    # 导出结果
    output_file_path = 'FloodInventory_Allocated_Output.csv'
    final_data.to_csv(output_file_path, index=False, encoding='utf-8-sig')
    print(f"数据已成功导出到: {output_file_path}")

    # --- 步骤 9: 验证结果 ---
    print("\n--- 验证分配结果 ---")

    # 查看2004年7月北京市各区网络热度分配结果
    beijing_2004_july = final_data[
        (final_data['City'] == 'Beijing') &
        (final_data['Year'] == 2004) &
        (final_data['Month'] == 7)
        ]

    if not beijing_2004_july.empty:
        print("2004年7月北京市各区分配结果:")
        print(beijing_2004_july[['County', WEIGHT_CHOICE, 'Online popularity(Daily average)']].to_string())

        sum_after_allocation = beijing_2004_july['Online popularity(Daily average)'].sum()
        print(f"\n分配后的热度总和: {sum_after_allocation}")

        # 获取原始城市总热度
        original_total_series = city_popularity[
            (city_popularity['City'] == 'Beijing') &
            (city_popularity['Year'] == 2004) &
            (city_popularity['Month'] == 7)
            ]['Online popularity(Daily average)']

        if not original_total_series.empty:
            original_total = original_total_series.iloc[0]
            print(f"原始城市总热度: {original_total}")
            print(f"差值 (由于取整误差): {original_total - sum_after_allocation}")

            # 检查权重分配情况
            total_weight = beijing_2004_july[WEIGHT_CHOICE].sum()
            print(f"总权重值: {total_weight}")

            # 显示详细的分配比例
            print("\n详细分配情况:")
            for _, row in beijing_2004_july.iterrows():
                proportion = row[WEIGHT_CHOICE] / total_weight if total_weight > 0 else 0
                expected_popularity = original_total * proportion
                print(
                    f"{row['County']}: 权重={row[WEIGHT_CHOICE]}, 比例={proportion:.4f}, 应得热度≈{expected_popularity:.1f}, 实际分配={row['Online popularity(Daily average)']}")
        else:
            print("未找到2004年7月北京市的原始城市总热度记录")
    else:
        print("未找到2004年7月北京市的记录")

    print("\n处理完成！")

except Exception as e:
    import traceback

    print(f"\n处理过程中发生严重错误: {str(e)}")
    traceback.print_exc()