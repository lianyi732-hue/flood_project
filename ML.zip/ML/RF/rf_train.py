#这个代码的核心在于计算权重，五个影响因子的权重

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_squared_error
import matplotlib.pyplot as plt
import os

# --- 1. 数据加载与准备 ---
try:
    # 优先使用绝对路径加载，确保脚本在任何位置都能运行
    script_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(script_dir, 'FloodInventory_All_Normalized_city20.xlsx')
    print(f"正在从路径加载数据: {file_path}")
    data = pd.read_excel(file_path)
except (NameError, FileNotFoundError):
    print("无法通过绝对路径找到文件，尝试直接加载 'FloodInventory_All_Normalized_city20.xlsx'。")
    try:
        data = pd.read_excel('FloodInventory_All_Normalized_city20.xlsx')
    except FileNotFoundError:
        print("\n错误：文件 'FloodInventory_All_Normalized_city20' 未找到。请检查文件名和位置。")
        exit()

# 清理列名，去除可能存在的首尾空格
data.columns = data.columns.str.strip()

# 定义你关心的五个核心指标
factor_columns = [
    'Number of people affected(ten thousand)',
    'Citywide deaths',
    'Disaster-affected area(thousand hectares)',
    'Economic losses(ten thousand yuan)',
    'Online popularity(Daily average)'
]

# 检查这些列是否存在于数据中
missing_cols = [col for col in factor_columns if col not in data.columns]
if missing_cols:
    print(f"\n错误：数据中缺少以下关键列: {missing_cols}")
    exit()

# 清理数据：只保留这五个指标，并删除任何包含缺失值的行
data_factors = data[factor_columns].dropna()
print(f"\n数据清理完成，用于分析的记录共有 {len(data_factors)} 条。")

# --- 2. 创建一个综合的“洪水严重性指数”作为预测目标 ---
# 使用 MinMaxScaler 将所有指标缩放到 0-1 范围，避免量纲影响
scaler = MinMaxScaler()
factors_scaled = scaler.fit_transform(data_factors)

# 将标准化后的五个指标相加，得到“洪水严重性指数”
# 这个指数越高，代表该次洪水的综合影响越大
data_factors['Severity_Index'] = np.sum(factors_scaled, axis=1)

print("\n已成功创建“洪水严重性指数”作为模型预测目标。")
print("指数前5行预览:")
print(data_factors['Severity_Index'].head())


# --- 3. 准备特征 (X) 和目标 (y) ---
# 特征 X 是原始的五个指标
X = data_factors[factor_columns]
# 目标 y 是我们新创建的严重性指数
y = data_factors['Severity_Index']


# --- 4. 划分数据并训练随机森林回归模型 ---
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 使用回归模型（Regressor）而不是分类模型
rf_regressor = RandomForestRegressor(n_estimators=100, random_state=42)

print("\n正在训练随机森林回归模型...")
rf_regressor.fit(X_train, y_train)
print("模型训练完成。")


# --- 5. 获取并可视化特征重要性（权重）---
# 这就是你最关心的结果：各个指标的权重
importances = rf_regressor.feature_importances_

# 创建一个DataFrame来清晰地展示结果
importance_df = pd.DataFrame({
    '指标 (Factor)': factor_columns,
    '重要性 (Importance/Weight)': importances
}).sort_values(by='重要性 (Importance/Weight)', ascending=False)

# 将重要性转换为百分比，更直观
importance_df['重要性百分比 (Weight %)'] = (importance_df['重要性 (Importance/Weight)'] * 100).round(2)


print('\n\n====== 各项洪水影响指标的权重分析结果 ======')
print(importance_df[['指标 (Factor)', '重要性百分比 (Weight %)']])

# 使用Matplotlib进行可视化
plt.rcParams['font.sans-serif'] = ['SimHei'] # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False # 用来正常显示负号

plt.figure(figsize=(12, 8))
plt.barh(importance_df['指标 (Factor)'], importance_df['重要性 (Importance/Weight)'], color='skyblue')
plt.xlabel('重要性（权重）', fontsize=14)
plt.ylabel('影响指标', fontsize=14)
plt.title('随机森林模型分析：各影响指标的权重', fontsize=16)
plt.gca().invert_yaxis() # 将最重要的指标显示在最上方
plt.grid(axis='x', linestyle='--', alpha=0.7)
plt.show()


# --- 6. (可选) 评估模型性能 ---
# 评估模型可以帮助我们判断特征重要性结果的可靠性
y_pred = rf_regressor.predict(X_test)
r2 = r2_score(y_test, y_pred)
mse = mean_squared_error(y_test, y_pred)

print('\n--- 模型性能评估 ---')
print(f'R² 分数: {r2:.4f}')
print(f'均方误差 (MSE): {mse:.4f}')
print(f'(R²分数越接近1，说明模型越能解释数据的变异，特征重要性的结果也越可靠)')
