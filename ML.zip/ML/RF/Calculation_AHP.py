# 这个代码的作用是 根据权重计算洪水严重程度值  得到各个模型的洪濑灾害严重性得分

import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler

print("--- 开始使用最终确认的权重计算洪水严重程度值 ---")

# --- 1. 数据加载与准备 ---
try:
    file_path = 'FloodInventory_All_Normalized_city20.xlsx'
    data = pd.read_excel(file_path)
    print(f"成功加载Excel文件: '{file_path}'")
except FileNotFoundError:
    print(f"错误：未找到文件 '{file_path}'。请确保文件与脚本在同一目录下。")
    exit()

# 清理列名中可能存在的空格
data.columns = data.columns.str.strip()
factor_columns = [
    'Number of people affected(ten thousand)',
    'Economic losses(ten thousand yuan)',
    'Online popularity(Daily average)',
    'Citywide deaths',
    'Disaster-affected area(thousand hectares)'
]

# 检查关键列是否存在
missing_cols = [col for col in factor_columns if col not in data.columns]
if missing_cols:
    print(f"\n错误：数据中缺少以下关键列: {missing_cols}")
    exit()

# 清理数据，移除包含空值的行
data_factors = data[factor_columns].dropna().copy()
print(f"数据清理完成，用于计算的记录共有 {len(data_factors)} 条.")


# --- 2. 定义最终模型权重 (将图片中的数值转换为小数形式) ---
model_weights = {
    'GBDT': {
        'Number of people affected(ten thousand)': 0.125,
        'Economic losses(ten thousand yuan)': 0.186,
        'Online popularity(Daily average)': 0.088,
        'Citywide deaths': 0.366,
        'Disaster-affected area(thousand hectares)': 0.235
    },
    'XGBoost': {
        'Number of people affected(ten thousand)': 0.136,
        'Economic losses(ten thousand yuan)': 0.227,
        'Online popularity(Daily average)': 0.095,
        'Citywide deaths': 0.421,
        'Disaster-affected area(thousand hectares)': 0.121
    },
    'RF': {
        'Number of people affected(ten thousand)': 0.117,
        'Economic losses(ten thousand yuan)': 0.214,
        'Online popularity(Daily average)': 0.089,
        'Citywide deaths': 0.425,
        'Disaster-affected area(thousand hectares)': 0.155
    },
    'SVM': {
        'Number of people affected(ten thousand)': 0.111,
        'Economic losses(ten thousand yuan)': 0.043,
        'Online popularity(Daily average)': 0.04,
        'Citywide deaths': 0.063,
        'Disaster-affected area(thousand hectares)': 0.743
    },
    'LightGBM': {
        'Number of people affected(ten thousand)': 0.185,
        'Economic losses(ten thousand yuan)': 0.204,
        'Online popularity(Daily average)': 0.156,
        'Citywide deaths': 0.224,
        'Disaster-affected area(thousand hectares)': 0.231
    },
    'MLP': {
        'Number of people affected(ten thousand)': 0.06,
        'Economic losses(ten thousand yuan)': 0.021,
        'Online popularity(Daily average)': 0.022,
        'Citywide deaths': 0.116,
        'Disaster-affected area(thousand hectares)': 0.781
    }
}
print("\n已加载图片中提供的最终模型权重（已转换为小数形式）。")

# --- 3. 数据预处理：归一化 (与模型训练时保持一致) ---
data_log_transformed = data_factors.apply(np.log1p)
scaler = MinMaxScaler()
data_scaled = pd.DataFrame(scaler.fit_transform(data_log_transformed), columns=factor_columns, index=data_factors.index)
print("数据已完成归一化处理，准备进行加权计算。")

# --- 4. 计算每个模型的洪水严重程度得分 ---
results_df = data.copy()
print(f"\n--- 正在计算严重程度得分 ---")
for model_name, weights in model_weights.items():
    score_column_name = f'Score_{model_name}'
    results_df[score_column_name] = 0.0
    for factor, weight in weights.items():
        if factor in data_scaled.columns:
            results_df[score_column_name] += data_scaled[factor] * weight
        else:
            print(f"警告：特征 '{factor}' 在数据中未找到，计算时将忽略。")

print("\n所有严重程度得分计算完成。")

# --- 5. 查看并保存结果 ---
score_columns = [col for col in results_df.columns if 'Score_' in col]
display_columns = factor_columns + score_columns
print("\n计算结果预览（前5行）：")
print(results_df[display_columns].head())

# 将结果保存到新的Excel文件中
output_filename = "Flood_Severity_Scores_Final_Weighs_AHP.xlsx"
results_df.to_excel(output_filename, index=False)
print(f"\n计算完成！完整结果已保存到文件: '{output_filename}'")