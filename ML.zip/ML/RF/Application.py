# 记录学习曲线 

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, learning_curve
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.metrics import accuracy_score
import warnings
from sklearn.exceptions import ConvergenceWarning

# Models
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from xgboost import XGBClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC
import lightgbm as lgb

# === Set Global Font and Size (SCI style) ===
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 12
plt.rcParams['axes.titlesize'] = 12
plt.rcParams['axes.labelsize'] = 12
plt.rcParams['legend.fontsize'] = 12
plt.rcParams['xtick.labelsize'] = 11
plt.rcParams['ytick.labelsize'] = 11

# --- 1. Load and Prepare Data ---
try:
    file_path = 'Flood_Severity_Scores_Final_Weighs_Entropy.xlsx'
    data = pd.read_excel(file_path)
    print(f"Successfully loaded Excel file: '{file_path}'")
except Exception as e:
    print(f"Error reading Excel file: {e}")
    exit()

data.columns = data.columns.str.strip()
factor_columns = [
    'Number of people affected(ten thousand)', 'Citywide deaths',
    'Disaster-affected area(thousand hectares)', 'Economic losses(ten thousand yuan)',
    'Online popularity(Daily average)'
]
data_factors = data[factor_columns].dropna()
X_features = data_factors.values

# Create regression and 5-class target variables
scaler_y = MinMaxScaler()
factors_scaled = scaler_y.fit_transform(data_factors)
y_reg = np.sum(factors_scaled, axis=1)
y_multi_class = pd.qcut(y_reg, q=5, labels=False, duplicates='drop')

# Standardize features
scaler_X = StandardScaler()
X_scaled = scaler_X.fit_transform(X_features)

# --- 2. Split into Training and Validation Sets ---
X_train, X_val, y_train, y_val = train_test_split(
    X_scaled, y_multi_class,
    test_size=0.2,
    random_state=42,
    stratify=y_multi_class
)
print(f"\nData split: {len(X_train)} training samples, {len(X_val)} validation samples")

# --- 3. Record and Plot Learning Curves ---
fig, axes = plt.subplots(3, 2, figsize=(18, 18))
axes = axes.flatten()
fig.suptitle('Model Learning Curves (Train vs Validation Accuracy)', fontsize=14, fontweight='bold')

# --- A. MLP Learning Curve ---
ax = axes[0]
train_accs, val_accs = [], []
n_epochs = 100
mlp = MLPClassifier(random_state=42, warm_start=True, max_iter=1)

with warnings.catch_warnings():
    warnings.filterwarnings("ignore", category=ConvergenceWarning)
    for epoch in range(n_epochs):
        mlp.fit(X_train, y_train)
        train_accs.append(accuracy_score(y_train, mlp.predict(X_train)))
        val_accs.append(accuracy_score(y_val, mlp.predict(X_val)))

ax.plot(range(1, n_epochs + 1), train_accs, 'o-', label='Train ACC')
ax.plot(range(1, n_epochs + 1), val_accs, 's-', label='Val ACC')
ax.set_title('MLP Learning Curve')
ax.set_xlabel('Epoch')
ax.set_ylabel('Accuracy')
ax.grid(True, linestyle='--', alpha=0.6)
ax.legend()

# --- B. GBDT Learning Curve ---
ax = axes[1]
train_accs, val_accs = [], []
n_estimators = 100
gbdt = GradientBoostingClassifier(random_state=42, n_estimators=n_estimators)
gbdt.fit(X_train, y_train)

for y_pred_train, y_pred_val in zip(gbdt.staged_predict(X_train),
                                    gbdt.staged_predict(X_val)):
    train_accs.append(accuracy_score(y_train, y_pred_train))
    val_accs.append(accuracy_score(y_val, y_pred_val))

ax.plot(range(1, n_estimators + 1), train_accs, 'o-', label='Train ACC')
ax.plot(range(1, n_estimators + 1), val_accs, 's-', label='Val ACC')
ax.set_title('GBDT Learning Curve')
ax.set_xlabel('n_estimators')
ax.set_ylabel('Accuracy')
ax.grid(True, linestyle='--', alpha=0.6)
ax.legend()

# --- C. XGBoost Learning Curve ---
ax = axes[2]
xgb = XGBClassifier(
    random_state=42,
    n_estimators=100,
    eval_metric='merror'
)
xgb.fit(
    X_train, y_train,
    eval_set=[(X_train, y_train), (X_val, y_val)],
    verbose=False
)
results = xgb.evals_result()
epochs = len(results['validation_0']['merror'])

train_accs = [1 - err for err in results['validation_0']['merror']]
val_accs = [1 - err for err in results['validation_1']['merror']]

ax.plot(range(1, epochs + 1), train_accs, 'o-', label='Train ACC')
ax.plot(range(1, epochs + 1), val_accs, 's-', label='Val ACC')
ax.set_title('XGBoost Learning Curve')
ax.set_xlabel('Boosting Iteration')
ax.set_ylabel('Accuracy')
ax.grid(True, linestyle='--', alpha=0.6)
ax.legend()

# --- D. RF "Learning" Curve ---
ax = axes[3]
train_accs, val_accs = [], []
n_estimators_range = range(1, 101)
rf = RandomForestClassifier(random_state=42, warm_start=True)

for n in n_estimators_range:
    rf.set_params(n_estimators=n)
    rf.fit(X_train, y_train)
    train_accs.append(accuracy_score(y_train, rf.predict(X_train)))
    val_accs.append(accuracy_score(y_val, rf.predict(X_val)))

ax.plot(n_estimators_range, train_accs, 'o-', label='Train ACC')
ax.plot(n_estimators_range, val_accs, 's-', label='Val ACC')
ax.set_title('Random Forest Learning Curve')
ax.set_xlabel('n_estimators')
ax.set_ylabel('Accuracy')
ax.grid(True, linestyle='--', alpha=0.6)
ax.legend()

# --- E. LightGBM Learning Curve ---
ax = axes[4]
eval_result = {}
num_classes = len(np.unique(y_train))

lgbm = lgb.LGBMClassifier(
    boosting_type='gbdt',
    n_estimators=100,
    objective='multiclass',
    num_class=num_classes,
    random_state=42
)

lgbm.fit(
    X_train, y_train,
    eval_set=[(X_train, y_train), (X_val, y_val)],
    eval_metric='multi_error',
    callbacks=[lgb.record_evaluation(eval_result)]
)

train_err = eval_result['training']['multi_error']
val_err = eval_result['valid_1']['multi_error']
train_accs = [1 - e for e in train_err]
val_accs = [1 - e for e in val_err]
epochs = len(train_accs)

ax.plot(range(1, epochs + 1), train_accs, 'o-', label='Train ACC')
ax.plot(range(1, epochs + 1), val_accs, 's-', label='Val ACC')
ax.set_title('LightGBM Learning Curve')
ax.set_xlabel('Boosting Iteration')
ax.set_ylabel('Accuracy')
ax.grid(True, linestyle='--', alpha=0.6)
ax.legend()

# --- F. SVM Learning Curve ---
ax = axes[5]
svm = SVC(kernel='rbf', C=1.0, gamma='scale', random_state=42)

train_sizes = np.linspace(0.1, 1.0, 15)
train_sizes_abs, train_scores, val_scores = learning_curve(
    svm,
    X_scaled,
    y_multi_class,
    train_sizes=train_sizes,
    cv=5,
    scoring='accuracy',
    shuffle=True,
    random_state=42
)

train_mean = train_scores.mean(axis=1)
val_mean = val_scores.mean(axis=1)

ax.plot(train_sizes_abs, train_mean, 'o-', label='Train ACC')
ax.plot(train_sizes_abs, val_mean, 's-', label='Val ACC')
ax.set_title('SVM Learning Curve')
ax.set_xlabel('Training Samples')
ax.set_ylabel('Accuracy')
ax.grid(True, linestyle='--', alpha=0.6)
ax.legend()

# --- Save ---
plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.savefig('model_learning_curves_all_models_TimesNewRoman.png', dpi=300)
plt.show()
print("Saved as model_learning_curves_all_models_TimesNewRoman.png")
