#利用 6 种不同的机器学习算法对洪涝灾害数据进行建模，
#通过 10 折交叉验证筛选出最优分类器，并利用学习曲线图深度剖析各个模型在处理此类灾情数据时的学习效率与泛化能力。

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import cross_val_score, KFold, train_test_split
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.metrics import accuracy_score
import warnings
from sklearn.exceptions import ConvergenceWarning

# 导入所有需要的分类器模型
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from xgboost import XGBClassifier
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
import lightgbm as lgb

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# ==============================================================================
# --- 1. 数据加载与准备 ---
# ==============================================================================
try:
    file_path = 'FloodInventory_All_Normalized_city20.xlsx'
    data = pd.read_excel(file_path)
    print(f"✅ 成功加载Excel文件: '{file_path}'")
except Exception as e:
    print(f"读取Excel文件时发生错误: {e}")
    exit()

data.columns = data.columns.str.strip()
factor_columns = [
    'Number of people affected(ten thousand)', 'Citywide deaths',
    'Disaster-affected area(thousand hectares)', 'Economic losses(ten thousand yuan)',
    'Online popularity(Daily average)'
]
data_factors = data[factor_columns].dropna()
X_features = data_factors.values

# 标准化特征
scaler_X = StandardScaler()
X_scaled = scaler_X.fit_transform(X_features)

# 创建5分类目标 y_multi_class
scaler_y = MinMaxScaler()
factors_scaled = scaler_y.fit_transform(data_factors)
y_reg = np.sum(factors_scaled, axis=1)
y_multi_class = pd.qcut(y_reg, q=5, labels=False, duplicates='drop')
class_names = ['极低严重', '低严重', '中严重', '高严重', '极高严重']

print("\n已根据严重性指数的五分位数创建了5分类目标。")
print("各类别样本数量分布：\n", pd.Series(y_multi_class).value_counts().sort_index())

# ==============================================================================
# --- 任务一：模型分类性能交叉验证 ---
# ==============================================================================
print("\n" + "=" * 60)
print("任务一：5分类性能评估 (10折交叉验证)")
print("=" * 60)

# 定义所有要评估的分类器 (已包含正则化参数)
classifiers = {
    "RF": RandomForestClassifier(random_state=42, max_depth=10, min_samples_leaf=5),
    "GBDT": GradientBoostingClassifier(random_state=42, max_depth=5),
    "XGBoost": XGBClassifier(random_state=42, eval_metric='mlogloss', max_depth=5),
    "LightGBM": lgb.LGBMClassifier(random_state=42),
    "SVM": SVC(random_state=42),
    "MLP": MLPClassifier(random_state=42, max_iter=2000, alpha=0.001, early_stopping=True, n_iter_no_change=10)
}

kf = KFold(n_splits=10, shuffle=True, random_state=42)
class_results = []

print("正在进行交叉验证，请稍候...")
for name, model in classifiers.items():
    acc_scores = cross_val_score(model, X_scaled, y_multi_class, cv=kf, scoring='accuracy')
    f1_scores = cross_val_score(model, X_scaled, y_multi_class, cv=kf, scoring='f1_weighted')
    class_results.append({
        "Model": name,
        "Mean_Accuracy": acc_scores.mean(),
        "Mean_F1_Score_Weighted": f1_scores.mean()
    })

class_results_df = pd.DataFrame(class_results)
print("\n--- 5分类性能评估结果 ---")
print(class_results_df.sort_values(by='Mean_F1_Score_Weighted', ascending=False))

# 可视化分类性能
fig, ax = plt.subplots(1, 1, figsize=(12, 7))
df_melted = class_results_df.melt(id_vars='Model', var_name='Metric', value_name='Score')
sns.barplot(x='Model', y='Score', hue='Metric', data=df_melted, ax=ax)
ax.set_title('各模型分类性能对比 (Accuracy vs F1-Score)', fontsize=16)
ax.set_xlabel('模型', fontsize=12)
ax.set_ylabel('得分', fontsize=12)
ax.set_ylim(0.8, 1.0)
plt.legend(title='评价指标')
plt.tight_layout()
plt.savefig('classification_performance_summary.png', dpi=300)
print("\n✅ 分类性能对比图已保存为 'classification_performance_summary.png'")
plt.show()


# ==============================================================================
# --- 任务二：学习曲线分析 ---
# ==============================================================================
print("\n" + "=" * 60)
print("任务二：模型学习曲线分析")
print("=" * 60)

# 训练集/验证集分割
X_train, X_val, y_train, y_val = train_test_split(
    X_scaled, y_multi_class, test_size=0.2, random_state=42, stratify=y_multi_class
)
print(f"数据已分割：训练集 {len(X_train)}条, 验证集 {len(X_val)}条")

# 创建2x2子图布局
fig, axes = plt.subplots(2, 2, figsize=(18, 14))
axes = axes.flatten()
fig.suptitle('核心模型学习过程曲线 (Train vs Validation Accuracy)', fontsize=20)

# (MLP, GBDT, XGBoost, RF 的绘图代码与之前完全相同)
# ...
# --- A. 绘制MLP学习曲线 ---
ax = axes[0]
train_accs, val_accs = [], []
n_epochs = 100
mlp = MLPClassifier(random_state=42, warm_start=True, max_iter=1)
with warnings.catch_warnings():
    warnings.filterwarnings("ignore", category=ConvergenceWarning, module="sklearn")
    for epoch in range(n_epochs):
        mlp.fit(X_train, y_train)
        train_accs.append(accuracy_score(y_train, mlp.predict(X_train)))
        val_accs.append(accuracy_score(y_val, mlp.predict(X_val)))
ax.plot(range(1, n_epochs + 1), train_accs, 'o-', label='Train ACC')
ax.plot(range(1, n_epochs + 1), val_accs, 's-', label='Val ACC')
ax.set_title('MLP Learning Curve', fontsize=16)

# --- B. 绘制GBDT学习曲线 ---
ax = axes[1]
train_accs, val_accs = [], []
n_estimators = 100
gbdt = GradientBoostingClassifier(random_state=42, n_estimators=n_estimators, max_depth=5) # 使用正则化参数
gbdt.fit(X_train, y_train)
for y_pred_train, y_pred_val in zip(gbdt.staged_predict(X_train), gbdt.staged_predict(X_val)):
    train_accs.append(accuracy_score(y_train, y_pred_train))
    val_accs.append(accuracy_score(y_val, y_pred_val))
ax.plot(range(1, n_estimators + 1), train_accs, 'o-', label='Train ACC')
ax.plot(range(1, n_estimators + 1), val_accs, 's-', label='Val ACC')
ax.set_title('GBDT Learning Curve', fontsize=16)

# --- C. 绘制XGBoost学习曲线 ---
ax = axes[2]
xgb = XGBClassifier(random_state=42, n_estimators=100, eval_metric='merror', max_depth=5) # 使用正则化参数
xgb.fit(X_train, y_train, eval_set=[(X_train, y_train), (X_val, y_val)], verbose=False)
results = xgb.evals_result()
epochs = len(results['validation_0']['merror'])
train_accs = [1 - err for err in results['validation_0']['merror']]
val_accs = [1 - err for err in results['validation_1']['merror']]
ax.plot(range(1, epochs + 1), train_accs, 'o-', label='Train ACC')
ax.plot(range(1, epochs + 1), val_accs, 's-', label='Val ACC')
ax.set_title('XGBoost Learning Curve', fontsize=16)

# --- D. 绘制RF的“学习”曲线 ---
ax = axes[3]
train_accs, val_accs = [], []
n_estimators_range = range(1, 101)
rf = RandomForestClassifier(random_state=42, warm_start=True, max_depth=10, min_samples_leaf=5) # 使用正则化参数
for n in n_estimators_range:
    rf.set_params(n_estimators=n)
    rf.fit(X_train, y_train)
    train_accs.append(accuracy_score(y_train, rf.predict(X_train)))
    val_accs.append(accuracy_score(y_val, rf.predict(X_val)))
ax.plot(n_estimators_range, train_accs, 'o-', label='Train ACC')
ax.plot(n_estimators_range, val_accs, 's-', label='Val ACC')
ax.set_title('RF "Learning" Curve (vs n_estimators)', fontsize=16)
# ...


# --- 统一美化所有子图 ---
for ax in axes:
    ax.legend()
    ax.grid(True, linestyle='--', alpha=0.6)
    ax.set_xlabel('Epoch / n_estimators', fontsize=12)
    ax.set_ylabel('Accuracy', fontsize=12)
    # --- 【核心修改】在这里强制设定Y轴的范围 ---
    #ax.set_ylim(0, 1.05) # Y轴从0开始，到1.05结束（留一点顶部空间）
    # ------------------------------------

# --- 保存并显示图表 ---
plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.savefig('classification_learning_curves_from_zero.png', dpi=300)
print("\n✅ 所有核心模型的学习曲线图（Y轴从0开始）已成功保存为 'classification_learning_curves_from_zero.png'")
plt.show()

print("\n所有分析任务均已完成！")