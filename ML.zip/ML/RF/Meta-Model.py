#本研究采用模型堆叠（Stacking）的集成学习策略，构建了一个最终的元模型。

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import cross_val_score, KFold
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from xgboost import XGBRegressor, XGBClassifier

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


# --- 1. 数据加载 ---
try:
    feature_file_path = 'Flood_Severity_Scores_Final_Weighs_AHP.xlsx'
    feature_df = pd.read_excel(feature_file_path, engine='openpyxl')
    print(f"✅ 成功加载模型分数文件 (作为新特征): '{feature_file_path}'")

    target_file_path = 'FloodInventory_All_Normalized_city.xlsx'
    target_df_raw = pd.read_excel(target_file_path)
    print(f"✅ 成功加载原始数据文件 (用于构建目标): '{target_file_path}'")
except Exception as e:
    print(f"读取文件时发生错误: {e}")
    exit()

# ==============================================================================
# --- 2. 【核心修改】使用Pandas进行稳健的数据对齐与目标变量创建 ---
# ==============================================================================

# a) 定义列名
score_columns = ['Score_GBDT', 'Score_XGBoost', 'Score_RF', 'Score_SVM', 'Score_LightGBM', 'Score_MLP']
factor_columns = ['Number of people affected(ten thousand)', 'Citywide deaths',
                  'Disaster-affected area(thousand hectares)', 'Economic losses(ten thousand yuan)',
                  'Online popularity(Daily average)']

# b) 为两个DataFrame创建一个临时的、用于对齐的索引
# 假设两个文件的原始顺序是一致的
feature_df = feature_df.reset_index(drop=True)
target_df_raw = target_df_raw.reset_index(drop=True)

# c) 将特征和目标源数据合并到一个DataFrame中
# 我们只保留那些在两个文件中都存在的行
aligned_df = pd.concat([target_df_raw[factor_columns], feature_df[score_columns]], axis=1)

# d) 清洗数据：删除任何包含空值的行
aligned_df.dropna(inplace=True)

print(f"\n数据对齐与准备完成。")
print(f"对齐后用于训练的样本数: {len(aligned_df)}")

# e) 从对齐后的DataFrame中，创建最终的特征(X)和目标(Y)
X_new_final = aligned_df[score_columns].values

scaler_y = MinMaxScaler()
factors_scaled = scaler_y.fit_transform(aligned_df[factor_columns])
y_reg_final = np.sum(factors_scaled, axis=1)

# 使用 qcut 创建分类目标。它现在返回的是一个带有正确索引的Series
y_multi_class_series = pd.qcut(pd.Series(y_reg_final), q=5, labels=False, duplicates='drop')

# f) 最后一次对齐：因为qcut的duplicates='drop'可能会再次丢掉一些行
final_index = y_multi_class_series.index
# 我们用这个最终的索引来过滤所有数据
X_new_final = aligned_df[score_columns].loc[final_index].values
y_reg_final = pd.Series(y_reg_final).loc[final_index].values
y_multi_class_final = y_multi_class_series.values

print(f"最终用于训练的特征维度: {X_new_final.shape}")
print(f"最终用于训练的目标维度: {y_multi_class_final.shape}")

# 定义交叉验证策略
kf = KFold(n_splits=10, shuffle=True, random_state=42)

# ==============================================================================
#           任务一：使用新特征进行回归性能评估
# ==============================================================================
print("\n" + "=" * 60)
print("任务一：元模型回归性能评估 (R² 分数)")
meta_regressor = XGBRegressor(random_state=42, n_estimators=100)
r2_scores = cross_val_score(meta_regressor, X_new_final, y_reg_final, cv=kf, scoring='r2')
print(f"元模型(XGBoost)的10折交叉验证平均 R² 分数: {r2_scores.mean():.4f} (+/- {r2_scores.std():.4f})")

# ==============================================================================
#           任务二：使用新特征进行多分类性能评估
# ==============================================================================
print("\n" + "=" * 60)
print("任务二：元模型5分类性能评估 (Accuracy & F1-Score)")
meta_classifier = XGBClassifier(random_state=42, eval_metric='mlogloss', n_estimators=100)
acc_scores = cross_val_score(meta_classifier, X_new_final, y_multi_class_final, cv=kf, scoring='accuracy')
f1_scores = cross_val_score(meta_classifier, X_new_final, y_multi_class_final, cv=kf, scoring='f1_weighted')
print(f"元模型(XGBoost)的10折交叉验证平均 Accuracy: {acc_scores.mean():.4f} (+/- {acc_scores.std():.4f})")
print(f"元模型(XGBoost)的10折交叉验证平均 F1-Score: {f1_scores.mean():.4f} (+/- {f1_scores.std():.4f})")

# ==============================================================================
#           任务三：元模型特征重要性分析
# ==============================================================================
print("\n" + "=" * 60)
print("任务三：元模型特征重要性分析")
meta_regressor.fit(X_new_final, y_reg_final)
importance_df = pd.DataFrame({
    'Base_Model_Feature': score_columns,
    'Importance': meta_regressor.feature_importances_
}).sort_values('Importance', ascending=False)
print("\n元模型认为的基础模型重要性排名:")
print(importance_df)

# 可视化
plt.figure(figsize=(10, 6))
sns.barplot(x='Importance', y='Base_Model_Feature', data=importance_df, palette='viridis')
plt.title('元模型对6个基础模型分数的依赖程度')
plt.xlabel('特征重要性 (由元模型评估)')
plt.ylabel('基础模型分数 (作为特征)')
plt.tight_layout()
plt.savefig('meta_model_feature_importance.png', dpi=300)
plt.show()