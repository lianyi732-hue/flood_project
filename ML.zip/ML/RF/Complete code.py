#这个代码结合了ACC-AUU和Classification的结合
#成功地使用交叉验证，客观评估了5个模型预测连续性洪水严重指数的能力，并用图表清晰展示了结果。
#五分类任务，并使用Accuracy和F1分数这两个核心指标，全面评估了模型划分灾害等级的能力。

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import cross_val_score, KFold, train_test_split
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.metrics import r2_score, accuracy_score, f1_score, confusion_matrix, classification_report
import warnings
from sklearn.exceptions import ConvergenceWarning

# 导入所有需要的模型
# 回归器 Regressors
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from xgboost import XGBRegressor
from sklearn.svm import SVR
from sklearn.neural_network import MLPRegressor

# 分类器 Classifiers
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from xgboost import XGBClassifier
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号

# --- 1. 数据加载与准备 ---
try:
    file_path = 'FloodInventory_All_Normalized_city20.xlsx'
    data = pd.read_excel(file_path)
    print(f"成功加载Excel文件: '{file_path}'")
    print(f"数据形状: {data.shape}")
except Exception as e:
    print(f"读取Excel文件时发生错误: {e}")
    exit()

# 清理列名
data.columns = data.columns.str.strip()
print(f"数据列名: {list(data.columns)}")

# 选择特征列
factor_columns = [
    'Number of people affected(ten thousand)', 'Citywide deaths',
    'Disaster-affected area(thousand hectares)', 'Economic losses(ten thousand yuan)',
    'Online popularity(Daily average)'
]

# 检查列是否存在
missing_cols = [col for col in factor_columns if col not in data.columns]
if missing_cols:
    print(f"以下列不存在于数据中: {missing_cols}")
    exit()

data_factors = data[factor_columns].dropna()
print(f"有效数据样本数: {len(data_factors)}")

X_features = data_factors.values

# 标准化特征
scaler_X = StandardScaler()
X_scaled = scaler_X.fit_transform(X_features)

# --- 2. 创建回归和分类的目标变量 ---
# 创建回归目标 y_reg
scaler_y = MinMaxScaler()
factors_scaled = scaler_y.fit_transform(data_factors)
y_reg = np.sum(factors_scaled, axis=1)

# 创建5分类目标 y_multi_class
try:
    y_multi_class = pd.qcut(y_reg, q=5, labels=False, duplicates='drop')
    print("\n已根据严重性指数的五分位数创建了5分类目标。")
    class_counts = pd.Series(y_multi_class).value_counts().sort_index()
    print("各类别样本数量分布：\n", class_counts)

    # 可视化类别分布
    plt.figure(figsize=(10, 6))
    class_counts.plot(kind='bar', color='skyblue')
    plt.title('灾害严重程度类别分布')
    plt.xlabel('类别')
    plt.ylabel('样本数量')
    plt.xticks(rotation=0)
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.tight_layout()
    plt.savefig('class_distribution.png', dpi=300)
    plt.show()

except ValueError as e:
    print(f"\n创建分类目标时出错: {e}")
    exit()

# 定义交叉验证策略
kf = KFold(n_splits=10, shuffle=True, random_state=42)

# ==============================================================================
#                               任务一：回归性能评估
# ==============================================================================
print("\n" + "=" * 60)
print("任务一：回归性能评估 (R² 分数)")
print("=" * 60)

regressors = {
    "RF": RandomForestRegressor(random_state=42, n_estimators=100),
    "GBDT": GradientBoostingRegressor(random_state=42, n_estimators=100),
    "XGBoost": XGBRegressor(random_state=42, n_estimators=100),
    "SVM": SVR(),
    "MLP": MLPRegressor(random_state=42, max_iter=2000, hidden_layer_sizes=(100, 50))
}

reg_results = []
for name, model in regressors.items():
    r2_scores = cross_val_score(model, X_scaled, y_reg, cv=kf, scoring='r2')
    reg_results.append({
        "Model": name,
        "Mean_R2_Score": r2_scores.mean(),
        "Std_Dev_R2": r2_scores.std()
    })

reg_results_df = pd.DataFrame(reg_results)
print("\n--- 回归性能评估结果 (表1) ---")
print(reg_results_df.sort_values(by='Mean_R2_Score', ascending=False))

# 可视化回归性能
plt.figure(figsize=(10, 6))
models = reg_results_df['Model']
r2_means = reg_results_df['Mean_R2_Score']
r2_stds = reg_results_df['Std_Dev_R2']

plt.bar(models, r2_means, yerr=r2_stds, capsize=5, color=['#FF9999', '#66B2FF', '#99FF99', '#FFCC99', '#FF99CC'])
plt.title('各模型回归性能比较 (R²分数)')
plt.xlabel('模型')
plt.ylabel('R²分数')
plt.ylim(0, 1)
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.tight_layout()
plt.savefig('regression_performance.png', dpi=300)
plt.show()

# ==============================================================================
#                               任务二：多分类性能评估
# ==============================================================================
print("\n" + "=" * 60)
print("任务二：5分类性能评估 (Accuracy & F1-Score)")
print("=" * 60)

classifiers = {
    "RF": RandomForestClassifier(random_state=42, n_estimators=100),
    "GBDT": GradientBoostingClassifier(random_state=42, n_estimators=100),
    "XGBoost": XGBClassifier(random_state=42, eval_metric='mlogloss', n_estimators=100),
    "SVM": SVC(random_state=42, probability=True),
    "MLP": MLPClassifier(random_state=42, max_iter=2000, hidden_layer_sizes=(100, 50))
}

class_results = []
for name, model in classifiers.items():
    acc_scores = cross_val_score(model, X_scaled, y_multi_class, cv=kf, scoring='accuracy')
    f1_scores = cross_val_score(model, X_scaled, y_multi_class, cv=kf, scoring='f1_weighted')
    class_results.append({
        "Model": name,
        "Mean_Accuracy": acc_scores.mean(),
        "Std_Dev_Acc": acc_scores.std(),
        "Mean_F1_Score_Weighted": f1_scores.mean(),
        "Std_Dev_F1": f1_scores.std()
    })

class_results_df = pd.DataFrame(class_results)
print("\n--- 5分类性能评估结果 (表2) ---")
print(class_results_df.sort_values(by='Mean_F1_Score_Weighted', ascending=False))

# 可视化分类性能
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))

# 准确率比较
models = class_results_df['Model']
acc_means = class_results_df['Mean_Accuracy']
acc_stds = class_results_df['Std_Dev_Acc']

ax1.bar(models, acc_means, yerr=acc_stds, capsize=5, color=['#FF9999', '#66B2FF', '#99FF99', '#FFCC99', '#FF99CC'])
ax1.set_title('各模型分类准确率比较')
ax1.set_xlabel('模型')
ax1.set_ylabel('准确率')
ax1.set_ylim(0, 1)
ax1.grid(axis='y', linestyle='--', alpha=0.7)

# F1分数比较
f1_means = class_results_df['Mean_F1_Score_Weighted']
f1_stds = class_results_df['Std_Dev_F1']

ax2.bar(models, f1_means, yerr=f1_stds, capsize=5, color=['#FF9999', '#66B2FF', '#99FF99', '#FFCC99', '#FF99CC'])
ax2.set_title('各模型加权F1分数比较')
ax2.set_xlabel('模型')
ax2.set_ylabel('加权F1分数')
ax2.set_ylim(0, 1)
ax2.grid(axis='y', linestyle='--', alpha=0.7)

plt.tight_layout()
plt.savefig('classification_performance.png', dpi=300)
plt.show()

# ==============================================================================
#                               任务三：学习曲线分析
# ==============================================================================
print("\n" + "=" * 60)
print("任务三：模型学习曲线分析")
print("=" * 60)

# 划分训练集和验证集
X_train, X_val, y_train, y_val = train_test_split(
    X_scaled, y_multi_class, test_size=0.2, random_state=42, stratify=y_multi_class
)
print(f"\n数据划分: {len(X_train)} 训练样本, {len(X_val)} 验证样本")

# 记录和绘制学习曲线
fig, axes = plt.subplots(2, 2, figsize=(18, 14))
axes = axes.flatten()
fig.suptitle('模型学习曲线 (训练 vs 验证准确率)', fontsize=20)

# --- A. 绘制MLP学习曲线 ---
ax = axes[0]
train_accs, val_accs = [], []
n_epochs = 100
mlp = MLPClassifier(random_state=42, warm_start=True, max_iter=1, hidden_layer_sizes=(100, 50))
# 抑制MLP的收敛警告
with warnings.catch_warnings():
    warnings.filterwarnings("ignore", category=ConvergenceWarning, module="sklearn")
    for epoch in range(n_epochs):
        mlp.fit(X_train, y_train)
        train_accs.append(accuracy_score(y_train, mlp.predict(X_train)))
        val_accs.append(accuracy_score(y_val, mlp.predict(X_val)))
ax.plot(range(1, n_epochs + 1), train_accs, 'o-', label='Train ACC')
ax.plot(range(1, n_epochs + 1), val_accs, 's-', label='Val ACC')
ax.set_title('MLP学习曲线', fontsize=16)

# --- B. 绘制GBDT学习曲线 ---
ax = axes[1]
train_accs, val_accs = [], []
n_estimators = 100
gbdt = GradientBoostingClassifier(random_state=42, n_estimators=n_estimators)
gbdt.fit(X_train, y_train)
for y_pred_train, y_pred_val in zip(gbdt.staged_predict(X_train), gbdt.staged_predict(X_val)):
    train_accs.append(accuracy_score(y_train, y_pred_train))
    val_accs.append(accuracy_score(y_val, y_pred_val))
ax.plot(range(1, n_estimators + 1), train_accs, 'o-', label='Train ACC')
ax.plot(range(1, n_estimators + 1), val_accs, 's-', label='Val ACC')
ax.set_title('GBDT学习曲线', fontsize=16)

# --- C. 绘制XGBoost学习曲线 ---
ax = axes[2]
xgb = XGBClassifier(random_state=42, n_estimators=100, eval_metric='merror')
xgb.fit(X_train, y_train, eval_set=[(X_train, y_train), (X_val, y_val)], verbose=False)
results = xgb.evals_result()
epochs = len(results['validation_0']['merror'])
# 将错误率转换为准确率
train_accs = [1 - err for err in results['validation_0']['merror']]
val_accs = [1 - err for err in results['validation_1']['merror']]
ax.plot(range(1, epochs + 1), train_accs, 'o-', label='Train ACC')
ax.plot(range(1, epochs + 1), val_accs, 's-', label='Val ACC')
ax.set_title('XGBoost学习曲线', fontsize=16)

# --- D. 绘制RF学习曲线 ---
ax = axes[3]
train_accs, val_accs = [], []
n_estimators_range = range(1, 101)
rf = RandomForestClassifier(random_state=42, warm_start=True)
for n in n_estimators_range:
    rf.set_params(n_estimators=n)
    rf.fit(X_train, y_train)
    train_accs.append(accuracy_score(y_train, rf.predict(X_train)))
    val_accs.append(accuracy_score(y_val, rf.predict(X_val)))
ax.plot(n_estimators_range, train_accs, 'o-', label='Train ACC')
ax.plot(n_estimators_range, val_accs, 's-', label='Val ACC')
ax.set_title('RF学习曲线 (vs n_estimators)', fontsize=16)

# 最终化并保存图表
for ax in axes:
    ax.legend()
    ax.grid(True, linestyle='--', alpha=0.6)
    ax.set_xlabel('Epoch / n_estimators', fontsize=12)
    ax.set_ylabel('准确率', fontsize=12)

plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.savefig('model_learning_curves.png', dpi=300)
print("\n所有模型学习曲线图表已保存到 'model_learning_curves.png'")
plt.show()

# ==============================================================================
#                               任务四：最佳模型训练与预测
# ==============================================================================
print("\n" + "=" * 60)
print("任务四：使用最佳模型进行训练和预测")
print("=" * 60)

# 选择最佳回归模型
best_reg_model_name = reg_results_df.loc[reg_results_df['Mean_R2_Score'].idxmax(), 'Model']
best_reg_model = regressors[best_reg_model_name]

# 选择最佳分类模型
best_clf_model_name = class_results_df.loc[class_results_df['Mean_F1_Score_Weighted'].idxmax(), 'Model']
best_clf_model = classifiers[best_clf_model_name]

print(f"最佳回归模型: {best_reg_model_name}")
print(f"最佳分类模型: {best_clf_model_name}")

# 划分训练集和测试集
X_train_full, X_test, y_reg_train, y_reg_test, y_clf_train, y_clf_test = train_test_split(
    X_scaled, y_reg, y_multi_class, test_size=0.2, random_state=42, stratify=y_multi_class
)

print(f"\n训练集样本数: {len(X_train_full)}")
print(f"测试集样本数: {len(X_test)}")

# 训练回归模型
best_reg_model.fit(X_train_full, y_reg_train)
y_reg_pred = best_reg_model.predict(X_test)
reg_r2 = r2_score(y_reg_test, y_reg_pred)

print(f"\n回归模型在测试集上的R²分数: {reg_r2:.4f}")

# 训练分类模型
best_clf_model.fit(X_train_full, y_clf_train)
y_clf_pred = best_clf_model.predict(X_test)
clf_accuracy = accuracy_score(y_clf_test, y_clf_pred)
clf_f1 = f1_score(y_clf_test, y_clf_pred, average='weighted')

print(f"分类模型在测试集上的准确率: {clf_accuracy:.4f}")
print(f"分类模型在测试集上的加权F1分数: {clf_f1:.4f}")

# 生成分类报告
print("\n分类报告:")
print(classification_report(y_clf_test, y_clf_pred))

# 绘制混淆矩阵
cm = confusion_matrix(y_clf_test, y_clf_pred)
plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
            xticklabels=['Class 0', 'Class 1', 'Class 2', 'Class 3', 'Class 4'],
            yticklabels=['Class 0', 'Class 1', 'Class 2', 'Class 3', 'Class 4'])
plt.title('混淆矩阵')
plt.ylabel('真实标签')
plt.xlabel('预测标签')
plt.tight_layout()
plt.savefig('confusion_matrix.png', dpi=300)
plt.show()

# ==============================================================================
#                               任务五：特征重要性分析
# ==============================================================================
print("\n" + "=" * 60)
print("任务五：特征重要性分析")
print("=" * 60)

# 分析随机森林的特征重要性
if hasattr(best_reg_model, 'feature_importances_'):
    feature_importance = best_reg_model.feature_importances_
    feature_names = factor_columns

    # 创建特征重要性DataFrame
    importance_df = pd.DataFrame({
        'Feature': feature_names,
        'Importance': feature_importance
    }).sort_values('Importance', ascending=False)

    print("\n回归模型特征重要性:")
    print(importance_df)

    # 可视化特征重要性
    plt.figure(figsize=(10, 6))
    plt.barh(importance_df['Feature'], importance_df['Importance'], color='skyblue')
    plt.title('回归模型特征重要性')
    plt.xlabel('重要性')
    plt.tight_layout()
    plt.savefig('feature_importance.png', dpi=300)
    plt.show()

# 保存结果到Excel
with pd.ExcelWriter('model_performance_results.xlsx') as writer:
    reg_results_df.to_excel(writer, sheet_name='回归性能', index=False)
    class_results_df.to_excel(writer, sheet_name='分类性能', index=False)
    if 'importance_df' in locals():
        importance_df.to_excel(writer, sheet_name='特征重要性', index=False)

print("\n所有结果已保存到 'model_performance_results.xlsx'")
print("所有图表已保存为PNG文件")
print("\n分析完成！")