import joblib
import pandas as pd
from sklearn import metrics
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# 预测全区
data = pd.read_csv(r'C:\Users\fan\Desktop\测试集.csv')

x_data_pr = data.loc[:, ['key1', 'key2', 'key3', 'key4', 'key5', 'key6', 'key7','key8']]

#
transfer = StandardScaler()
x_data_pr = transfer.fit_transform(x_data_pr)
estimator = joblib.load('rf.pkl')
# 预测
y_predict = estimator.predict(x_data_pr)

print(y_predict, y_predict.shape)

# 输出预测概率值
roc_auc_plot = estimator.predict_proba(x_data_pr)
print(roc_auc_plot, y_predict.shape)
pd.DataFrame(roc_auc_plot).to_csv(r'C:\Users\fan\Desktop\RFjieguo.csv', header=None)