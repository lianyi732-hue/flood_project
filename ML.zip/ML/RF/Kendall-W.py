#计算不同模型指标权重的一致性

import pandas as pd
from scipy.stats import friedmanchisquare

# ==============================================================================
# --- 1. 数据加载与准备 ---
# ==============================================================================
# 【核心修改】文件名应为您的 .xlsx 文件名
file_path ='Flood_Severity_Scores_Final_Weighs_Entropy.xlsx'

try:
    # 【核心修改】使用 pd.read_excel() 并指定 openpyxl 引擎来读取 .xlsx 文件
    data = pd.read_excel(file_path, engine='openpyxl')
    print(f"✅ 成功加载Excel文件: '{file_path}'")
except FileNotFoundError:
    print(f"❌ 错误：未找到文件 '{file_path}'。请确保文件与脚本在同一目录下。")
    exit()
except Exception as e:
    print(f"❌ 读取文件时发生错误: {e}")
    exit()

# --- 2. 选取所有6个模型的分数列 ---
score_columns = [
    'Score_GBDT',
    'Score_XGBoost',
    'Score_RF',
    'Score_SVM',
    'Score_LightGBM',
    'Score_MLP'
]

# 检查列是否存在
missing_cols = [col for col in score_columns if col not in data.columns]
if missing_cols:
    print(f"\n❌ 错误：数据中缺少以下模型分数列: {missing_cols}")
    exit()

scores_df = data[score_columns]
print(f"\n已成功提取 {len(scores_df)} 条记录的 {len(score_columns)} 个模型分数用于一致性分析。")


# --- 3. 使用 Scipy 的弗里德曼检验计算 Kendall's W ---
try:
    statistic, p_value = friedmanchisquare(*scores_df.T.values)
    k = scores_df.shape[1]
    n = scores_df.shape[0]
    kendall_w = statistic / (k * (n - 1))

    # --- 4. 展示并解读结果 ---
    print("\n" + "="*60)
    print("--- 6个模型预测结果一致性分析 (肯德尔和谐系数) ---")
    print(f"肯德尔和谐系数 (Kendall's W): {kendall_w:.4f}")
    print(f"P值 (P-value): {p_value}")
    print(f"弗里德曼检验统计量 (Chi-squared): {statistic:.4f}")
    print("="*60)

    # ... (结果解读部分与之前相同) ...

except Exception as e:
    print(f"\n❌ 在计算过程中发生错误: {e}")