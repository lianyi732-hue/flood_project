import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.neural_network import MLPClassifier
from matplotlib.ticker import MaxNLocator

# ======================================================================
# 全局字体配置：Times New Roman + 字号14
# ======================================================================
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 14
plt.rcParams['axes.unicode_minus'] = False

# 高对比度严重性颜色映射：0-4 (Very Low → Very High)
severity_palette = {
    0: '#2ECC71',  # 绿色
    1: '#F1C40F',  # 黄色
    2: '#F39C12',  # 橙色
    3: '#E67E22',  # 深橙
    4: '#E74C3C',  # 红色
}

# ======================================================================
# --- 1. 读入数据 ---
# ======================================================================
try:
    file_path = 'FloodInventory_All_Normalized_city20.xlsx'
    data = pd.read_excel(file_path)
    print(f"Loaded: {file_path}")
except Exception as e:
    print(f"Error loading excel file: {e}")
    exit()

data.columns = data.columns.str.strip()

factor_columns = [
    'Number of people affected(ten thousand)',
    'Citywide deaths',
    'Disaster-affected area(thousand hectares)',
    'Economic losses(ten thousand yuan)',
    'Online popularity(Daily average)'
]

data.dropna(subset=factor_columns, inplace=True)

# 输入变量标准化
X_features = data[factor_columns].values
scaler_X = StandardScaler()
X_scaled = scaler_X.fit_transform(X_features)

# 清理城市名称
data['City'] = (
    data['City']
    .astype(str)
    .str.replace(' City', '')
    .str.replace('市', '')
    .str.strip()
)

# ======================================================================
# --- 2. MLP 建模得到严重等级 ---
# ======================================================================
best_model = MLPClassifier(
    random_state=42,
    max_iter=2000,
    hidden_layer_sizes=(100, 50)
)

scaler_y = MinMaxScaler()
factors_scaled = scaler_y.fit_transform(data[factor_columns])
y_reg = np.sum(factors_scaled, axis=1)

y_multi_class = pd.qcut(y_reg, q=5, labels=False, duplicates='drop')

print("\nTraining MLP Classifier...")
best_model.fit(X_scaled, y_multi_class)

data['Predicted_Severity_Class'] = best_model.predict(X_scaled)
print("Model prediction done.")

# 年度平均严重等级
annual_severity = (
    data.groupby(['City', 'Year'])['Predicted_Severity_Class']
    .mean()
    .reset_index()
)
annual_severity.rename(columns={'Predicted_Severity_Class': 'Avg_Severity_Class'}, inplace=True)

print("Annual severity computed.")

# ======================================================================
# --- 3. 北 / 南 城市分组 ---
# ======================================================================
northern_cities_raw = [
    'Beijing', 'Tianjin', "Xi'an", 'Tangshan', 'Zhengzhou',
    'Dalian', 'Shenyang', 'Jinan', 'Qingdao', 'Yantai'
]
northern_cities = [
    c.replace(' City', '').replace('市', '').strip()
    for c in northern_cities_raw
]

all_cities = annual_severity['City'].unique().tolist()
southern_cities = [c for c in all_cities if c not in northern_cities]

# ======================================================================
# --- 4. 统一 X/Y 轴 ---
# ======================================================================
min_year = int(annual_severity['Year'].min())
max_year = int(annual_severity['Year'].max())
x_ticks = range(min_year, max_year + 1, 5)

# ======================================================================
# --- 5. 绘制北方城市图（高对比度 + 实心点） ---
# ======================================================================
print("\nPlotting Northern Cities Trends (High Contrast + Solid Dots)...")

fig_north, axes_north = plt.subplots(5, 2, figsize=(18, 14))
fig_north.suptitle('Annual Trend of Flood Severity (Northern Cities)', fontsize=22, y=0.99)
axes_north = axes_north.flatten()

for i, city in enumerate(northern_cities):
    ax = axes_north[i]
    city_df = annual_severity[annual_severity['City'] == city].sort_values('Year')

    if not city_df.empty:

        city_df = city_df.copy()
        city_df['Severity_Round'] = (
            city_df['Avg_Severity_Class']
            .round()
            .astype(int)
            .clip(0, 4)
        )

        # 灰色折线：趋势
        ax.plot(
            city_df['Year'], city_df['Avg_Severity_Class'],
            color='grey', linewidth=2,
            marker='o', markersize=4
        )

        # 实心点（颜色显著）
        for idx, row in city_df.iterrows():
            ax.scatter(
                row['Year'], row['Avg_Severity_Class'],
                s=95,
                color=severity_palette[row['Severity_Round']],
                edgecolors='black',
                linewidth=0.3,
                zorder=5
            )

    ax.set_title(city, fontsize=16, fontweight='bold')
    ax.set_ylim(-0.2, 4.2)
    ax.set_yticks([0, 1, 2, 3, 4])
    ax.set_xlim(min_year - 1, max_year + 1)
    ax.set_xticks(x_ticks)
    ax.grid(True, linestyle='--', alpha=0.5)

    # 统一字体
    for label in ax.get_xticklabels():
        label.set_fontfamily('Times New Roman')
    for label in ax.get_yticklabels():
        label.set_fontfamily('Times New Roman')

axes_north[-1].set_xlabel('Year', fontsize=14)
axes_north[-2].set_xlabel('Year', fontsize=14)

plt.tight_layout(rect=[0, 0.03, 1, 0.97])
plt.savefig('Northern_Cities_Severity_SolidDots.png', dpi=300)
plt.show()

print("Saved Northern_Cities_Severity_SolidDots.png")

# ======================================================================
# --- 6. 绘制南方城市图（高对比度 + 实心点） ---
# ======================================================================
print("\nPlotting Southern Cities Trends (High Contrast + Solid Dots)...")

fig_south, axes_south = plt.subplots(5, 2, figsize=(18, 14))
fig_south.suptitle('Annual Trend of Flood Severity (Southern Cities)', fontsize=22, y=0.99)
axes_south = axes_south.flatten()

for i, city in enumerate(southern_cities):
    ax = axes_south[i]
    city_df = annual_severity[annual_severity['City'] == city].sort_values('Year')

    if not city_df.empty:

        city_df = city_df.copy()
        city_df['Severity_Round'] = (
            city_df['Avg_Severity_Class']
            .round()
            .astype(int)
            .clip(0, 4)
        )

        # 灰色折线
        ax.plot(
            city_df['Year'], city_df['Avg_Severity_Class'],
            color='grey', linewidth=2,
            marker='o', markersize=4
        )

        # 实心点
        for idx, row in city_df.iterrows():
            ax.scatter(
                row['Year'], row['Avg_Severity_Class'],
                s=95,
                color=severity_palette[row['Severity_Round']],
                edgecolors='black',
                linewidth=0.3,
                zorder=5
            )

    ax.set_title(city, fontsize=16, fontweight='bold')
    ax.set_ylim(-0.2, 4.2)
    ax.set_yticks([0, 1, 2, 3, 4])
    ax.set_xlim(min_year - 1, max_year + 1)
    ax.set_xticks(x_ticks)
    ax.grid(True, linestyle='--', alpha=0.5)

    # 英文字体统一
    for label in ax.get_xticklabels():
        label.set_fontfamily('Times New Roman')
    for label in ax.get_yticklabels():
        label.set_fontfamily('Times New Roman')

axes_south[-1].set_xlabel('Year', fontsize=14)
axes_south[-2].set_xlabel('Year', fontsize=14)

plt.tight_layout(rect=[0, 0.03, 1, 0.97])
plt.savefig('Southern_Cities_Severity_SolidDots.png', dpi=300)
plt.show()

print("Saved Southern_Cities_Severity_SolidDots.png")


print("\nAll tasks completed successfully.")
