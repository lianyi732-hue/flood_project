# 这个代码是实现了Figure_3的出图
# 最新版本是arial字体

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np

# =========================
# Font settings
# =========================
FONT_FAMILY = "Arial"
FONT_WEIGHT = "bold"

# 按你的最新要求：坐标字体略小；格子内数字不大；y轴旋转90°保持原来方向
AXIS_FONT_SIZE = 14       # x/y ticks（比上一版小一点）
ANNOT_FONT_SIZE = 12      # inside cells
PANEL_FONT_SIZE = 18      # (1)(2)标签字号

plt.rcParams.update({
    "font.family": FONT_FAMILY,
    "axes.unicode_minus": False
})
sns.set_theme(style="white")

# =========================
# Data config
# =========================
datasets = [
    ("Flood_Severity_Scores_Final_Weighs_AHP.xlsx", "(1) AHP"),
    ("Flood_Severity_Scores_Final_Weighs_Entropy.xlsx", "(2) Entropy Weight")
]
score_columns = [
    "Score_GBDT", "Score_XGBoost", "Score_RF",
    "Score_SVM", "Score_LightGBM", "Score_MLP"
]

corr_mats = []
for file_path, _ in datasets:
    df = pd.read_excel(file_path, engine="openpyxl")
    corr_mats.append(df[score_columns].corr(method="spearman"))

# =========================
# Labels: 两行显示（放不下就换行）
# =========================
two_line_labels = [c.replace("Score_", "Score\n") for c in score_columns]
# 如果你想更省空间（只显示模型名），用下面这行替换上面那行：
# two_line_labels = [c.replace("Score_", "") for c in score_columns]

# =========================
# Plot settings
# =========================
VMIN, VMAX = 0.96, 1.00
CBAR_TICKS = np.arange(0.965, 1.001, 0.005)
CMAP = "Blues"

# =========================
# Figure layout (shared colorbar)
# =========================
fig = plt.figure(figsize=(18, 6.2))
gs = fig.add_gridspec(1, 3, width_ratios=[1, 1, 0.045], wspace=0.12)

ax1 = fig.add_subplot(gs[0, 0])
ax2 = fig.add_subplot(gs[0, 1])
cax = fig.add_subplot(gs[0, 2])  # shared colorbar axis

axes = [ax1, ax2]

# 给两行 x 标签留一点空间
fig.subplots_adjust(left=0.10, right=0.97, bottom=0.24, top=0.98)

# =========================
# Draw heatmaps (ONLY ax2 creates the colorbar on cax)
# =========================
for i, (ax, (_, panel_label), corr) in enumerate(zip(axes, datasets, corr_mats)):
    show_cbar = (i == 1)  # only right panel draws the single shared colorbar

    sns.heatmap(
        corr,
        ax=ax,
        cmap=CMAP,
        vmin=VMIN,
        vmax=VMAX,
        annot=True,
        fmt=".3f",
        linewidths=0.5,
        linecolor="white",
        square=True,
        xticklabels=two_line_labels,
        yticklabels=two_line_labels,
        cbar=show_cbar,
        cbar_ax=cax if show_cbar else None,
        cbar_kws={"ticks": CBAR_TICKS} if show_cbar else None,
        annot_kws={"size": ANNOT_FONT_SIZE, "weight": FONT_WEIGHT, "family": FONT_FAMILY}
    )

    # X ticks: 0°
    ax.tick_params(axis="x", pad=8)
    for t in ax.get_xticklabels():
        t.set_rotation(0)
        t.set_ha("center")
        t.set_fontfamily(FONT_FAMILY)
        t.set_fontsize(AXIS_FONT_SIZE)
        t.set_fontweight(FONT_WEIGHT)

    # Y ticks: 90°（方向/对齐方式与原始代码一致）
    ax.tick_params(axis="y", pad=8)
    for t in ax.get_yticklabels():
        t.set_rotation(90)
        t.set_va("center")
        t.set_ha("center")
        t.set_fontfamily(FONT_FAMILY)
        t.set_fontsize(AXIS_FONT_SIZE)
        t.set_fontweight(FONT_WEIGHT)

    # Panel label at bottom
    ax.text(
        0.5, -0.20,
        panel_label,
        transform=ax.transAxes,
        ha="center",
        va="top",
        fontsize=PANEL_FONT_SIZE,
        fontfamily=FONT_FAMILY,
        fontweight=FONT_WEIGHT
    )

# =========================
# Shared colorbar formatting (rotate 90°)
# =========================
cbar = ax2.collections[0].colorbar
cbar.ax.tick_params(labelsize=AXIS_FONT_SIZE, pad=8)

for t in cbar.ax.get_yticklabels():
    t.set_rotation(90)
    t.set_va("center")
    t.set_ha("center")
    t.set_fontfamily(FONT_FAMILY)
    t.set_fontsize(AXIS_FONT_SIZE)
    t.set_fontweight(FONT_WEIGHT)

# =========================
# Save
# =========================
out_png = "spearman_heatmap_AHP_vs_Entropy_shared_cbar_compact_v3.png"
plt.savefig(out_png, dpi=300, bbox_inches="tight", pad_inches=0.05)
plt.show()

print(f"✅ 完成：坐标字体略调小 + y轴90°与原始一致：{out_png}")