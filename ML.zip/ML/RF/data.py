#这个代码的作用是 生成ArcGIS可以读取的是CSV格式的数据
#加载原始数据，训练最佳模型预测出每个事件的严重等级，然后提取出包含经纬度和严重性等级的关键信息，最后保存为一个干净的CSV文件。

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.neural_network import MLPClassifier

print("--- 步骤1：准备GIS数据 ---")

# --- a. 加载并准备数据 ---
try:
    file_path = 'FloodInventory_All_Normalized_city20.xlsx'
    data = pd.read_excel(file_path)
    print(f"✅ 成功加载Excel文件: '{file_path}'")
except Exception as e:
    print(f"❌ 读取Excel文件时发生错误: {e}")
    exit()

data.columns = data.columns.str.strip()
factor_columns = [
    'Number of people affected(ten thousand)', 'Citywide deaths',
    'Disaster-affected area(thousand hectares)', 'Economic losses(ten thousand yuan)',
    'Online popularity(Daily average)'
]
data.dropna(subset=factor_columns + ['Longitude', 'latitude'], inplace=True)
X_features = data[factor_columns].values
scaler_X = StandardScaler()
X_scaled = scaler_X.fit_transform(X_features)

# --- b. 训练最佳模型并进行预测 ---
best_model = MLPClassifier(random_state=42, max_iter=2000, hidden_layer_sizes=(100, 50))
scaler_y = MinMaxScaler()
factors_scaled = scaler_y.fit_transform(data[factor_columns])
y_reg = np.sum(factors_scaled, axis=1)
y_multi_class = pd.qcut(y_reg, q=5, labels=False, duplicates='drop')

print("⏳ 正在训练模型以预测严重性等级...")
best_model.fit(X_scaled, y_multi_class)
data['Severity_Class'] = best_model.predict(X_scaled)
print("✅ 已为所有洪水事件预测严重性等级。")

# --- c. 清理经纬度并提取关键列 ---
# 清理经纬度列，去除可能存在的'°E', '°N'等字符
data['Lon'] = data['Longitude'].astype(str).str.replace('°E', '').str.strip()
data['Lat'] = data['latitude'].astype(str).str.replace('°N', '').str.strip()

# 将经纬度转换为数值
data['Lon'] = pd.to_numeric(data['Lon'], errors='coerce')
data['Lat'] = pd.to_numeric(data['Lat'], errors='coerce')

# 提取最终需要的列
gis_data = data[['Year', 'City', 'County', 'Lon', 'Lat', 'Severity_Class']].dropna()

# --- d. 保存为CSV文件 ---
output_path = 'Flood_Events_for_GIS.csv'
gis_data.to_csv(output_path, index=False, encoding='utf-8-sig')
print(f"\n✅ GIS所需的数据已成功保存到: '{output_path}'")
print("下一步，请在ArcGIS中打开这个CSV文件。")