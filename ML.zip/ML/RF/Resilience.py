#这个代码的作用是做一个关于一个城市不同年份的洪涝韧性综合得分的变化趋势，可以判断韧性是在提升还是恶化。
#且将综合得分划分为“高、中、低”等不同韧性等级，更直观地展示城市韧性水平随时间的变化过程。
#最后有南北方城市对比图绘制 得到了两组韧性等级图
#韧
#性等级

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.neural_network import MLPClassifier
from matplotlib.ticker import MaxNLocator

# ==============================================================================
# --- 主程序 ---
# ==============================================================================
# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# --- 1. 加载并准备数据 ---
try:
    file_path = 'FloodInventory_All_Normalized_city20.xlsx'
    data = pd.read_excel(file_path)
    print(f"成功加载Excel文件: '{file_path}'")
except Exception as e:
    print(f"读取Excel文件时发生错误: {e}")
    exit()

data.columns = data.columns.str.strip()
factor_columns = [
    'Number of people affected(ten thousand)', 'Citywide deaths',
    'Disaster-affected area(thousand hectares)', 'Economic losses(ten thousand yuan)',
    'Online popularity(Daily average)'
]
data.dropna(subset=factor_columns, inplace=True)
X_features = data[factor_columns].values
scaler_X = StandardScaler()
X_scaled = scaler_X.fit_transform(X_features)
data['City'] = data['City'].astype(str).str.replace(' City', '').str.replace('市', '').str.strip()

# --- 2. 训练模型并计算韧性分数 ---
best_model = MLPClassifier(random_state=42, max_iter=2000, hidden_layer_sizes=(100, 50))
scaler_y = MinMaxScaler()
factors_scaled = scaler_y.fit_transform(data[factor_columns])
y_reg = np.sum(factors_scaled, axis=1)
y_multi_class = pd.qcut(y_reg, q=5, labels=False, duplicates='drop')

print("\n正在训练模型并预测严重性等级...")
best_model.fit(X_scaled, y_multi_class)
data['Predicted_Severity_Class'] = best_model.predict(X_scaled)
print("正在计算年度韧性分数...")
annual_severity = data.groupby(['City', 'Year'])['Predicted_Severity_Class'].mean().reset_index()
annual_severity.rename(columns={'Predicted_Severity_Class': 'Avg_Severity_Class'}, inplace=True)
annual_severity['Resilience_Score'] = 4 - annual_severity['Avg_Severity_Class']
try:
    annual_severity['Resilience_Level'] = pd.qcut(
        annual_severity['Resilience_Score'], q=3, labels=['低韧性', '中韧性', '高韧性']
    )
except Exception:
    score_bins = [-np.inf, annual_severity['Resilience_Score'].quantile(0.33),
                  annual_severity['Resilience_Score'].quantile(0.67), np.inf]
    annual_severity['Resilience_Level'] = pd.cut(annual_severity['Resilience_Score'], bins=score_bins, labels=['低韧性', '中韧性', '高韧性'])
print("韧性分数计算完成。")


# ==============================================================================
# --- 3. 分组并分别绘制细节图 ---
# ==============================================================================

# --- a. 定义城市分组 ---
northern_cities_raw = [
    'Beijing', 'Tianjin', 'Xi\'an City', 'Tangshan City', 'Zhengzhou City',
    'Dalian City', 'Shenyang City', 'Jinan City', 'Qingdao City', 'Yantai City'
]
northern_cities = [name.replace(' City', '').replace('市', '').strip() for name in northern_cities_raw]
all_cities_in_data = annual_severity['City'].unique().tolist()
southern_cities = [city for city in all_cities_in_data if city not in northern_cities]

# --- b. 绘制第一张图：北方城市 ---
print("\n正在绘制尺寸优化后的北方城市韧性趋势图...")
# 【核心修改】将figsize的高度从25调整为14
fig_north, axes_north = plt.subplots(5, 2, figsize=(18, 14))
fig_north.suptitle('北方10城市洪涝韧性年度变化趋势', fontsize=28, y=0.99)
axes_north = axes_north.flatten()

for i, city_name in enumerate(northern_cities):
    ax = axes_north[i]
    city_data = annual_severity[annual_severity['City'] == city_name].sort_values(by='Year')
    if not city_data.empty:
        sns.lineplot(x='Year', y='Resilience_Score', data=city_data, marker='o', lw=2, color='grey', ax=ax)
        sns.scatterplot(x='Year', y='Resilience_Score', hue='Resilience_Level', data=city_data,
                        palette={'低韧性': '#d62728', '中韧性': '#ff7f0e', '高韧性': '#2ca02c'},
                        s=120, edgecolor='w', zorder=3, ax=ax)
        min_score = city_data['Resilience_Score'].min()
        max_score = city_data['Resilience_Score'].max()
        ax.set_ylim(min_score - 0.2, max_score + 0.2)
        ax.yaxis.set_major_locator(MaxNLocator(nbins=5, prune='both'))
    ax.set_title(city_name, fontsize=18)
    ax.set_ylabel('韧性得分', fontsize=12)
    ax.set_xlabel('年份', fontsize=12)
    ax.grid(True, linestyle='--', alpha=0.5)
    ax.legend().set_visible(False)

plt.tight_layout(rect=[0, 0.03, 1, 0.97])
plt.savefig('Northern_Cities_Resilience_Trends_Compact.png', dpi=300)
print("✅ 尺寸优化后的北方城市图表已保存。")
plt.show()


# --- c. 绘制第二张图：南方城市 ---
print("\n正在绘制尺寸优化后的南方城市韧性趋势图...")
# 【核心修改】将figsize的高度从25调整为14
fig_south, axes_south = plt.subplots(5, 2, figsize=(18, 14))
fig_south.suptitle('南方10城市洪涝韧性年度变化趋势', fontsize=28, y=0.99)
axes_south = axes_south.flatten()

for i, city_name in enumerate(southern_cities):
    ax = axes_south[i]
    city_data = annual_severity[annual_severity['City'] == city_name].sort_values(by='Year')
    if not city_data.empty:
        sns.lineplot(x='Year', y='Resilience_Score', data=city_data, marker='o', lw=2, color='grey', ax=ax)
        sns.scatterplot(x='Year', y='Resilience_Score', hue='Resilience_Level', data=city_data,
                        palette={'低韧性': '#d62728', '中韧性': '#ff7f0e', '高韧性': '#2ca02c'},
                        s=120, edgecolor='w', zorder=3, ax=ax)
        min_score = city_data['Resilience_Score'].min()
        max_score = city_data['Resilience_Score'].max()
        ax.set_ylim(min_score - 0.2, max_score + 0.2)
        ax.yaxis.set_major_locator(MaxNLocator(nbins=5, prune='both'))
    ax.set_title(city_name, fontsize=18)
    ax.set_ylabel('韧性得分', fontsize=12)
    ax.set_xlabel('年份', fontsize=12)
    ax.grid(True, linestyle='--', alpha=0.5)
    ax.legend().set_visible(False)

handles, labels = axes_north[0].get_legend_handles_labels()
fig_south.legend(handles, labels, loc='upper right', title='韧性等级', fontsize=16, bbox_to_anchor=(0.98, 0.98))
plt.tight_layout(rect=[0, 0.03, 1, 0.97])
plt.savefig('Southern_Cities_Resilience_Trends_Compact.png', dpi=300)
print("✅ 尺寸优化后的南方城市图表已保存。")
plt.show()

print("\n所有分析与绘图任务均已完成！")